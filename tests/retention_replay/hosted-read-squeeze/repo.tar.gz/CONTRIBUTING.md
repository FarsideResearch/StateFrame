# Contributing to Frame Lab

Thanks for wanting to help. Bug reports, fixes, tests and documentation improvements are all welcome.

## Before you start

Frame Lab is part of the StateFrame project and is dual-licensed the same way: under the GNU Affero General Public
License v3.0 only, or under a separate commercial license from Farside Research LLC. See LICENSE and
COMMERCIAL-LICENSE.md.

To keep both options possible, every contribution needs a signed Contributor License Agreement before it can be
merged. Frame Lab uses the StateFrame project's agreement in [CLA.md](CLA.md). You keep the copyright in your work; the
agreement gives the project the rights it needs to ship it under both licenses.

## Development setup

Use Python 3.11 or newer. A fresh clone needs no Python runtime dependencies:

```bash
git clone https://github.com/FarsideResearch/FrameLab.git
cd FrameLab
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --no-index --no-build-isolation -e .
```

Node.js 20 or newer is needed only when changing the web UI. From the repository root, install its locked dependencies and rebuild the shipped bundle:

```bash
cd ui/web
npm ci
npm run build
```

When UI sources change, commit the rebuilt `ui/web/dist` with them. The normal install and UI server do not need Node.js.

## Tests

Run all available suites from the repository root:

```bash
python3 -B -m unittest discover -s tests -t .
(cd ui && python3 -B -m unittest discover -s tests -t .)
bash scripts/check.sh
```

The check script also runs the license inventory, manifest check and wheel/sdist build and listing checks. It skips the web suite with an install instruction when `ui/web/node_modules` is missing. To run that suite directly, use Node.js 20 or newer and run `npm ci` in `ui/web`, then `(cd ui/web && npm test)`. No suite needs a model server.

## Code and UI style

- Keep the command line in `src/framelab/` and the UI server in `ui/` on the Python standard library. Discuss a runtime dependency before adding one.
- Keep changes focused, use clear names and short functions, and comment where a reason would not be clear from the code.
- Add or update a test that fails without the change and passes with it.
- Any new web dependency must use a permissive license (MIT, BSD, Apache-2.0, ISC, PSF or similar). After changing the lockfile, run `python3 scripts/license_inventory.py` and `python3 scripts/build_web_notices.py`.
- UI colors, type and spacing come from `ui/web/src/tokens.css`.

## Reporting a problem

For a normal bug, open an issue and include:

- the exact command you ran,
- what you expected and what happened instead,
- the error Frame Lab printed (it never prints your API key, but check before you paste),
- your Python version and operating system.

Please leave out run journals, source code or data you are not allowed to share. A journal contains the full text the model saw.

Report suspected security issues privately to Farside Research at [support@farsideresearch.com](mailto:support@farsideresearch.com). Do not open a public issue for a security report.

## Review

A maintainer will read your change, may ask for small adjustments, and will merge it once the tests pass and your signed CLA is on file. Thanks again for helping.
