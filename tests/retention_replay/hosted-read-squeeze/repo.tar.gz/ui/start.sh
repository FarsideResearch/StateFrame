#!/usr/bin/env bash
# Frame Lab UI: build the web app if its sources changed, then serve on 127.0.0.1.
# Usage: bash ui/start.sh [port]   (default 8786 or FRAME_LAB_PORT)
#   FRAME_LAB_DATA=PATH    inspect a folder of runs (or one StateFrame run directory)
#   FRAME_LAB_CONFIG=PATH  use a versioned source manifest (see ui/schemas/source-manifest.schema.json)
#   neither                show the bundled synthetic demo
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${1:-${FRAME_LAB_PORT:-8786}}"
WEB="$HERE/web"

SOURCE_ARGS=()
if [ -n "${FRAME_LAB_CONFIG:-}" ]; then
  SOURCE_ARGS+=(--config "$FRAME_LAB_CONFIG")
elif [ -n "${FRAME_LAB_DATA:-}" ]; then
  SOURCE_ARGS+=(--data-root "$FRAME_LAB_DATA")
else
  # Nothing configured: the synthetic demo. Imported sources are always explicit.
  SOURCE_ARGS+=(--demo)
fi

# The release ships a prebuilt web/dist. Rebuild only when node is available and the sources changed.
needs_build=0
if [ ! -f "$WEB/dist/index.html" ]; then
  needs_build=1
elif command -v node >/dev/null 2>&1 && [ -f "$WEB/scripts/build-fingerprint.mjs" ]; then
  if ! node "$WEB/scripts/build-fingerprint.mjs" >/dev/null 2>&1; then
    needs_build=1
  fi
fi
if [ "$needs_build" = 1 ]; then
  if command -v npm >/dev/null 2>&1; then
    echo "Building the Frame Lab web app..."
    ( cd "$WEB" && { [ -d node_modules ] || npm ci --ignore-scripts --no-audit --no-fund; } && npm run build >/dev/null )
  elif [ ! -f "$WEB/dist/index.html" ]; then
    echo "web/dist is missing and npm is not installed; install Node.js 20+ or use a release that includes web/dist." >&2
    exit 1
  else
    echo "Web sources changed but npm is not installed; serving the existing web/dist." >&2
  fi
fi

echo "Frame Lab UI -> http://127.0.0.1:${PORT}/  (Ctrl-C to stop)"
# Bash 3.2 on macOS treats expansion of an empty array as unset under nounset.
set +u
exec python3 -B "$HERE/server.py" --port "$PORT" "${SOURCE_ARGS[@]}"
