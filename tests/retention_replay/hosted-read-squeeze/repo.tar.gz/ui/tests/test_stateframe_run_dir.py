"""The UI inspects a run directory exactly as the StateFrame engine writes it (the examples/ sample run)."""
from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

import server  # noqa: E402
from fl_index import journal, runs  # noqa: E402
from fl_index.paths import configure, source_diagnostics  # noqa: E402

_spec = importlib.util.spec_from_file_location("make_sample_run", ROOT / "examples" / "make_sample_run.py")
sample = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sample)


class StateFrameRunDirectoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(configure, demo=True)
        self.runs_root = Path(self.tmp.name) / "runs"
        sample.build(self.runs_root / "discount-fix")

    def test_a_folder_of_runs_is_indexed(self):
        configure(data_root=str(Path(self.tmp.name)))
        self.assertEqual(source_diagnostics()["status"], "ready")
        self.assertEqual([r["id"] for r in runs.list_runs()], ["discount-fix"])

    def test_a_plain_folder_of_run_directories_is_indexed(self):
        # `framelab ui --data DIR` where DIR holds run directories directly, with no runs/ subfolder.
        configure(data_root=str(self.runs_root))
        self.assertEqual(source_diagnostics()["status"], "ready")
        self.assertEqual([r["id"] for r in runs.list_runs()], ["discount-fix"])

    def test_engine_summary_fills_status_result_and_counts(self):
        configure(data_root=str(Path(self.tmp.name)))
        row = runs.list_runs()[0]
        self.assertEqual((row["status"], row["status_source"], row["result"]), ("complete", "summary.json", "PASS"))
        self.assertEqual((row["requests"], row["prompt_tokens"], row["engine_outcome"]), (3, 2820, "done"))

    def test_a_failed_engine_run_is_not_reported_as_complete(self):
        summary = self.runs_root / "discount-fix" / "summary.json"
        summary.write_text('{"succeeded": false, "exit_code": 130, "runtime_outcome": "cancelled", "requests": 2}')
        configure(data_root=str(Path(self.tmp.name)))
        row = runs.list_runs()[0]
        self.assertEqual((row["status"], row["result"], row["engine_outcome"]), ("exit_130", "FAIL", "cancelled"))

    def test_a_single_run_directory_can_be_the_data_root(self):
        configure(data_root=str(self.runs_root / "discount-fix"))
        self.assertEqual([r["id"] for r in runs.list_runs()], ["discount-fix"])
        refs = journal.list_journals(server.resolve("capability", "discount-fix"))
        self.assertEqual(len(refs), 1)
        self.assertIn("worker/measurement-runs/", refs[0]["ref"])
        detail = server._run({"id": "discount-fix"})
        self.assertTrue(detail["journals"])

    def test_the_journal_rows_are_readable(self):
        configure(data_root=str(Path(self.tmp.name)))
        ref = journal.list_journals(server.resolve("capability", "discount-fix"))[0]["ref"]
        rows = server._journal_rows({"id": "discount-fix", "j": ref, "q": "request_submitted"})
        self.assertEqual(rows["matched"], 3)


if __name__ == "__main__":
    unittest.main()
