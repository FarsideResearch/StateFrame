"""P3 evidence-shape, statistical, identity, and provenance regressions."""
import json
import os
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import server  # noqa: E402
from fl_index import experiments, frames, journal, grades  # noqa: E402
from fl_index.paths import configure  # noqa: E402


def jsonl(values):
    return "".join(json.dumps(value) + "\n" for value in values)


class JournalShapeTest(unittest.TestCase):
    def test_scalar_and_malformed_nested_shapes_are_quarantined(self):
        j = journal.Journal([
            json.dumps({"kind": "request_submitted", "request_id": "bad", "payload": {"messages": [None], "tools": "wrong"}}),
            json.dumps({"kind": "response_received", "request_id": "bad", "accounting": [], "response": "wrong"}),
            "42\n",
            "null\n",
        ])
        self.assertEqual(j.event(2)["schema_status"], "invalid_event")
        listed = frames.list_frames(j)
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["attempt_id"], "bad@event-0")
        frame = frames.get_frame(j, listed[0]["attempt_id"])
        self.assertEqual(frame["messages"][0]["role"], "unknown")
        self.assertEqual(frame["schema_status"], "invalid_fields")
        self.assertEqual(frame["response"]["schema_status"], "invalid_object")

    def test_duplicate_request_ids_have_distinct_attempts_and_navigation(self):
        events = [
            {"kind": "request_submitted", "request_id": "same", "payload": {"messages": [], "tools": [{"function": {"name": "inspect", "parameters": {"type": "object", "required": ["old"]}}}], "temperature": 0}},
            {"kind": "response_received", "request_id": "same", "response": {"choices": [{"message": {"content": "one"}}]}},
            {"kind": "request_submitted", "request_id": "same", "payload": {"messages": [], "tools": [{"function": {"name": "inspect", "parameters": {"type": "object", "required": ["new"]}}}], "temperature": 1}},
            {"kind": "response_received", "request_id": "same", "response": {"choices": [{"message": {"content": "two"}}]}},
        ]
        j = journal.Journal([json.dumps(event) + "\n" for event in events])
        listed = frames.list_frames(j)
        self.assertEqual([row["attempt_id"] for row in listed], ["same@event-0", "same@event-2"])
        first = frames.get_frame(j, "same@event-0")
        second = frames.get_frame(j, "same@event-2")
        self.assertEqual(first["next_request_id"], "same@event-2")
        self.assertIsNone(second["next_request_id"])
        self.assertEqual(first["request_payload"]["temperature"], 0)
        self.assertEqual(second["request_payload"]["temperature"], 1)
        self.assertEqual(first["request_payload"]["tools"][0]["function"]["parameters"]["required"], ["old"])
        self.assertEqual(second["request_payload"]["tools"][0]["function"]["parameters"]["required"], ["new"])
        with self.assertRaises(frames.AmbiguousRequestError):
            frames.get_frame(j, "same")


class PointerAndAnalysisTest(unittest.TestCase):
    def test_json_pointer_root_empty_key_escape_and_negative_rejection(self):
        value = {"": "empty", "a/b": {"~key": ["first"]}, "arr": ["zero"]}
        self.assertEqual(experiments.get_pointer(value, ""), value)
        self.assertEqual(experiments.get_pointer(value, "/"), "empty")
        self.assertEqual(experiments.get_pointer(value, "/a~1b/~0key/0"), "first")
        with self.assertRaises(KeyError):
            experiments.get_pointer(value, "/arr/-1")
        self.assertEqual(experiments.find_record_arrays([{"ok": True}])[0]["pointer"], "")

    def test_jsonl_analysis_is_dataset_scoped_on_every_page(self):
        values = [{"arm": "A", "pass": i < 100} for i in range(200)] + [{"arm": "B", "pass": i < 100} for i in range(200)]
        first = server._text_payload("cases.jsonl", jsonl(values), {"offset": "0", "limit": "200"}, 0)
        second = server._text_payload("cases.jsonl", jsonl(values), {"offset": "200", "limit": "200"}, 0)
        self.assertEqual(first["analysis"]["scope"], "dataset")
        self.assertEqual(second["analysis"]["scope"], "dataset")
        rates = {(m["arm"], m["field"]): m["rate"] for m in first["analysis"]["metrics"]}
        self.assertEqual(rates[("A", "pass")], 0.5)
        self.assertEqual(rates[("B", "pass")], 0.5)
        self.assertEqual(rates, {(m["arm"], m["field"]): m["rate"] for m in second["analysis"]["metrics"]})

    def test_unknown_values_are_counted_and_operational_fields_are_not_success_metrics(self):
        result = experiments.analyze_records([
            {"arm": "A", "success": True, "timed_out": True},
            {"arm": "A", "success": None, "timed_out": False},
        ])
        fields = {m["field"] for m in result["metrics"]}
        self.assertEqual(fields, {"success"})
        metric = result["metrics"][0]
        self.assertEqual((metric["k"], metric["eligible"], metric["unknown"]), (1, 1, 1))
        declared = experiments.analyze_records([{"success": None}], {"schema": "stateframe.experiment.v1", "metrics": [{"key": "success"}]})
        self.assertIsNone(declared["metrics"][0]["rate"])

    def test_large_json_values_have_bounded_states_and_mixed_rows_are_safe(self):
        old = experiments.INLINE_JSON_BYTES
        try:
            experiments.INLINE_JSON_BYTES = 8
            array = server._json_payload("values.json", [1, None, "x"], {}, 40)
            self.assertIsNone(array["data"])
            self.assertEqual(array["items"]["rows"][1]["value"], None)
            text = server._json_payload("text.json", "0123456789abcdefghij", {"chunk_limit": "4"}, 40)
            self.assertEqual(text["chunk"]["text"], "0123")
            null_value = server._json_payload("null.json", None, {}, 4)
            self.assertTrue(null_value["has_value"])
            self.assertEqual(null_value["value_type"], "null")
        finally:
            experiments.INLINE_JSON_BYTES = old


class GradeAndManifestTest(unittest.TestCase):
    def test_task_grade_does_not_become_run_grade_without_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, "grades"), exist_ok=True)
            with open(os.path.join(tmp, "grades", "task.graded.json"), "w", encoding="utf-8") as fh:
                json.dump({"task_id": "task-1", "verdict": "FIXED"}, fh)
            configure(data_root=tmp)
            self.assertIsNone(grades.verdict_for_run("different-run"))
            self.assertEqual(grades.task_counts()["fixed"], 1)
            self.assertEqual(grades.proofs()[0]["grade_scope"], "task")
        configure()

    def test_declared_experiment_manifest_is_returned_as_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = os.path.join(tmp, "experiments", "paired")
            os.makedirs(exp)
            with open(os.path.join(exp, "manifest.json"), "w", encoding="utf-8") as fh:
                json.dump({"schema": "stateframe.experiment.v1", "match_keys": ["task_id", "seed"], "metrics": [{"key": "pass", "direction": "maximize"}]}, fh)
            configure(data_root=tmp)
            detail = experiments.experiment_detail("paired")
            self.assertEqual(detail["manifest"]["schema"], "stateframe.experiment.v1")
            self.assertEqual(detail["manifest"]["match_keys"], ["task_id", "seed"])
        configure()


if __name__ == "__main__":
    unittest.main()
