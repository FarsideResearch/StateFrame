"""P6 product-evidence and paired-comparison contracts."""
import json
import os
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import server  # noqa: E402
from fl_index import evidence, frames, journal  # noqa: E402
from fl_index.paths import configure  # noqa: E402


class P6ProductEvidenceTest(unittest.TestCase):
    def tearDown(self):
        configure()

    def test_demo_answers_four_questions_and_links_provenance(self):
        configure(demo=True)
        run = server._run({"id": "demo-stateframe-run"})
        story = run["evidence"]
        self.assertEqual(story["schema"], "stateframe.product_evidence.v1")
        self.assertEqual(story["input"]["model"], "demo-model")
        self.assertEqual(story["action"]["status"], "verified")
        self.assertEqual(story["verification"]["status"], "verified")
        self.assertTrue(story["stop"]["task_success"])
        self.assertEqual(story["stop"]["authority"], "engine")
        self.assertEqual(story["usage"]["input_tokens"], 42)
        self.assertEqual(story["usage"]["output_tokens"], 8)
        self.assertIsNone(story["usage"]["cost_usd"])
        self.assertTrue(story["input"]["evidence"]["query"]["rid"].startswith("demo-request-1@event-"))
        self.assertTrue(story["config"]["files"]["effective"])

    def test_landing_story_keeps_success_and_budget_failure_distinct(self):
        configure(demo=True)
        overview = server._overview({})
        story = overview["product_story"]
        featured = {row["id"]: row for row in story["featured_runs"]}
        self.assertIn("demo-stateframe-run", featured)
        self.assertIn("demo-budget-failure", featured)
        self.assertTrue(featured["demo-stateframe-run"]["task_success"])
        self.assertFalse(featured["demo-budget-failure"]["task_success"])
        self.assertEqual(featured["demo-budget-failure"]["disposition"], "budget_exhausted")

    def test_budget_failure_keeps_its_request_frame_inspectable(self):
        configure(demo=True)
        ref = server._run({"id": "demo-budget-failure"})["journals"][0]["ref"]
        parsed = journal.load_journal(server.resolve("capability", "demo-budget-failure"), ref)
        listed = frames.list_frames(parsed)
        self.assertEqual(len(listed), 1, parsed.rows)
        self.assertIsNotNone(frames.get_frame(parsed, listed[0]["attempt_id"]))
        run = server._run({"id": "demo-budget-failure"})
        self.assertIsNotNone(run["evidence"]["input"], run["evidence"])
        self.assertEqual(run["evidence"]["input"]["model"], "demo-model")

    def test_process_completion_without_engine_stop_stays_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = os.path.join(tmp, "runs", "process-only")
            os.makedirs(os.path.join(run, "run"))
            with open(os.path.join(run, "spec.json"), "w", encoding="utf-8") as fh:
                json.dump({"schema": "stateframe.run.v1"}, fh)
            with open(os.path.join(run, "run", "live-receipt.json"), "w", encoding="utf-8") as fh:
                json.dump({"complete": True, "return_code": 0}, fh)
            configure(data_root=tmp)
            story = evidence.build_run_story("process-only")
            self.assertEqual(story["stop"]["authority"], "process")
            self.assertIsNone(story["stop"]["task_success"])
            self.assertTrue(any(item["code"] == "PROCESS_NOT_TASK_PROOF" for item in story["warnings"]))

    def test_missing_accounting_stays_unknown_instead_of_becoming_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = os.path.join(tmp, "runs", "no-usage")
            os.makedirs(os.path.join(run, "run", "worker", "measurement-runs", "one"))
            with open(os.path.join(run, "spec.json"), "w", encoding="utf-8") as fh:
                json.dump({"schema": "stateframe.run.v1"}, fh)
            with open(os.path.join(run, "run", "live-receipt.json"), "w", encoding="utf-8") as fh:
                json.dump({"complete": True, "return_code": 0}, fh)
            with open(os.path.join(run, "run", "worker", "measurement-runs", "one", "events.jsonl"), "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"kind": "request_submitted", "request_id": "no-usage", "payload": {"messages": [], "tools": []}}) + "\n")
            configure(data_root=tmp)
            story = evidence.build_run_story("no-usage")
            self.assertIsNone(story["usage"]["input_tokens"])
            self.assertIsNone(story["usage"]["output_tokens"])

    def test_paired_demo_comparison_reports_rates_deltas_and_discordant_cases(self):
        configure(demo=True)
        detail = server._experiment({"name": "paired-demo"})
        comparison = detail["comparison"]
        self.assertEqual(comparison["status"], "ready")
        self.assertEqual(comparison["match_keys"], ["task_id", "seed"])
        self.assertEqual(comparison["paired_count"], 4)
        self.assertEqual(comparison["excluded_count"], 0)
        metrics = {metric["key"]: metric for metric in comparison["metrics"]}
        self.assertEqual(metrics["pass"]["arms"]["baseline"]["value"], 0.5)
        self.assertEqual(metrics["pass"]["arms"]["bounded"]["value"], 0.5)
        self.assertLess(metrics["input_tokens"]["delta"], 0)
        self.assertLess(metrics["latency_ms"]["delta"], 0)
        self.assertEqual(len(comparison["discordant"]), 2)
        self.assertIn("demo-stateframe-run", comparison["discordant"][0]["run_links"]["bounded"])


if __name__ == "__main__":
    unittest.main()
