"""P1 source-contract and run-layout regression coverage."""
import io
import json
import os
import sys
import tarfile
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from fl_index import journal, runs  # noqa: E402
from fl_index.paths import configure, source_diagnostics  # noqa: E402
import server  # noqa: E402


EVENT = {"kind": "run_started", "sequence": 0}


def write_json(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(value, fh)


class SourceContractTest(unittest.TestCase):
    def tearDown(self):
        configure()

    def test_missing_data_root_is_healthy_but_not_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            configure(data_root=os.path.join(tmp, "clean-export"))
            health = server._health({})
            self.assertTrue(health["ok"])
            self.assertFalse(health["ready"])
            self.assertEqual(health["source"]["status"], "unavailable")
            self.assertIn("--demo", health["source"]["next_action"])
            self.assertEqual(server._overview({})["counts"]["runs"], 0)

    def test_bundled_demo_is_self_contained_and_nested(self):
        configure(demo=True)
        health = source_diagnostics()
        self.assertEqual(health["status"], "ready")
        self.assertEqual(sorted(row["id"] for row in runs.list_runs()), ["demo-budget-failure", "demo-stateframe-run"])
        meta = runs.run_meta("demo-stateframe-run")
        self.assertTrue(meta["has_worker"])
        self.assertEqual(meta["layout"]["metadata_root"], "run")
        refs = journal.list_journals(server.resolve("capability", "demo-stateframe-run"))
        self.assertEqual(refs[0]["source"], "file")
        self.assertIn("run/worker/", refs[0]["ref"])
        result = server._run({"id": "demo-stateframe-run"})
        self.assertTrue(any(row["name"] == "run/" for row in result["files"]))
        self.assertTrue(result["journals"])
        sidecar = server._run_file({"id": "demo-stateframe-run", "name": "run/effective-config.json"})
        self.assertEqual(sidecar["kind"], "json")

    def test_manifest_accepts_direct_engine_run_and_archive_layout(self):
        with tempfile.TemporaryDirectory() as tmp:
            run_dir = os.path.join(tmp, "engine-run")
            write_json(os.path.join(run_dir, "spec.json"), {"schema": "stateframe.run.v1"})
            write_json(os.path.join(run_dir, "run", "live-receipt.json"), {"complete": True, "return_code": 0})
            events = (json.dumps(EVENT) + "\n").encode()
            os.makedirs(os.path.join(run_dir, "run", "worker"), exist_ok=True)
            with open(os.path.join(run_dir, "run", "worker", "events.jsonl"), "wb") as fh:
                fh.write(events)
            archive = os.path.join(run_dir, "worker.tgz")
            with tarfile.open(archive, "w:gz") as tf:
                info = tarfile.TarInfo("worker/measurement-runs/demo/events.jsonl")
                info.size = len(events)
                tf.addfile(info, io.BytesIO(events))
            manifest = os.path.join(tmp, "sources.json")
            write_json(manifest, {"version": 1, "name": "engine export", "sources": {"runs": run_dir}})

            configure(config_path=manifest)
            self.assertEqual(runs.discover(), ["engine-run"])
            meta = runs.run_meta("engine-run")
            self.assertTrue(meta["has_tgz"])
            self.assertTrue(meta["has_worker"])
            self.assertEqual(len(journal.list_tgz_members(server.resolve("capability", "engine-run"))), 1)
            refs = journal.list_journals(server.resolve("capability", "engine-run"))
            self.assertTrue(any(ref["source"] == "tgz" for ref in refs))
            members = server._run_tgz({"id": "engine-run"})
            self.assertEqual(members["total"], 1)
            preview = server._run_tgz_member({"id": "engine-run", "member": members["members"][0]["name"]})
            self.assertEqual(preview["kind"], "jsonl")


if __name__ == "__main__":
    unittest.main()
