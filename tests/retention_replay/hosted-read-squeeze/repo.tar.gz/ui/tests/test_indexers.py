"""Unit tests for Frame Lab UI indexers (stdlib unittest; no pytest).

Run: cd ui && python3 -B -m unittest discover -s tests -t .
All fixtures live in temp dirs; nothing touches the real lab artifacts.
"""
import io
import json
import os
import sys
import tarfile
import tempfile
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fl_index import frames, journal  # noqa: E402
from fl_index.experiments import analyze_records, find_record_arrays, get_pointer, wilson  # noqa: E402
from fl_index.paths import PathRejected, Root, resolve, safe_member_name  # noqa: E402
from fl_index.redact import MASK, redact, redact_text  # noqa: E402
from fl_index.util import parse_md_tables  # noqa: E402

RID = "r1"
EVENTS = [
    {"kind": "run_started", "sequence": 0},
    {"kind": "tool_menu_composed", "sequence": 1, "available_tools": ["read", "edit"]},
    {"kind": "selection_decision", "sequence": 2, "request_id": RID, "mode": "ENFORCE", "applied": True,
     "view": {"selected": [{"item_id": "a", "text": "hello"}], "omitted": [{"item_id": "b", "reason": "budget"}], "budget_tokens": 10}},
    {"kind": "capacity_preflight", "sequence": 3, "request_id": RID, "prompt_tokens": 120, "fits": True, "context_limit": 1000},
    {"kind": "request_submitted", "sequence": 4, "request_id": RID, "step": 0,
     "payload": {"messages": [{"role": "system", "content": "sys"}, {"role": "user", "content": "do it"}], "tools": [{"function": {"name": "read"}}]}},
    {"kind": "response_received", "sequence": 5, "request_id": RID, "elapsed_ns": 2_000_000_000,
     "accounting": {"prompt_n": 110, "raw_usage": {"completion_tokens": 7}},
     "response": {"choices": [{"finish_reason": "tool_calls", "message": {"content": "", "tool_calls": [{"function": {"name": "read", "arguments": "{}"}}]}}]}},
    {"kind": "test_subprocess_completed", "sequence": 6, "exit_code": 0, "selectors": ["t1"]},
    {"kind": "attempt_terminated", "sequence": 7, "result": {"behaviour": "PASS_behavioural"}},
]


def _jsonl(events):
    return "".join(json.dumps(e) + "\n" for e in events) + "not json\n"


class JournalParseTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.run = self.tmp.name
        d = os.path.join(self.run, "worker", "measurement-runs", "abc")
        os.makedirs(d)
        with open(os.path.join(d, "events.jsonl"), "w") as fh:
            fh.write(_jsonl(EVENTS))

    def tearDown(self):
        self.tmp.cleanup()

    def test_parse_summaries_and_categories(self):
        js = journal.list_journals(self.run)
        self.assertEqual([j["source"] for j in js], ["file"])
        j = journal.load_journal(self.run, js[0]["ref"])
        self.assertEqual(len(j.rows), len(EVENTS) + 1)
        self.assertEqual(j.bad_lines, 1)
        by_kind = {r["kind"]: r for r in j.rows}
        self.assertEqual(by_kind["response_received"]["tokens"], {"prompt": 110, "completion": 7})
        self.assertEqual(by_kind["response_received"]["cat"], "response")
        self.assertEqual(by_kind["request_submitted"]["cat"], "request")
        self.assertEqual(by_kind["test_subprocess_completed"]["cat"], "test")
        self.assertEqual(by_kind["attempt_terminated"]["cat"], "terminal")
        self.assertEqual(by_kind["capacity_preflight"]["tokens"], {"prompt_est": 120})

    def test_frames_join_by_request_id(self):
        j = journal.load_journal(self.run, journal.list_journals(self.run)[0]["ref"])
        fl = frames.list_frames(j)
        self.assertEqual(len(fl), 1)
        self.assertEqual(fl[0]["chars"], len("sys") + len("do it"))
        fr = frames.get_frame(j, RID)
        self.assertEqual(fr["tool_names"], ["read"])
        self.assertEqual(fr["selection"]["omitted"][0]["reason"], "budget")
        self.assertEqual(fr["response"]["finish_reason"], "tool_calls")
        self.assertEqual(fr["tool_menu"]["available_tools"], ["read", "edit"])
        with self.assertRaises(KeyError):
            frames.get_frame(j, "missing")

    def test_rejects_non_journal_and_traversal_refs(self):
        for bad in ("../x/events.jsonl", "/etc/passwd", "worker/spec.json"):
            with self.assertRaises(PathRejected):
                journal.load_journal(self.run, bad)


class TgzStreamingTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.run = self.tmp.name
        data = _jsonl(EVENTS).encode()
        with tarfile.open(os.path.join(self.run, "worker.tgz"), "w:gz") as tf:
            for name, payload in (("worker/measurement-runs/zz/events.jsonl", data), ("worker/candidates/0001.json", b"{}")):
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                tf.addfile(info, io.BytesIO(payload))

    def tearDown(self):
        self.tmp.cleanup()

    def test_streams_member_without_extracting(self):
        before = sorted(os.listdir(self.run))
        js = journal.list_journals(self.run)
        self.assertEqual(js, [{"ref": "tgz:worker/measurement-runs/zz/events.jsonl", "size": len(_jsonl(EVENTS).encode()), "source": "tgz"}])
        j = journal.load_journal(self.run, js[0]["ref"])
        self.assertEqual(j.rows[4]["kind"], "request_submitted")
        self.assertEqual(sorted(os.listdir(self.run)), before, "tgz must never be extracted to disk")

    def test_member_read_and_rejections(self):
        tgz = os.path.join(self.run, "worker.tgz")
        self.assertEqual(journal.read_tar_member(tgz, "worker/candidates/0001.json"), b"{}")
        with self.assertRaises(FileNotFoundError):
            journal.read_tar_member(tgz, "worker/nope.json")
        for bad in ("../evil", "/abs/path", "a/../../b", "", "x\x00y"):
            with self.assertRaises(PathRejected):
                safe_member_name(bad)
        with self.assertRaises(PathRejected):  # only journal members may be loaded as journals
            journal.load_journal(self.run, "tgz:worker/candidates/0001.json")
        with self.assertRaises(ValueError):
            journal.read_tar_member(tgz, "worker/measurement-runs/zz/events.jsonl", max_bytes=10)


class TraversalTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = os.path.realpath(self.tmp.name)
        self.inside = os.path.join(base, "root")
        os.makedirs(os.path.join(self.inside, "sub"))
        with open(os.path.join(base, "secret.txt"), "w") as fh:
            fh.write("x")
        os.symlink(os.path.join(base, "secret.txt"), os.path.join(self.inside, "escape"))
        self.rmap = {"r": Root("r", self.inside), "f": Root("f", os.path.join(base, "secret.txt"), True)}

    def tearDown(self):
        self.tmp.cleanup()

    def test_allows_inside(self):
        self.assertEqual(resolve("r", "sub", self.rmap), os.path.join(self.inside, "sub"))
        self.assertEqual(resolve("r", "", self.rmap), self.inside)

    def test_rejects_escapes(self):
        for rel in ("../secret.txt", "sub/../../secret.txt", "/etc/passwd", "escape", "a\x00b", "..\\secret.txt"):
            with self.assertRaises(PathRejected, msg=rel):
                resolve("r", rel, self.rmap)
        with self.assertRaises(PathRejected):
            resolve("unknown", "", self.rmap)
        with self.assertRaises(PathRejected):
            resolve("f", "child", self.rmap)


class RedactionTest(unittest.TestCase):
    def test_masks_secret_values_and_keys(self):
        fake = "sk-" + "a" * 30
        obj = {"api_key": "plainvalue123", "tokenizer": "keep-me", "prompt_tokens": 5,
               "note": f"use {fake} now", "url": "postgresql://u:hunter22@host/db",
               "hdr": "Authorization: Bearer abcdefghijklmnop"}
        out = redact(obj)
        self.assertEqual(out["api_key"], MASK)
        self.assertEqual(out["tokenizer"], "keep-me")
        self.assertEqual(out["prompt_tokens"], 5)
        self.assertNotIn(fake, out["note"])
        self.assertNotIn("hunter22", out["url"])
        self.assertNotIn("abcdefghijklmnop", out["hdr"])
        self.assertEqual(redact_text("AKIA" + "A" * 16), MASK)
        # regression: ids containing "-task-" must not be mistaken for sk- keys
        ep = "expert-20261004-task-sample-13-import-order"
        self.assertEqual(redact_text(ep), ep)


class AnalysisTest(unittest.TestCase):
    def test_md_tables(self):
        md = "# H\n\n| a | b |\n|---|:--:|\n| 1 | x |\n| 2 | y |\n\ntext"
        t = parse_md_tables(md)
        self.assertEqual(t[0]["header"], ["a", "b"])
        self.assertEqual(t[0]["rows"], [["1", "x"], ["2", "y"]])
        self.assertEqual(t[0]["heading"], "H")

    def test_records_and_wilson(self):
        data = {"meta": {"x": 1}, "records": [{"arm": "A", "pass": True}, {"arm": "A", "pass": False}, {"arm": "B", "pass": "PASS"}]}
        arrays = find_record_arrays(data)
        self.assertEqual(arrays, [{"pointer": "/records", "length": 3}])
        a = analyze_records(get_pointer(data, "/records"))
        self.assertEqual(a["arm_key"], "arm")
        m = {(x["arm"], x["field"]): x for x in a["metrics"]}
        self.assertEqual((m[("A", "pass")]["k"], m[("A", "pass")]["n"]), (1, 2))
        lo, hi = wilson(5, 10)
        self.assertAlmostEqual(lo, 0.2366, places=3)
        self.assertAlmostEqual(hi, 0.7634, places=3)
        self.assertEqual(wilson(0, 0), (0.0, 0.0))


if __name__ == "__main__":
    unittest.main()
