"""N3 regression coverage for shared contracts and Markdown table parity."""
import os
import sys
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import server  # noqa: E402
from fl_index import journal, paths  # noqa: E402
from fl_index.util import parse_md_tables  # noqa: E402


MARKDOWN = r"""# Evidence

```markdown
# Example, not data
| fake | table |
| --- | --- |
| should | be ignored |
```

| Field | Value | Notes |
| --- | :---: | --- |
| `prompt_tokens` | **50%** | left \| right |
| path | C:\\tmp | [visible link](https://example.test) |

~~~text
| another | example |
| --- | --- |
| ignored | too |
~~~
"""


class MarkdownTableContractTest(unittest.TestCase):
    def test_fenced_examples_are_not_data_and_supported_inline_syntax_is_normalized(self):
        tables = parse_md_tables(MARKDOWN)

        self.assertEqual(len(tables), 1)
        table = tables[0]
        self.assertEqual(table["heading"], "Evidence")
        self.assertEqual(table["header"], ["Field", "Value", "Notes"])
        self.assertEqual(table["rows"][0], ["prompt_tokens", "50%", "left | right"])
        self.assertEqual(table["rows"][1][1], r"C:\tmp")
        self.assertEqual(table["rows"][1][2], "[visible link](https://example.test)")
        self.assertGreater(table["line"], 6)

    def test_server_markdown_payload_uses_the_same_table_projection(self):
        payload = server._text_payload("report.md", MARKDOWN, {})
        self.assertEqual(payload["tables"], parse_md_tables(MARKDOWN))
        self.assertEqual(len(payload["tables"]), 1)

    def test_verified_dead_helpers_are_not_retained(self):
        self.assertFalse(hasattr(paths, "rel_to"))
        self.assertFalse(hasattr(journal.Journal, "parsed_iter"))


if __name__ == "__main__":
    unittest.main()
