"""The UI server is read only: GET and HEAD are served, every method that could change something is refused."""
from __future__ import annotations

import http.client
import json
import sys
import threading
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

import server  # noqa: E402
from fl_index.paths import configure  # noqa: E402


class ReadOnlyServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        configure(demo=True)
        cls.httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.FrameLabHandler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def request(self, method, path, body=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        try:
            headers = {"Host": "127.0.0.1", "Content-Type": "application/json", "Origin": f"http://127.0.0.1:{self.port}"}
            conn.request(method, path, body=json.dumps(body) if body is not None else None, headers=headers)
            reply = conn.getresponse()
            return reply.status, reply.read()
        finally:
            conn.close()

    def test_reads_are_served(self):
        status, body = self.request("GET", "/api/health")
        self.assertEqual(status, 200)
        self.assertNotIn("control_enabled", json.loads(body))
        self.assertEqual(self.request("HEAD", "/api/runs")[0], 200)

    def test_every_write_method_is_refused(self):
        for method in ("POST", "PUT", "DELETE", "PATCH"):
            for path in ("/api/runs", "/api/lab/drafts", "/api/lab/session"):
                status, body = self.request(method, path, {"token": "x" * 32})
                self.assertEqual(status, 405, (method, path))
                self.assertEqual(json.loads(body)["code"], "READ_ONLY")

    def test_no_workspace_api_remains(self):
        for path in ("/api/lab/overview", "/api/lab/exports", "/api/lab/exports/a/file/b"):
            self.assertEqual(self.request("GET", path)[0], 404, path)


if __name__ == "__main__":
    unittest.main()
