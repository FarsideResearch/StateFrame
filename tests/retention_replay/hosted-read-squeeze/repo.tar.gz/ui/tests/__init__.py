"""Frame Lab UI unittest package."""
