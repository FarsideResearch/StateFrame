"""P2 confidentiality, containment, archive-budget, and HTTP regressions."""
import http.client
import io
import json
import os
import sys
import tarfile
import tempfile
import threading
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import server  # noqa: E402
from fl_index import docs, journal, runs  # noqa: E402
from fl_index.paths import PathRejected, configure, resolve  # noqa: E402
from fl_index.redact import MASK, redact, redact_text  # noqa: E402
from fl_index.util import open_regular  # noqa: E402


def write_json(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(value, fh)


class RedactionPolicyTest(unittest.TestCase):
    def test_nested_quoted_serialized_and_identifier_values_are_projected(self):
        marker = "SYNTHETIC_SECRET_123"
        value = {
            "credentials": {"value": marker},
            "token": [marker],
            "payload": '{"api_key":"' + marker + '"}',
            "shell": 'API_KEY="' + marker + '" password: x',
            "email": "synthetic.person@example.test",
            "path": "/private/tmp/synthetic-workspace/report.json",
            "request_id": "supported-run-123",
        }
        projected = redact(value)
        encoded = json.dumps(projected)
        self.assertNotIn(marker, encoded)
        self.assertEqual(projected["credentials"], MASK)
        self.assertEqual(projected["token"], MASK)
        self.assertNotIn("synthetic.person@example.test", encoded)
        self.assertNotIn("/private/tmp/synthetic-workspace", encoded)
        self.assertEqual(projected["request_id"], "supported-run-123")

    def test_search_projection_does_not_match_raw_secret_text(self):
        marker = "SYNTHETIC_SECRET_SEARCH"
        self.assertNotIn(marker, redact_text('{"api_key":"' + marker + '"}'))
        self.assertIsNone(redact({"value": float("nan")})["value"])
        with self.assertRaises(ValueError):
            server._text_payload("invalid.json", "{not-json", {}, 9)


class IndexedContainmentTest(unittest.TestCase):
    def tearDown(self):
        configure()

    def test_indexed_sidecars_and_document_symlinks_do_not_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            export = os.path.join(tmp, "export")
            run = os.path.join(export, "runs", "safe-run")
            outside = os.path.join(tmp, "outside")
            os.makedirs(os.path.join(run, "run"), exist_ok=True)
            os.makedirs(os.path.join(export, "experiments", "exp"), exist_ok=True)
            os.makedirs(os.path.join(export, "grades"), exist_ok=True)
            write_json(os.path.join(run, "spec.json"), {"schema": "stateframe.run.v1"})
            os.makedirs(os.path.join(run, "worker", "measurement-runs", "a"), exist_ok=True)
            with open(os.path.join(run, "worker", "measurement-runs", "a", "events.jsonl"), "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"kind": "request_submitted", "payload": {"api_key": "SYNTHETIC_SECRET_OUTSIDE"}}) + "\n")
            write_json(os.path.join(outside, "completion.json"), {"complete": True})
            os.makedirs(outside, exist_ok=True)
            # The target is created after the parent so the fixture works on
            # filesystems that do not permit dangling links during setup.
            os.symlink(os.path.join(outside, "completion.json"), os.path.join(run, "run", "completion.json"))
            with open(os.path.join(outside, "report.md"), "w", encoding="utf-8") as fh:
                fh.write("SYNTHETIC_SECRET_OUTSIDE")
            with self.assertRaises(OSError):
                with open_regular(os.path.join(run, "run", "completion.json"), "r", encoding="utf-8"):
                    pass
            os.symlink(os.path.join(outside, "report.md"), os.path.join(export, "grades", "escape_REPORT.md"))
            os.symlink(os.path.join(outside, "report.md"), os.path.join(export, "experiments", "exp", "RESULTS.md"))
            os.symlink(os.path.join(outside, "report.md"), os.path.join(export, "grades", "escape.json"))

            configure(data_root=export)
            self.assertEqual(docs.grades_docs(), [])
            self.assertEqual(runs.list_runs()[0]["status"], "index_error")
            self.assertEqual(server._journal_rows({"id": "safe-run", "j": "worker/measurement-runs/a/events.jsonl", "q": "SYNTHETIC_SECRET_OUTSIDE"})["matched"], 0)
            with self.assertRaises(PathRejected):
                server._file({"root": "grades", "path": "escape.json"})
            self.assertNotIn("SYNTHETIC_SECRET_OUTSIDE", json.dumps(server._overview({})))


class ArchiveBudgetTest(unittest.TestCase):
    def _archive(self, tmp, members, filename="worker.tgz"):
        path = os.path.join(tmp, filename)
        with tarfile.open(path, "w:gz") as tf:
            for name, payload in members:
                info = tarfile.TarInfo(name)
                if isinstance(payload, tuple):
                    info.type, info.linkname = payload
                    tf.addfile(info)
                else:
                    data = payload.encode("utf-8")
                    info.size = len(data)
                    tf.addfile(info, io.BytesIO(data))
        return path

    def test_journal_archive_obeys_small_byte_and_line_caps(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._archive(tmp, [("worker/measurement-runs/a/events.jsonl", '{"kind":"x"}\n')])
            old_bytes, old_lines = journal.MAX_JOURNAL_BYTES, journal.MAX_JOURNAL_LINES
            try:
                journal.MAX_JOURNAL_BYTES = 1
                with self.assertRaises(journal.ArchiveLimitError):
                    journal.load_journal(tmp, "tgz:worker/measurement-runs/a/events.jsonl")
                journal.MAX_JOURNAL_BYTES = 1024
                journal.MAX_JOURNAL_LINES = 0
                with self.assertRaises(journal.ArchiveLimitError):
                    journal.load_journal(tmp, "tgz:worker/measurement-runs/a/events.jsonl")
            finally:
                journal.MAX_JOURNAL_BYTES, journal.MAX_JOURNAL_LINES = old_bytes, old_lines

    def test_archive_listing_rejects_non_regular_members_and_total_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._archive(tmp, [
                ("worker/link.json", (tarfile.SYMTYPE, "../../outside")),
                ("worker/hard.json", (tarfile.LNKTYPE, "worker/other.json")),
                ("worker/other.json", "1234567890"),
            ])
            old_total = journal.MAX_ARCHIVE_TOTAL_BYTES
            try:
                journal.MAX_ARCHIVE_TOTAL_BYTES = 100
                self.assertEqual(journal.list_tgz_members(tmp), [{"name": "worker/other.json", "size": 10, "file": True}])
                journal.MAX_ARCHIVE_TOTAL_BYTES = 5
                isolated = os.path.join(tmp, "isolated")
                os.makedirs(isolated)
                self._archive(isolated, [("worker/other-2.json", "1234567890")])
                with self.assertRaises(journal.ArchiveLimitError):
                    journal.list_tgz_members(isolated)
            finally:
                journal.MAX_ARCHIVE_TOTAL_BYTES = old_total
            with self.assertRaises(PathRejected):
                journal.read_tar_member(path, "worker/link.json")


class HttpBoundaryTest(unittest.TestCase):
    def test_errors_are_stable_and_security_headers_are_present(self):
        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.FrameLabHandler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(lambda: (httpd.shutdown(), httpd.server_close(), thread.join(timeout=2)))
        conn = http.client.HTTPConnection("127.0.0.1", httpd.server_port, timeout=3)
        conn.request("GET", "/api/file?root=grades&path=../../synthetic-secret.json")
        response = conn.getresponse()
        body = response.read().decode("utf-8")
        self.assertEqual(response.status, 403)
        self.assertIn("Content-Security-Policy", response.headers)
        self.assertEqual(response.headers.get("X-FrameLab-Projection"), "redacted")
        self.assertEqual(response.headers.get("Access-Control-Allow-Origin"), None)
        self.assertRegex(response.headers.get("X-FrameLab-Request-ID", ""), r"^[0-9a-f]{16}$")
        self.assertNotIn("synthetic-secret.json", body)
        self.assertIn('"code":"PATH_REJECTED"', body)
        conn.close()


if __name__ == "__main__":
    unittest.main()
