"""P5 HTTP response contract regression coverage without starting a server."""
import io
import os
import sys
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from server import FrameLabHandler  # noqa: E402


class FakeHandler:
    def __init__(self, command):
        self.command = command
        self.headers = {}
        self.wfile = io.BytesIO()
        self.sent = []

    def send_response(self, code):
        self.sent.append(("status", code))

    def send_header(self, name, value):
        self.sent.append((name, value))

    def end_headers(self):
        self.sent.append(("end", None))


class P5ResponseContractTest(unittest.TestCase):
    def test_get_and_head_keep_accessibility_and_offline_security_headers(self):
        for command, expected_body in (("GET", b"body"), ("HEAD", b"")):
            handler = FakeHandler(command)
            FrameLabHandler._send(handler, 200, b"body", "text/html; charset=utf-8")
            headers = dict((name, value) for name, value in handler.sent if name not in {"status", "end"})
            self.assertEqual(handler.wfile.getvalue(), expected_body)
            self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
            self.assertEqual(headers["X-Frame-Options"], "DENY")
            self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])
            self.assertIn("font-src 'self'", headers["Content-Security-Policy"])
            self.assertEqual(headers["X-FrameLab-Projection"], "redacted")


if __name__ == "__main__":
    unittest.main()
