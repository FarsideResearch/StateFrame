"""P4 inspection-state API contracts; all fixtures are isolated temp exports."""
import io
import json
import os
import re
import sys
import tarfile
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import server  # noqa: E402
from fl_index.paths import configure, roots, source_diagnostics  # noqa: E402


def write_json(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(value, fh)


class P4InspectionApiTest(unittest.TestCase):
    def tearDown(self):
        configure()

    def test_experiments_root_is_canonical_and_legacy_manifest_key_is_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = os.path.join(tmp, "experiments")
            os.makedirs(os.path.join(exp, "paired-demo"))
            manifest = os.path.join(tmp, "sources.json")
            for key in ("experiments", "frame" + "_lab"):
                value = {"version": 1, "sources": {key: exp}}
                write_json(manifest, value)
                with open(os.path.join(HERE, "schemas", "source-manifest.schema.json"), encoding="utf-8") as fh:
                    schema = json.load(fh)
                source_schema = schema["properties"]["sources"]
                allowed = key in source_schema["properties"] or any(re.fullmatch(pattern, key) for pattern in source_schema["patternProperties"])
                self.assertTrue(allowed, f"schema rejects source key {key}")
                self.assertFalse(source_schema["additionalProperties"])
                self.assertFalse(any(re.fullmatch(pattern, "frame" + "-lab") for pattern in source_schema["patternProperties"]))
                if key != "experiments":
                    self.assertTrue(next(iter(source_schema["patternProperties"].values()))["deprecated"])
                configure(config_path=manifest)
                self.assertIn("experiments", roots())
                if key != "experiments":
                    self.assertNotIn(key, roots())
                self.assertIn("experiments", server._health({})["roots"])
                self.assertIn("experiments", [item["key"] for item in source_diagnostics()["sources"]])
                canonical = server._file({"root": "experiments", "path": "paired-demo"})
                legacy = server._file({"root": "frame" + "_lab", "path": "paired-demo"})
                self.assertEqual(legacy, canonical)


    def test_generic_directory_and_experiment_files_have_continuations(self):
        with tempfile.TemporaryDirectory() as tmp:
            export = os.path.join(tmp, "export")
            exp = os.path.join(export, "experiments", "demo")
            os.makedirs(exp)
            for name in ("RESULTS.md", "a.json", "b.json", "c.json"):
                with open(os.path.join(exp, name), "w", encoding="utf-8") as fh:
                    fh.write("# result\n" if name.endswith(".md") else "{}")
            write_json(os.path.join(tmp, "sources.json"), {"version": 1, "sources": {"experiments": os.path.join(export, "experiments")}})
            configure(config_path=os.path.join(tmp, "sources.json"))

            directory = server._file({"root": "experiments", "path": "demo", "offset": "1", "limit": "2"})
            self.assertEqual(directory["total"], 4)
            self.assertTrue(directory["has_more"])
            self.assertEqual(directory["next_offset"], 3)

            detail = server._experiment({"name": "demo", "offset": "1", "limit": "2"})
            self.assertEqual(detail["files_total"], 4)
            self.assertTrue(detail["files_has_more"])
            self.assertEqual(len(detail["files"]), 2)

    def test_archive_members_and_frame_search_return_scope_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = os.path.join(tmp, "runs", "r1")
            journal_dir = os.path.join(run, "worker", "measurement-runs", "sample")
            os.makedirs(journal_dir)
            events = [
                {"kind": "request_submitted", "request_id": "request-1", "payload": {"messages": [{"role": "user", "content": "request marker"}], "tools": []}},
                {"kind": "response_received", "request_id": "request-1", "response": {"choices": [{"message": {"content": "response marker"}}]}},
            ]
            raw = ("\n".join(json.dumps(e) for e in events) + "\n").encode()
            with open(os.path.join(journal_dir, "events.jsonl"), "wb") as fh:
                fh.write(raw)
            archive = os.path.join(run, "worker.tgz")
            with tarfile.open(archive, "w:gz") as tf:
                info = tarfile.TarInfo("worker/measurement-runs/sample/events.jsonl")
                info.size = len(raw)
                tf.addfile(info, io.BytesIO(raw))
            write_json(os.path.join(run, "spec.json"), {"schema": "stateframe.run.v1"})
            write_json(os.path.join(tmp, "sources.json"), {"version": 1, "sources": {"runs": os.path.join(tmp, "runs")}})
            configure(config_path=os.path.join(tmp, "sources.json"))

            members = server._run_tgz({"id": "r1", "offset": "0", "limit": "1"})
            self.assertEqual(members["total"], 1)
            self.assertFalse(members["has_more"])
            ref = server._run({"id": "r1"})["journals"][0]["ref"]
            result = server._frames_search({"id": "r1", "j": ref, "q": "response marker", "scope": "response"})
            self.assertEqual(result["scope"], "response")
            self.assertEqual(result["total"], 1)
            self.assertIn("response", result["results"][0]["scopes"])


if __name__ == "__main__":
    unittest.main()
