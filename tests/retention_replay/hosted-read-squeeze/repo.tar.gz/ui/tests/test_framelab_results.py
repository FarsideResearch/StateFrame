"""Results written by `framelab run --out experiments/<name>/RESULTS.json` appear in the Experiments view."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "src"))

from fl_index import experiments  # noqa: E402
from fl_index.paths import configure  # noqa: E402
from framelab.experiment import execute, extract_base, render_markdown  # noqa: E402
from framelab.scoring import load_scorer  # noqa: E402
from framelab.variants import load_variants  # noqa: E402

_spec = importlib.util.spec_from_file_location("make_sample_run", ROOT / "examples" / "make_sample_run.py")
sample = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sample)


def _reply(body, url, timeout_s):
    names = [t["function"]["name"] for t in body.get("tools", [])]
    tool = "replace_in_file" if names == ["read_file", "replace_in_file"] else "read_file"
    arguments = {"path": "pricing.py", "old": "x", "new": "discount / 100"}
    return {"elapsed_ns": 1_000_000, "response": {"choices": [{"finish_reason": "tool_calls", "message": {
        "role": "assistant", "content": None,
        "tool_calls": [{"id": "c", "type": "function", "function": {"name": tool, "arguments": json.dumps(arguments)}}]}}]}}


class FramelabResultsInUiTest(unittest.TestCase):
    def test_a_run_result_folder_is_listed_and_its_variants_are_readable(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            journal = sample.build(root / "runs" / "discount-fix")
            base = extract_base(journal, "step:1")
            result = execute(base, load_variants(ROOT / "examples" / "variants.json"),
                             load_scorer(ROOT / "examples" / "scorer.json"),
                             url="http://127.0.0.1:1/v1/chat/completions", n=2, send=_reply)
            out = root / "experiments" / "tool-menu"
            out.mkdir(parents=True)
            (out / "RESULTS.json").write_text(json.dumps(result))
            (out / "RESULTS.md").write_text(render_markdown(result, "Tool menu"))
            self.addCleanup(configure, demo=True)
            configure(data_root=str(root))
            rows = experiments.list_experiments()
            self.assertEqual([(r["name"], r["title"], r["has_results_json"]) for r in rows], [("tool-menu", "Tool menu", True)])
            detail = experiments.experiment_detail("tool-menu", 0, 200, "")
            text = json.dumps(detail)
            self.assertIn("edit-tools-only", text)
            self.assertIn("2/2", text)


if __name__ == "__main__":
    unittest.main()
