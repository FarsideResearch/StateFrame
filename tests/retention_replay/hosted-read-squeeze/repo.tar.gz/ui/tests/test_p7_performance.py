"""P7 bounded-work, static recovery, and release qualification contracts."""
import io
import json
import os
import sys
import tempfile
import threading
import unittest

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import server  # noqa: E402
from fl_index import frames, journal  # noqa: E402
from fl_index.paths import configure  # noqa: E402
from fl_index.util import TTLCache  # noqa: E402


class FakeHandler:
    def __init__(self, command="GET"):
        self.command = command
        self.headers = {}
        self.wfile = io.BytesIO()
        self.sent = []

    def send_response(self, code):
        self.sent.append(("status", code))

    def send_header(self, name, value):
        self.sent.append((name, value))

    def end_headers(self):
        self.sent.append(("end", None))

    def _send(self, *args, **kwargs):
        return server.FrameLabHandler._send(self, *args, **kwargs)

    def _error(self, *args, **kwargs):
        return server.FrameLabHandler._error(self, *args, **kwargs)

    def _json(self, *args, **kwargs):
        return server.FrameLabHandler._json(self, *args, **kwargs)


class P7PerformanceTest(unittest.TestCase):
    def tearDown(self):
        configure()

    def test_ttl_cache_is_bounded_and_single_flight(self):
        cache = TTLCache(60, max_entries=2, byte_cap=10, weight_fn=len)
        started = threading.Event()
        release = threading.Event()
        calls = 0
        calls_lock = threading.Lock()

        def build():
            nonlocal calls
            with calls_lock:
                calls += 1
            started.set()
            release.wait(2)
            return "1234"

        values = []
        workers = [threading.Thread(target=lambda: values.append(cache.get_or("same", build))) for _ in range(4)]
        for worker in workers:
            worker.start()
        self.assertTrue(started.wait(1))
        release.set()
        for worker in workers:
            worker.join(2)
        self.assertEqual(values, ["1234"] * 4)
        self.assertEqual(calls, 1)
        cache.get_or("one", lambda: "12")
        cache.get_or("two", lambda: "34")
        cache.get_or("three", lambda: "56")
        self.assertLessEqual(cache.stats()["entries"], 2)
        self.assertLessEqual(cache.stats()["bytes"], 10)

    def test_frame_indexes_are_memoized_per_loaded_journal(self):
        line = json.dumps({
            "kind": "request_submitted",
            "request_id": "p7-request",
            "payload": {"messages": [{"role": "user", "content": "bounded"}], "tools": []},
        })
        parsed = journal.Journal([line])
        first = frames.list_frames(parsed)
        second = frames.list_frames(parsed)
        self.assertIs(first, second)
        self.assertIn("request_index", parsed._memo)
        self.assertEqual(parsed._memo["request_index"][0][0]["attempt_id"], "p7-request@event-0")

    def test_journal_endpoint_returns_bounded_pages_and_continuation(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = os.path.join(tmp, "runs", "p7-run", "run", "worker", "measurement-runs", "one")
            os.makedirs(run)
            with open(os.path.join(tmp, "runs", "p7-run", "spec.json"), "w", encoding="utf-8") as fh:
                json.dump({"schema": "stateframe.run.v1"}, fh)
            with open(os.path.join(run, "events.jsonl"), "w", encoding="utf-8") as fh:
                for i in range(3):
                    fh.write(json.dumps({"kind": "run_started", "sequence": i}) + "\n")
            configure(data_root=tmp)
            ref = journal.list_journals(server.resolve("capability", "p7-run"))[0]["ref"]
            result = server._journal_rows({"id": "p7-run", "j": ref, "offset": "0", "limit": "2"})
            self.assertEqual(len(result["rows"]), 2)
            self.assertEqual(result["matched"], 3)
            self.assertTrue(result["has_more"])
            self.assertEqual(result["next_offset"], 2)

    def test_health_exposes_active_payload_and_cache_budgets(self):
        configure(demo=True)
        health = server._health({})
        self.assertGreater(health["budgets"]["max_response_bytes"], 0)
        self.assertIn("byte_cap", health["budgets"]["artifact_cache"])
        self.assertIn("journals", health["budgets"]["journal_cache"])

    def test_missing_static_asset_is_not_spa_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "index.html"), "wb") as fh:
                fh.write(b"shell")
            previous = server.DIST
            server.DIST = tmp
            try:
                handler = FakeHandler()
                server.FrameLabHandler._static(handler, "/assets/missing.js")
                self.assertEqual(dict(handler.sent)["status"], 404)
                deep = FakeHandler()
                server.FrameLabHandler._static(deep, "/run")
                self.assertEqual(dict(deep.sent)["status"], 200)
                self.assertEqual(deep.wfile.getvalue(), b"shell")
            finally:
                server.DIST = previous

    def test_http_payload_limit_returns_stable_recovery_error(self):
        previous = server.MAX_HTTP_RESPONSE_BYTES
        server.MAX_HTTP_RESPONSE_BYTES = 8
        try:
            handler = FakeHandler()
            server.FrameLabHandler._json(handler, 200, {"payload": "too large"}, "p7-request")
            self.assertEqual(dict(handler.sent)["status"], 413)
            body = json.loads(handler.wfile.getvalue())
            self.assertEqual(body["code"], "RESPONSE_LIMIT")
        finally:
            server.MAX_HTTP_RESPONSE_BYTES = previous


if __name__ == "__main__":
    unittest.main()
