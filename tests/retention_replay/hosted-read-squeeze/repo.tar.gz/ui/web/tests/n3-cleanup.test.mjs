import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { compareMissingLast, sortByField } from '../src/sort-utils.js'

const root = new URL('../', import.meta.url)
const source = (name) => readFile(new URL(name, root), 'utf8')

test('N3 shared sorter keeps missing values last in both directions', () => {
  const rows = [
    { id: 'run-10', value: 10 },
    { id: 'run-2', value: 2 },
    { id: 'unknown', value: null },
  ]
  assert.deepEqual(sortByField(rows, 'value').map((row) => row.id), ['run-2', 'run-10', 'unknown'])
  assert.deepEqual(sortByField(rows, 'value', true).map((row) => row.id), ['run-10', 'run-2', 'unknown'])
  assert.equal(compareMissingLast('', 1), 1)
  assert.equal(compareMissingLast(1, '', true), -1)
  assert.deepEqual(rows.map((row) => row.id), ['run-10', 'run-2', 'unknown'])
})

test('N3 list views share the sorter and no longer carry duplicate comparators', async () => {
  const runs = await source('src/views/RunsView.vue')
  const experiments = await source('src/views/ExperimentsView.vue')
  assert.match(runs, /sort-utils\.js/)
  assert.match(experiments, /sort-utils\.js/)
  assert.doesNotMatch(runs, /function compare\(/)
  assert.doesNotMatch(experiments, /function compare\(/)
  assert.match(runs, /field: 'run_verdict'/)
})

test('N3 shared API and visual contracts have one owner', async () => {
  const contracts = await source('src/api-contracts.js')
  const api = await source('src/api.js')
  const styles = await source('src/styles.css')
  const timeline = await source('src/components/TimelinePanel.vue')
  const tokens = await source('src/tokens.css')
  const diff = await source('src/components/DiffView.vue')
  assert.match(contracts, /@typedef \{Object\} ApiErrorEnvelope/)
  assert.match(contracts, /API_CONTRACT_VERSION/)
  assert.match(api, /api-contracts\.js/)
  assert.equal((styles.match(/\.cat-dot\s*\{/g) || []).length, 1)
  assert.doesNotMatch(timeline, /\.cat-dot\s*\{/)
  assert.doesNotMatch(tokens, /--fl-c-primary-strong/)
  assert.match(diff, /Compare line strings/)
})
