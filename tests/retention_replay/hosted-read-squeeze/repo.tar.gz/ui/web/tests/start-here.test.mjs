import test from 'node:test'
import assert from 'node:assert/strict'
import { readStartHereDismissed, saveStartHereDismissed, START_HERE_KEY } from '../src/start-here-state.js'

test('demo guide dismissal survives reload and storage errors', () => {
  const values = new Map()
  const storage = { getItem: (key) => values.get(key), setItem: (key, value) => values.set(key, value) }
  assert.equal(readStartHereDismissed(storage), false)
  saveStartHereDismissed(storage)
  assert.equal(values.get(START_HERE_KEY), '1')
  assert.equal(readStartHereDismissed(storage), true)
  const denied = { getItem() { throw new Error('denied') }, setItem() { throw new Error('denied') } }
  assert.equal(readStartHereDismissed(denied), false)
  assert.doesNotThrow(() => saveStartHereDismissed(denied))
})
