import test from 'node:test'
import assert from 'node:assert/strict'
import { sourceState } from '../src/source-state.js'

test('source state gives a useful clean-install action', () => {
  assert.deepEqual(sourceState({ status: 'unavailable', ready: false }), {
    tone: 'warning',
    title: 'No data connected',
    action: 'Start with framelab ui --data PATH/TO/RUNS.',
  })
})

test('source state preserves truthful partial and invalid diagnostics', () => {
  assert.equal(sourceState({ status: 'partial' }).tone, 'warning')
  assert.equal(sourceState({ status: 'invalid' }).tone, 'error')
  assert.equal(sourceState({ status: 'ready' }).title, 'Data ready')
  assert.equal(sourceState({ status: 'ready', mode: 'demo' }).title, 'Demo data ready')
})
