import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const root = new URL('../', import.meta.url)
const source = (name) => readFile(new URL(name, root), 'utf8')

function tokenValue(css, name) {
  const match = css.match(new RegExp(`--${name}:\\s*([^;]+);`))
  assert.ok(match, `missing token --${name}`)
  return match[1].trim()
}

function resolveToken(css, value) {
  let current = value
  for (let i = 0; i < 8 && current.startsWith('var('); i += 1) {
    const name = current.slice(4, -1).trim().replace(/^--/, '')
    current = tokenValue(css, name)
  }
  return current
}

function luminance(hex) {
  const rgb = [0, 2, 4].map((offset) => Number.parseInt(hex.slice(offset + 1, offset + 3), 16) / 255)
  return rgb.reduce((sum, channel, index) => sum + (channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4) * [0.2126, 0.7152, 0.0722][index], 0)
}

function contrast(a, b) {
  const [light, dark] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (light + 0.05) / (dark + 0.05)
}

test('P5 semantic status and control tokens meet normal-text contrast', async () => {
  const css = await source('src/tokens.css')
  const paper = resolveToken(css, tokenValue(css, 'fs-surface'))
  const inkSoft = resolveToken(css, tokenValue(css, 'fs-black-soft'))
  const black = resolveToken(css, tokenValue(css, 'fs-black'))
  const dark = css.match(/:root\[data-theme='dark'\]\s*\{([\s\S]*?)\n\}/)?.[1]
  assert.ok(dark, 'missing dark theme token block')
  for (const name of ['fl-c-success-text', 'fl-c-warning-text', 'fl-c-error-text', 'fl-c-primary-text', 'fl-c-info-text']) {
    const lightValue = resolveToken(css, tokenValue(css, name))
    assert.ok(contrast(lightValue, paper) >= 4.5, `${name} is too light on paper`)
  }
  for (const name of ['fl-c-success-text', 'fl-c-warning-text', 'fl-c-error-text', 'fl-c-primary-text', 'fl-c-info-text']) {
    const darkValue = resolveToken(css, tokenValue(dark, name))
    assert.ok(contrast(darkValue, inkSoft) >= 4.5, `${name} is too dark on the dark surface`)
    assert.ok(contrast(darkValue, black) >= 4.5, `${name} is too dark on the dark background`)
  }
  // Body and muted text on both surfaces, and the header text on the black navbar.
  for (const [fg, bg] of [['fs-ink', 'fs-surface'], ['fs-muted', 'fs-surface'], ['fs-muted', 'fs-soft'],
    ['fs-on-black', 'fs-black-soft'], ['fs-muted-on-black', 'fs-black-soft'], ['fs-muted-on-black', 'fs-black'], ['fs-blue-on-black', 'fs-black'],
    ['fl-c-selection-text', 'fl-c-selection-bg'], ['fl-c-primary-text', 'fl-c-bg'], ['fl-c-header-accent', 'fl-c-header']]) {
    const ratio = contrast(resolveToken(css, tokenValue(css, fg)), resolveToken(css, tokenValue(css, bg)))
    assert.ok(ratio >= 4.5, `${fg} on ${bg} is ${ratio.toFixed(2)}:1`)
  }
  for (const name of ['fl-c-selection-text', 'fl-c-primary-text']) {
    const fg = resolveToken(css, tokenValue(dark, name))
    const bg = resolveToken(css, tokenValue(dark, name === 'fl-c-selection-text' ? 'fl-c-selection-bg' : 'fl-c-bg'))
    assert.ok(contrast(fg, bg) >= 4.5, `${name} has insufficient dark-theme contrast`)
  }
})

test('P5 keeps color literals in tokens.css and preserves reduced motion', async () => {
  const styles = await source('src/styles.css')
  const tokens = await source('src/tokens.css')
  assert.doesNotMatch(styles, /#[0-9a-f]{3,8}\b/i)
  assert.match(styles, /prefers-reduced-motion/)
  assert.match(styles, /--fl-c-control-line/)
  assert.match(styles, /scrollbar-color: var\(--fl-c-control-line\) var\(--fl-c-bg\)/)
  assert.match(styles, /\.fl-header :focus-visible \{ outline-color: var\(--fl-c-header-accent\)/)
  assert.match(tokens, /--fl-c-success-text/)
})

test('P5 shell exposes skip navigation, main focus, route status, and titles', async () => {
  const app = await source('src/App.vue')
  assert.match(app, /Skip to main content/)
  assert.match(app, /id="main-content"[^>]*tabindex="-1"/)
  assert.match(app, /aria-live="polite"/)
  assert.match(app, /document\.title/)
  assert.match(app, /focusRoute/)
})

test('P5 inspection rows and controls have keyboard activation and selection state', async () => {
  const files = [
    'src/views/RunsView.vue', 'src/views/ExperimentsView.vue', 'src/views/HomeView.vue', 'src/views/GradesView.vue',
    'src/components/TimelinePanel.vue', 'src/components/FramesPanel.vue', 'src/components/RunFilesPanel.vue',
    'src/components/FilePayload.vue', 'src/components/JsonNode.vue', 'src/components/MdTables.vue',
  ]
  for (const file of files) {
    const text = await source(file)
    if (file.endsWith('JsonNode.vue') || file.endsWith('MdTables.vue')) assert.match(text, /<button type="button"/, `${file} needs native keyboard controls`)
    else assert.match(text, /keydown\.(enter|space)/, `${file} needs keyboard activation`)
  }
  assert.match(await source('src/components/TimelinePanel.vue'), /aria-selected/)
  assert.match(await source('src/components/FramesPanel.vue'), /aria-selected/)
  assert.match(await source('src/components/JsonNode.vue'), /aria-expanded/)
})

test('P5 run table uses one grid contract and a non-hover full-value disclosure', async () => {
  const runs = await source('src/views/RunsView.vue')
  const styles = await source('src/styles.css')
  assert.match(runs, /runs-table-inner/)
  assert.match(runs, /class="grid-sort"/)
  assert.match(runs, /TruncatedValue/)
  assert.match(await source('src/components/TruncatedValue.vue'), /ValueDisclosure.*compact/)
  assert.match(styles, /--runs-grid-columns/)
  assert.match(styles, /\.value-disclosure__full/)
})

test('P5 copy fallback is guarded, cleaned up, focus-restoring, and announced', async () => {
  const copy = await source('src/components/CopyButton.vue')
  assert.match(copy, /try \{[\s\S]*props\.value/)
  assert.match(copy, /finally \{[\s\S]*ta\?\.remove\(\)/)
  assert.match(copy, /focusTarget\?\.focus/)
  assert.match(copy, /aria-live="polite"/)
  assert.match(copy, /Select the text manually/)
})

test('P5 wide evidence panes scroll as a unit and narrow inspector panes stack', async () => {
  const styles = await source('src/styles.css')
  assert.match(styles, /\.table-x--fill/)
  assert.match(styles, /overflow-x: visible !important/)
  assert.match(styles, /\.frame-inspector \.frame-side/)
  assert.match(styles, /@media \(max-width: 640px\)/)
})
