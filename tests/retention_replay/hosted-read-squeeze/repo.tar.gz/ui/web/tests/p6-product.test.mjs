import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const source = (name) => readFile(new URL(`../${name}`, import.meta.url), 'utf8')

test('P6 exposes four human questions, verification, and raw run details', async () => {
  const component = await source('src/components/RunEvidenceOverview.vue')
  const run = await source('src/views/RunView.vue')
  assert.match(component, /What the model saw/)
  assert.match(component, /What it did/)
  assert.match(component, /How it was checked/)
  assert.match(component, /Why it stopped/)
  assert.match(component, /What did it cost\?/) 
  assert.match(component, /Engine settings/)
  assert.match(component, /verification\.items\?\.\[0\]\?\.evidence/)
  assert.match(run, /RunEvidenceOverview/)
  assert.match(run, /RunSettings/)
})

test('P6 comparison UI requires declared pairing and links discordant cases', async () => {
  const component = await source('src/components/ExperimentComparison.vue')
  const view = await source('src/views/ExperimentView.vue')
  assert.match(component, /declared match keys/)
  assert.match(component, /matched pairs/)
  assert.match(component, /leads on/)
  assert.match(component, /discordant/) 
  assert.match(component, /Open \{\{ runId \}\}/)
  assert.match(view, /ExperimentComparison/)
  assert.match(view, /d\.comparison/)
})

test('P6 demo walkthrough links the run, frames, experiment, and grades', async () => {
  const home = await source('src/views/HomeView.vue')
  const guide = await source('src/components/StartHere.vue')
  assert.match(home, /data\.source\?\.mode === 'demo'/)
  assert.match(home, /experiment-name="paired-demo"/)
  for (const route of ["tab: 'frames'", "name: 'experiment'", "name: 'grades'"]) assert.ok(guide.includes(route))
  assert.match(guide, /framelab ui --data PATH\/TO\/RUNS/)
})
