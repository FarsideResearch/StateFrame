import test from 'node:test'
import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import { promisify } from 'node:util'
import {
  applyThemePreference, normalizeThemePreference, resolveTheme, storedTheme, THEME_COLOR_KEYS,
} from '../src/theme.js'

const run = promisify(execFile)
const root = new URL('../', import.meta.url)
const source = (name) => readFile(new URL(name, root), 'utf8')

test('N1 theme preference supports system mode and follows the OS without losing explicit choices', () => {
  const previousMedia = globalThis.matchMedia
  const previousStorage = globalThis.localStorage
  let dark = true
  globalThis.matchMedia = () => ({ matches: dark })
  globalThis.localStorage = { getItem: () => 'system' }
  try {
    assert.equal(storedTheme(), 'system')
    assert.equal(resolveTheme('system'), 'dark')
    dark = false
    assert.equal(resolveTheme('system'), 'light')
    assert.equal(normalizeThemePreference('light'), 'light')
    assert.equal(normalizeThemePreference('unknown'), 'system')
  } finally {
    globalThis.matchMedia = previousMedia
    globalThis.localStorage = previousStorage
  }
})

test('N1 applying a preference updates both effective and selected theme attributes', () => {
  const previousMedia = globalThis.matchMedia
  const previousDocument = globalThis.document
  globalThis.matchMedia = () => ({ matches: true })
  globalThis.document = { documentElement: { dataset: {}, style: {} } }
  try {
    assert.equal(applyThemePreference('system'), 'dark')
    assert.equal(globalThis.document.documentElement.dataset.theme, 'dark')
    assert.equal(globalThis.document.documentElement.dataset.themePreference, 'system')
    assert.equal(applyThemePreference('light'), 'light')
    assert.equal(globalThis.document.documentElement.dataset.themePreference, 'light')
  } finally {
    globalThis.matchMedia = previousMedia
    globalThis.document = previousDocument
  }
})

test('N1 bootstrap and App contracts prevent flash and synchronize theme state', async () => {
  const html = await source('index.html')
  const bootstrap = await source('public/theme-bootstrap.js')
  const app = await source('src/App.vue')
  assert.match(html, /theme-bootstrap\.js/)
  assert.ok(html.indexOf('theme-bootstrap.js') < html.indexOf('type="module"'), 'bootstrap must precede the module entry')
  assert.match(bootstrap, /localStorage\.getItem\('fl-theme'\)/)
  assert.match(bootstrap, /prefers-color-scheme: dark/)
  assert.match(bootstrap, /dataset\.theme = active/)
  assert.match(app, /addEventListener\('storage'/)
  assert.match(app, /matchMedia\?\.\('\(prefers-color-scheme: dark\)'\)/)
  assert.match(app, /removeEventListener\('storage'/)
  assert.match(app, /event\.key === null/)
  assert.match(app, /else systemMedia\?\.addListener/)
  assert.match(app, /data-theme-preference/)
})

test('N1 Vuetify bridge is explicit and fails closed instead of falling back to defaults', async () => {
  const theme = await source('src/theme.js')
  const main = await source('src/main.js')
  assert.ok(Object.keys(THEME_COLOR_KEYS).length >= 10)
  assert.match(theme, /missing Vuetify bridge values/)
  assert.match(main, /readThemeColors\('light'\)/)
  assert.match(main, /readThemeColors\('dark'\)/)
  const { stdout } = await run(process.execPath, ['scripts/check-theme-tokens.mjs'], { cwd: new URL('../', import.meta.url) })
  assert.match(stdout, /N1 token guard passed/)
})

test('N1 brand and menu contracts follow the Farside shape rules', async () => {
  const app = await source('src/App.vue')
  const mark = await source('src/components/BrandMark.vue')
  const tokens = await source('src/tokens.css')
  const styles = await source('src/styles.css')
  // The Farside F-dot mark: same 64-unit geometry as the site, letter in currentColor, dot in the accent.
  assert.match(app, /<BrandMark \/>/)
  assert.match(mark, /viewBox="0 0 64 64"/)
  assert.match(mark, /d="M12 4H52V13A3 3 0 0 1 49 16H28A4 4 0 0 0 24 20V24H40V30A6 6 0 0 1 34 36H24V60H12Z"/)
  assert.match(mark, /<circle class="fl-brand-mark__dot" cx="48" cy="52" r="8"/)
  assert.match(mark, /Farside Research/)
  assert.match(styles, /\.fl-brand-mark__letter \{ fill: currentColor; \}/)
  assert.match(styles, /\.fl-brand-mark__dot \{ fill: var\(--fl-c-header-accent\); \}/)
  // Square geometry everywhere, like the site.
  assert.match(tokens, /--fl-radius: 0;/)
  assert.match(tokens, /--fl-radius-sm: 0;/)
  assert.doesNotMatch(tokens + styles, /--sx-/)
  // Vuetify defaults must not reintroduce rounded pills on buttons, chips, fields or alerts.
  const main = await source('src/main.js')
  assert.doesNotMatch(main, /rounded: '(pill|lg|xl)'/)
  // A tab strip inside a wrapping toolbar must be allowed to shrink, or it widens the page at 390px.
  assert.match(styles, /\.toolbar > \.v-tabs \{ flex: 0 1 auto; min-width: 0; max-width: 100%; \}/)
  assert.match(styles, /\.v-menu > \.v-overlay__content \{[\s\S]*box-shadow: none !important/)
  assert.doesNotMatch(styles, /\.v-menu > \.v-overlay__content \{[^}]*color-mix/)
})
