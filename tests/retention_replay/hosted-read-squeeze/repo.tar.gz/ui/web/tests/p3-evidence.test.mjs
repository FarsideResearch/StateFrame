import test from 'node:test'
import assert from 'node:assert/strict'
import { cellText, jsonValueState, metricText, parentPointer, recordValue } from '../src/evidence-state.js'
import { api } from '../src/api.js'

test('JSON preview keeps null, scalar, and malformed rows inspectable', () => {
  assert.equal(cellText(null), 'null')
  assert.equal(cellText(undefined), 'unknown')
  assert.equal(cellText({ schema_status: 'invalid_record' }), '{"schema_status":"invalid_record"}')
  assert.equal(recordValue(null, 'pass'), undefined)
  assert.equal(recordValue({ pass: true }, 'pass'), true)
})

test('bounded JSON states and JSON pointer navigation are explicit', () => {
  assert.equal(jsonValueState({ inline: true, value_type: 'null' }), 'null')
  assert.equal(jsonValueState({ inline: false, chunk: { text: 'part' } }), 'chunked')
  assert.equal(jsonValueState({ inline: false, items: { rows: [] } }), 'paged-array')
  assert.equal(parentPointer('/records/2'), '/records')
  assert.equal(parentPointer('/records'), '')
  assert.equal(parentPointer(''), null)
})

test('unknown metric values never render as zero percent', () => {
  assert.equal(metricText({ rate: null }), 'unknown')
  assert.equal(metricText({ rate: 0 }), '0.0%')
})

test('FilePayload is wired to the P3 evidence contract', async () => {
  const source = await import('node:fs/promises').then((fs) => fs.readFile(new URL('../src/components/FilePayload.vue', import.meta.url), 'utf8'))
  assert.match(source, /payload\.analysis\.scope/) // dataset-level analysis remains visible to users
  assert.match(source, /payload\.items/) // primitive arrays have a bounded page
  assert.match(source, /payload\.has_value/) // JSON null is not confused with missing data
  assert.match(source, /@query|emit\('query'/) // pointer/page controls emit to their owner
})

test('successful invalid JSON is a recoverable API error', async () => {
  const previousFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => { throw new Error('bad body') } })
  try {
    await assert.rejects(api('synthetic-invalid-json'), (error) => error.code === 'INVALID_JSON_RESPONSE')
  } finally {
    globalThis.fetch = previousFetch
  }
})
