import test from 'node:test'
import assert from 'node:assert/strict'
import { createArtifactMarkdownRenderer } from '../src/markdown-policy.js'

test('artifact markdown never emits remote image requests', () => {
  const html = createArtifactMarkdownRenderer().render('![synthetic](https://third-party.example/secret.png)')
  assert.doesNotMatch(html, /<img\b/i)
  assert.doesNotMatch(html, /third-party\.example/i)
  assert.match(html, /Image omitted in offline mode/)
})

test('artifact markdown keeps raw HTML escaped and external links isolated', () => {
  const html = createArtifactMarkdownRenderer().render('<script>synthetic()</script> [docs](https://example.test/docs)')
  assert.doesNotMatch(html, /<script>/i)
  assert.match(html, /target="_blank"/)
  assert.match(html, /rel="noopener noreferrer"/)
})

test('markdown policy preserves evidence text without rewriting identifiers', () => {
  const html = createArtifactMarkdownRenderer().render('run: supported-run-123')
  assert.match(html, /supported-run-123/)
})
