import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { api, clearApiCache } from '../src/api.js'

const source = (name) => readFile(new URL(`../${name}`, import.meta.url), 'utf8')

test('P7 backend and frontend contracts expose bounded work', async () => {
  const apiSource = await source('src/api.js')
  const app = await source('src/App.vue')
  const diff = await source('src/components/DiffView.vue')
  const json = await source('src/components/JsonTree.vue')
  const markdown = await source('src/components/MdView.vue')
  assert.match(apiSource, /MAX_API_RESPONSE_BYTES/)
  assert.match(apiSource, /RESPONSE_LIMIT/)
  assert.match(app, /onErrorCaptured/)
  assert.match(app, /role="alert"/)
  assert.match(diff, /MAX_DIFF_RENDER_LINES/)
  assert.match(diff, /MAX_DIFF_INPUT_CHARS/)
  assert.match(json, /MAX_JSON_COPY_CHARS/)
  assert.match(markdown, /MAX_MARKDOWN_CHARS/)
})

test('P7 API cache remains bounded and invalid JSON has a stable recovery code', async () => {
  clearApiCache()
  const previousFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: true, status: 200, headers: new Headers(), text: async () => '<html>not json</html>' })
  try {
    await assert.rejects(api('invalid', {}), (error) => error.code === 'INVALID_JSON_RESPONSE')
  } finally {
    globalThis.fetch = previousFetch
    clearApiCache()
  }
})

test('P7 build and static-release contracts are source-addressable', async () => {
  const start = await readFile(new URL('../../start.sh', import.meta.url), 'utf8')
  const vite = await source('vite.config.js')
  const notice = await source('public/THIRD_PARTY_NOTICES.md')
  const fingerprint = await source('scripts/build-fingerprint.mjs')
  assert.match(start, /npm ci --ignore-scripts/)
  assert.match(start, /build-fingerprint\.mjs/)
  assert.match(vite, /framelab-build\.json/)
  assert.match(fingerprint, /package-lock\.json/)
  assert.match(notice, /Apache-2\.0/)
  assert.match(notice, /MIT/)
})

test('P7 component qualification covers copy, diff, markdown, and cache recovery', async () => {
  const copy = await source('src/components/CopyButton.vue')
  const timeline = await source('src/components/TimelinePanel.vue')
  const frame = await source('src/components/FrameInspector.vue')
  assert.match(copy, /2_000_000/)
  assert.match(copy, /First 2 MB copied/)
  assert.match(timeline, /Load more events/)
  assert.match(frame, /MAX_SEARCH_CHARS/)
})
