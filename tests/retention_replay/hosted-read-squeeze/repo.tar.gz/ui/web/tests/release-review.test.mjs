import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { normalizeFileLocation, normalizeFileRoot } from '../src/file-root.js'
import { appendExperimentPage } from '../src/page-state.js'
import { pageTitle } from '../src/page-title.js'
import { valueLabel } from '../src/value-labels.js'

const source = (path) => readFile(new URL(`../src/${path}`, import.meta.url), 'utf8')

test('legacy file URLs normalize before loading and new links use experiments', async () => {
  const old = 'frame' + '_lab'
  const url = new URL(`/file?root=${old}&path=paired-demo`, 'http://localhost')
  const redirect = normalizeFileLocation({ name: 'file', query: Object.fromEntries(url.searchParams), hash: '' })
  assert.equal(redirect.query.root, 'experiments')
  assert.equal(redirect.query.path, 'paired-demo')
  assert.equal(normalizeFileRoot(old), 'experiments')
  assert.equal(normalizeFileLocation({ name: 'file', query: { root: 'experiments' }, hash: '' }), true)
  assert.match(await source('views/FileView.vue'), /root: normalizeFileRoot\(queryValue\(qq\.root\)\)/)
})

test('labels describe known values and convert unfamiliar snake case', () => {
  assert.equal(valueLabel('exit_2'), 'Exited with code 2')
  assert.equal(valueLabel('PASS_behavioural'), 'Behavior check passed')
  assert.equal(valueLabel('FAIL_behavioural'), 'Behavior check failed')
  assert.equal(valueLabel('verified_success'), 'Verified success')
  assert.equal(valueLabel('budget_exhausted'), 'Budget exhausted')
  assert.equal(valueLabel('unexpected_stop_reason'), 'Unexpected stop reason')
  assert.equal(valueLabel('unknown', 'Not graded'), 'Not graded')
})

test('cold and unnamed routes keep the plain Frame Lab title', async () => {
  assert.equal(pageTitle(undefined), 'Frame Lab')
  assert.equal(pageTitle('home'), 'Frame Lab')
  assert.equal(pageTitle('unregistered'), 'Frame Lab')
  assert.equal(pageTitle('runs'), 'Runs · Frame Lab')
  assert.match(await source('App.vue'), /document\.title = pageTitle\(route\.name\)/)
})

test('experiment file pages append beyond 200 while detail metadata stays', async () => {
  const first = { name: 'large', results_md: '# Report', tables: [{ name: 'one' }], files: Array.from({ length: 200 }, (_, i) => ({ path: `large/${i}.json` })), files_total: 235, files_has_more: true, files_next_offset: 200 }
  const next = { files: Array.from({ length: 35 }, (_, i) => ({ path: `large/${i + 200}.json` })), files_total: 235, files_has_more: false, files_next_offset: null }
  const result = appendExperimentPage(first, next, 200)
  assert.equal(result.files.length, 235)
  assert.equal(result.files[0].path, 'large/0.json')
  assert.equal(result.files[234].path, 'large/234.json')
  assert.equal(result.results_md, '# Report')
  assert.deepEqual(result.tables, first.tables)
  assert.equal(result.files_has_more, false)
  assert.match(await source('views/ExperimentView.vue'), /appendExperimentPage\(d\.value, r, offset\)/)
})

test('narrow navigation wraps into four visible destinations', async () => {
  const css = await source('styles.css')
  const app = await source('App.vue')
  assert.match(css, /@media \(max-width: 640px\)[\s\S]*\.fl-nav \{ order: 3; flex: 0 0 100%; display: grid; grid-template-columns: repeat\(4, minmax\(0, 1fr\)\); overflow: visible/)
  assert.deepEqual(['Overview', 'Runs', 'Experiments', 'Grades'].map((label) => app.includes(`label: '${label}'`)), [true, true, true, true])
})

test('navigable truncated values expose a link and independent full-value control', async () => {
  const value = await source('components/TruncatedValue.vue')
  const runs = await source('views/RunsView.vue')
  const home = await source('views/HomeView.vue')
  assert.match(value, /<RouterLink v-if="to"/)
  assert.match(value, /<ValueDisclosure.*compact/)
  assert.match(runs, /<TruncatedValue :value="r.id" label="run name" :to=/)
  assert.match(home, /<TruncatedValue :value="r.id" label="run name" :to=/)
})

test('the full-value control appears only when a cell actually cuts its text off', async () => {
  const value = await source('components/TruncatedValue.vue')
  assert.match(value, /<ValueDisclosure v-if="overflowing"/)
  assert.match(value, /scrollWidth > el\.clientWidth/)
  assert.match(value, /new ResizeObserver\(measure\)/)
  assert.match(value, /observer\?\.disconnect\(\)/)
})

test('overview recent runs use a fixed table layout so long names truncate instead of widening the panel', async () => {
  const home = await source('views/HomeView.vue')
  const css = await readFile(new URL('../src/styles.css', import.meta.url), 'utf8')
  assert.match(home, /class="fl-table fixed"/)
  assert.match(css, /\.fl-table\.fixed \{ table-layout: fixed; \}/)
})
