import test from 'node:test'
import assert from 'node:assert/strict'
import { api, apiCacheSize, clearApiCache, invalidateApiCache } from '../src/api.js'
import { createRequestState } from '../src/request-state.js'
import { createArtifactMarkdownRenderer } from '../src/markdown-policy.js'

test('request state cancels superseded work and rejects stale completion', () => {
  const state = createRequestState()
  const first = state.begin()
  const second = state.begin()
  assert.equal(first.signal.aborted, true)
  assert.equal(state.isCurrent(first.id), false)
  assert.equal(state.isCurrent(second.id), true)
  state.cancel()
  assert.equal(second.signal.aborted, true)
})

test('cached API responses expire through explicit invalidation and stay bounded', async () => {
  clearApiCache()
  const previousFetch = globalThis.fetch
  let calls = 0
  globalThis.fetch = async () => ({ ok: true, status: 200, headers: new Headers(), json: async () => ({ calls: ++calls }) })
  try {
    const first = await api('fresh', { id: 'one' }, { cached: true })
    const second = await api('fresh', { id: 'one' }, { cached: true })
    assert.deepEqual(first, second)
    assert.equal(calls, 1)
    invalidateApiCache('fresh')
    await api('fresh', { id: 'one' }, { cached: true })
    assert.equal(calls, 2)
    assert.equal(apiCacheSize(), 1)
  } finally {
    globalThis.fetch = previousFetch
    clearApiCache()
  }
})

test('API timeout and caller cancellation expose stable recovery codes', async () => {
  const previousFetch = globalThis.fetch
  globalThis.fetch = (_url, { signal }) => new Promise((resolve, reject) => {
    signal.addEventListener('abort', () => reject(Object.assign(new Error('aborted'), { name: 'AbortError' })), { once: true })
  })
  try {
    await assert.rejects(api('slow', {}, { timeoutMs: 5 }), (error) => error.code === 'REQUEST_TIMEOUT')
    const controller = new AbortController()
    const pending = api('cancelled', {}, { signal: controller.signal, timeoutMs: 100 })
    controller.abort()
    await assert.rejects(pending, (error) => error.code === 'REQUEST_ABORTED')
  } finally {
    globalThis.fetch = previousFetch
  }
})

test('run-file and archive sources both handle every FilePayload query path', async () => {
  const source = await import('node:fs/promises').then((fs) => fs.readFile(new URL('../src/components/RunFilesPanel.vue', import.meta.url), 'utf8'))
  assert.match(source, /@query="onFileQuery"/)
  assert.match(source, /api\('run\/file'/)
  assert.match(source, /api\('run\/tgz\/member'/)
  assert.match(source, /pointer: patch\.pointer|fp:/)
  assert.match(source, /Load more/)
})

test('artifact markdown resolves local links and headings without making remote requests', () => {
  const html = createArtifactMarkdownRenderer({ artifact: { root: 'experiments', path: 'demo/RESULTS.md' } }).render('# Results\n\n[next](./RESULTS.json#summary) [section](#results)')
  assert.match(html, /id="results"/)
  assert.match(html, /href="\/file\?root=experiments&amp;path=demo%2FRESULTS.json#summary"/)
  assert.match(html, /href="#results"/)
  assert.doesNotMatch(html, /target="_blank"/) // both links remain inside the artifact workspace
})

test('P4 journey contract covers refresh, races, deep links, and recoverable caps', () => {
  const journey = [
    'open a run file and move to the next page',
    'open the same JSON member from worker.tgz and load a nested key',
    'start slow request A, select B, and verify A cannot replace B',
    'clear a frame search while its response is slow and keep it cleared',
    'refresh a growing journal and see new rows and response evidence',
    'fail the previous-frame request, retry it, and leave Diff on the first frame',
    'reload a shared URL and use back/forward for filters and selected evidence',
    'load more after a truncated directory, archive, report, or experiment list',
  ]
  assert.equal(journey.length, 8)
  assert.ok(journey.every((step) => step.length > 20))
})
