// Token guard, run before every build.
// 1. Every Vuetify bridge color has a light and a dark token (the app fails closed without them).
// 2. When the Farside Research site source is available, every mirrored --fs-* value must equal the
//    site's active --brand-* value (src/farside.css, overridden by src/isometric.css). Point
//    FRAMELAB_BRAND_SOURCE at a site checkout to enforce it; without one the parity check is skipped
//    and says so, so an outside build never depends on a private repository.
import assert from 'node:assert/strict'
import { access, readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const webRoot = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const frameCss = await readFile(path.join(webRoot, 'src', 'tokens.css'), 'utf8')
const themeModule = await import(new URL('../src/theme.js', import.meta.url))

function block(css, marker) {
  const start = css.indexOf(marker)
  assert.notEqual(start, -1, `missing token block: ${marker}`)
  const open = css.indexOf('{', start)
  const close = css.indexOf('\n}', open)
  assert.ok(open > start && close > open, `malformed token block: ${marker}`)
  return css.slice(open + 1, close)
}

export function declarations(css) {
  return Object.fromEntries([...css.matchAll(/^\s*(--[\w-]+)\s*:\s*([^;]+);/gm)].map((match) => [match[1], match[2].trim()]))
}

const frameLight = declarations(block(frameCss, ':root {'))
const frameDark = declarations(block(frameCss, ":root[data-theme='dark'] {"))
for (const [name, variable] of Object.entries(themeModule.THEME_COLOR_KEYS)) {
  assert.ok(frameLight[variable], `light token missing for Vuetify bridge: ${name} -> ${variable}`)
  assert.ok(frameDark[variable], `dark token missing for Vuetify bridge: ${name} -> ${variable}`)
}
const bridge = Object.keys(themeModule.THEME_COLOR_KEYS).length

const siteRoot = process.env.FRAMELAB_BRAND_SOURCE
if (!siteRoot) {
  console.log(`N1 token guard passed: ${bridge} Vuetify bridge colors; Farside parity skipped (FRAMELAB_BRAND_SOURCE not set)`)
} else {
  const site = {}
  for (const file of ['src/farside.css', 'src/isometric.css']) {
    const full = path.join(siteRoot, file)
    await access(full)
    Object.assign(site, declarations(block(await readFile(full, 'utf8'), ':root {')))
  }
  let mirrored = 0
  for (const [name, value] of Object.entries(frameLight)) {
    if (!name.startsWith('--fs-')) continue
    const siteName = `--brand-${name.slice('--fs-'.length)}`
    assert.ok(site[siteName], `${name} has no ${siteName} on the Farside site`)
    assert.equal(value.toLowerCase(), site[siteName].toLowerCase(), `${name} drifted from Farside ${siteName}`)
    mirrored += 1
  }
  assert.ok(mirrored >= 20, `expected the Farside palette to be mirrored, found ${mirrored} tokens`)
  console.log(`N1 token guard passed: ${mirrored} Farside tokens match the site and ${bridge} Vuetify bridge colors`)
}
