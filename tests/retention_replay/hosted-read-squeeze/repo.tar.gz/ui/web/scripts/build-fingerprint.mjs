import { createHash } from 'node:crypto'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const webRoot = path.resolve(fileURLToPath(new URL('../', import.meta.url)))
  const roots = ['src', 'public', 'scripts']
const rootFiles = ['index.html', 'package.json', 'package-lock.json', 'vite.config.js']

function inputFiles() {
  const files = [...rootFiles]
  function visit(relative) {
    const absolute = path.join(webRoot, relative)
    if (!existsSync(absolute)) return
    for (const entry of readdirSync(absolute).sort()) {
      const child = path.join(relative, entry)
      if (entry === 'node_modules' || entry === 'dist' || entry.startsWith('.')) continue
      if (statSync(path.join(webRoot, child)).isDirectory()) visit(child)
      else files.push(child)
    }
  }
  roots.forEach(visit)
  return [...new Set(files)].filter((file) => existsSync(path.join(webRoot, file))).sort()
}

export function buildFingerprint(root = webRoot) {
  const hash = createHash('sha256')
  for (const relative of inputFiles()) {
    hash.update(relative)
    hash.update('\0')
    hash.update(readFileSync(path.join(root, relative)))
    hash.update('\0')
  }
  return { algorithm: 'sha256', inputs: inputFiles().length, value: hash.digest('hex') }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const manifestPath = path.join(webRoot, 'dist', 'framelab-build.json')
  if (!existsSync(manifestPath)) process.exit(1)
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  const current = buildFingerprint()
  process.stdout.write(`${current.value}\n`)
  process.exit(manifest.fingerprint?.value === current.value ? 0 : 1)
}
