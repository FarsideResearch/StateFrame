/**
 * Shared table/list sorting contract.
 *
 * Missing values are always last, even when the visible sort direction is
 * descending. Present numbers sort numerically; other values use numeric-aware
 * locale comparison so identifiers such as run-2 precede run-10.
 */

/** @param {unknown} value */
export function isMissingSortValue(value) {
  return value === null || value === undefined || value === ''
}

/**
 * @param {unknown} left
 * @param {unknown} right
 * @param {boolean} descending
 */
export function compareMissingLast(left, right, descending = false) {
  const leftMissing = isMissingSortValue(left)
  const rightMissing = isMissingSortValue(right)
  if (leftMissing || rightMissing) {
    if (leftMissing && rightMissing) return 0
    return leftMissing ? 1 : -1
  }

  const direction = descending ? -1 : 1
  const comparison = typeof left === 'number' && typeof right === 'number'
    ? left - right
    : String(left).localeCompare(String(right), undefined, { numeric: true })
  return comparison * direction
}

/**
 * @template {Record<string, unknown>} T
 * @param {T[]} rows
 * @param {string} field
 * @param {boolean} descending
 * @returns {T[]}
 */
export function sortByField(rows, field, descending = false) {
  return [...rows].sort((left, right) => compareMissingLast(left?.[field], right?.[field], descending))
}
