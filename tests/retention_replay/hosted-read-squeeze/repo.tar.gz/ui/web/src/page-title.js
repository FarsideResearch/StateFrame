const ROUTE_TITLES = {
  home: 'Overview', runs: 'Runs', run: 'Run inspection', experiments: 'Experiments', experiment: 'Experiment',
  file: 'File inspection', grades: 'Grades', 'not-found': 'Not found',
}

export function pageTitle(name) {
  return !name || name === 'home' || !ROUTE_TITLES[name] ? 'Frame Lab' : `${ROUTE_TITLES[name]} · Frame Lab`
}

export function routeAnnouncement(name) {
  return `${ROUTE_TITLES[name] || 'Frame Lab'} loaded`
}
