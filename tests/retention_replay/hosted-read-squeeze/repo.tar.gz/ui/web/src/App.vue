<template>
  <v-app>
    <div class="fl-shell">
      <a class="skip-link" href="#main-content">Skip to main content</a>
      <header class="fl-header">
        <RouterLink to="/" class="fl-brand" aria-label="Frame Lab by Farside Research, overview">
          <BrandMark />
        </RouterLink>
        <nav class="fl-nav" aria-label="Primary">
          <RouterLink
            v-for="t in tabs" :key="t.value" :to="t.to" :class="{ active: t.value === activeTab }"
            :aria-current="t.value === activeTab ? 'page' : undefined" :title="t.label"
          >
            <v-icon :icon="t.icon" size="16" /><span class="label-text">{{ t.label }}</span>
          </RouterLink>
        </nav>
        <div class="fl-header-end">
          <button type="button" class="fl-icon-btn" :aria-label="themeActionLabel" :title="themeActionLabel" :data-theme-preference="themePreference" @click="toggleTheme">
            <v-icon :icon="isDark ? mdiWeatherSunny : mdiWeatherNight" size="16" />
            <span class="fl-theme-label">Theme: {{ themePreferenceLabel }}</span>
          </button>
        </div>
      </header>
      <main id="main-content" ref="main" class="fl-main" tabindex="-1" aria-label="Frame Lab content">
        <section v-if="renderError" class="fl-error-state" role="alert" aria-labelledby="render-error-title">
          <div class="kicker kicker--primary">Application recovery</div>
          <h1 id="render-error-title">This view could not be rendered</h1>
          <p>Frame Lab stopped this view safely. Your evidence remains read-only and no raw error details are shown here.</p>
          <p class="muted small">Reload the application to retry the current route.</p>
          <button type="button" class="fl-action-btn" @click="reloadApplication">Reload application</button>
        </section>
        <router-view v-else v-slot="{ Component }">
          <keep-alive :include="['RunsView', 'ExperimentsView']">
            <component :is="Component" />
          </keep-alive>
        </router-view>
      </main>
      <div class="route-status" role="status" aria-live="polite">{{ routeStatus }}</div>
    </div>
  </v-app>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onErrorCaptured, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useTheme } from 'vuetify'
import {
  mdiWeatherSunny, mdiWeatherNight, mdiViewDashboardOutline,
  mdiTimelineTextOutline, mdiFlaskOutline, mdiCheckDecagramOutline,
} from '@mdi/js'
import {
  applyThemePreference, normalizeThemePreference, storedTheme, themePreferenceLabel as formatThemePreference,
  THEME_KEY,
} from './theme'
import BrandMark from './components/BrandMark.vue'
import { pageTitle, routeAnnouncement } from './page-title.js'
import { normalizeFileRoot } from './file-root.js'

const theme = useTheme()
const route = useRoute()
const main = ref(null)
const routeStatus = ref('')
const renderError = ref(false)
const themePreference = ref(storedTheme())
onErrorCaptured(() => {
  renderError.value = true
  return false
})
function reloadApplication() {
  window.location.reload()
}
const isDark = computed(() => theme.global.current.value.dark)
const themePreferenceLabel = computed(() => formatThemePreference(themePreference.value))
const themeActionLabel = computed(() => {
  const next = themePreference.value === 'system' ? 'light' : themePreference.value === 'light' ? 'dark' : 'system'
  return `Theme preference: ${themePreferenceLabel.value}. Activate ${formatThemePreference(next)} theme`
})

function setThemePreference(value, { persist = true } = {}) {
  const next = normalizeThemePreference(value)
  themePreference.value = next
  const active = applyThemePreference(next)
  theme.global.name.value = active
  if (persist) {
    try { globalThis.localStorage?.setItem(THEME_KEY, next) } catch { /* private mode */ }
  }
}

function toggleTheme() {
  const next = themePreference.value === 'system' ? 'light' : themePreference.value === 'light' ? 'dark' : 'system'
  setThemePreference(next)
}

let systemMedia
function onStorage(event) {
  if (event.key === THEME_KEY || event.key === null) setThemePreference(event.key === null ? null : event.newValue, { persist: false })
}
function onSystemThemeChange() {
  if (themePreference.value === 'system') setThemePreference('system', { persist: false })
}
onMounted(() => {
  window.addEventListener('storage', onStorage)
  systemMedia = window.matchMedia?.('(prefers-color-scheme: dark)')
  if (systemMedia?.addEventListener) systemMedia.addEventListener('change', onSystemThemeChange)
  else systemMedia?.addListener?.(onSystemThemeChange)
})
onBeforeUnmount(() => {
  window.removeEventListener('storage', onStorage)
  if (systemMedia?.removeEventListener) systemMedia.removeEventListener('change', onSystemThemeChange)
  else systemMedia?.removeListener?.(onSystemThemeChange)
})

const tabs = [
  { value: 'home', label: 'Overview', to: '/', icon: mdiViewDashboardOutline, match: ['home'] },
  { value: 'runs', label: 'Runs', to: '/runs', icon: mdiTimelineTextOutline, match: ['runs', 'run'] },
  { value: 'experiments', label: 'Experiments', to: '/experiments', icon: mdiFlaskOutline, match: ['experiments', 'experiment'] },
  { value: 'grades', label: 'Grades', to: '/grades', icon: mdiCheckDecagramOutline, match: ['grades'] },
]
// The shared file viewer belongs to Experiments for experiment files, to Runs for run files, otherwise to Grades.
const activeTab = computed(() => {
  if (route.name === 'file') {
    const root = normalizeFileRoot(Array.isArray(route.query.root) ? route.query.root[0] : route.query.root)
    return root === 'experiments' ? 'experiments' : root === 'capability' ? 'runs' : 'grades'
  }
  return tabs.find((t) => t.match.includes(route.name))?.value
})

function updateTitle() {
  document.title = pageTitle(route.name)
}
async function focusRoute() {
  updateTitle()
  await nextTick()
  main.value?.focus({ preventScroll: true })
  routeStatus.value = routeAnnouncement(route.name)
}
watch(() => route.name, focusRoute, { immediate: true })
onMounted(updateTitle)
</script>
