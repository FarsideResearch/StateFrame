// Bridges tokens.css to Vuetify. Vuetify needs concrete hex values for its theme, so we read the
// resolved --fl-c-* custom properties for each theme instead of duplicating hexes here.
export const THEME_COLOR_KEYS = Object.freeze({
  background: '--fl-c-bg',
  surface: '--fl-c-surface',
  'surface-variant': '--fl-c-line',
  primary: '--fl-c-primary',
  secondary: '--fl-c-muted',
  success: '--fl-c-success',
  warning: '--fl-c-warning',
  error: '--fl-c-error',
  info: '--fl-c-info',
  'on-background': '--fl-c-text',
  'on-surface': '--fl-c-text',
})
const HEX = /^#[0-9a-f]{3,8}$/i
const ACTIVE_THEMES = new Set(['light', 'dark'])
const THEME_PREFERENCES = new Set(['light', 'dark', 'system'])

export const THEME_KEY = 'fl-theme'

export function normalizeThemePreference(value) {
  return THEME_PREFERENCES.has(value) ? value : 'system'
}

export function storedTheme() {
  try {
    return normalizeThemePreference(globalThis.localStorage?.getItem(THEME_KEY))
  } catch { return 'system' }
}

export function systemTheme() {
  try {
    return globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  } catch { return 'light' }
}

export function resolveTheme(preference) {
  const normalized = normalizeThemePreference(preference)
  return normalized === 'system' ? systemTheme() : normalized
}

export function applyThemePreference(preference) {
  const normalized = normalizeThemePreference(preference)
  const active = resolveTheme(normalized)
  applyThemeAttr(active)
  document.documentElement.dataset.themePreference = normalized
  return active
}

export function applyThemeAttr(name) {
  if (!ACTIVE_THEMES.has(name)) throw new Error(`Unsupported active theme: ${name}`)
  document.documentElement.dataset.theme = name
  document.documentElement.style.colorScheme = name
}

export function themePreferenceLabel(preference) {
  const normalized = normalizeThemePreference(preference)
  return normalized[0].toUpperCase() + normalized.slice(1)
}

// Resolve every key for one theme by flipping the root attribute briefly (synchronous, no paint).
export function readThemeColors(name) {
  if (!ACTIVE_THEMES.has(name)) throw new Error(`Unsupported active theme: ${name}`)
  const root = document.documentElement
  const prev = root.dataset.theme
  root.dataset.theme = name
  const cs = getComputedStyle(root)
  const colors = {}
  const missing = []
  try {
    for (const [k, v] of Object.entries(THEME_COLOR_KEYS)) {
      const val = resolveVar(cs, cs.getPropertyValue(v).trim())
      if (HEX.test(val)) colors[k] = val
      else missing.push(`${k} (${v})`)
    }
  } finally {
    if (prev === undefined) delete root.dataset.theme
    else root.dataset.theme = prev
  }
  if (missing.length) throw new Error(`Theme ${name} is missing Vuetify bridge values: ${missing.join(', ')}`)
  return colors
}

// Custom properties come back with var() already substituted in modern engines, but follow
// Follow nested var(--x) references defensively in case the engine returns specified values.
function resolveVar(cs, val) {
  let current = val
  for (let i = 0; i < 8; i += 1) {
    const m = /^var\((--[\w-]+)\)$/.exec(current)
    if (!m) return current
    current = cs.getPropertyValue(m[1]).trim()
  }
  return current
}
