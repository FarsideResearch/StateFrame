import MarkdownIt from 'markdown-it'

// Artifact markdown is evidence, not a web page. Keep text/link safety from
// markdown-it while replacing image loads with an explicit offline placeholder.
function artifactHref(href, artifact) {
  if (!artifact || !href || href.startsWith('#') || /^[a-z][a-z0-9+.-]*:/i.test(href) || href.startsWith('//')) return href
  if (href.startsWith('/')) return href
  const hashIndex = href.indexOf('#')
  const fragment = hashIndex >= 0 ? href.slice(hashIndex + 1) : ''
  const pathHref = hashIndex >= 0 ? href.slice(0, hashIndex) : href
  const base = String(artifact.path || '').split('/').slice(0, -1)
  const parts = [...base, ...pathHref.split('/')]
  const clean = []
  for (const part of parts) {
    if (!part || part === '.') continue
    if (part === '..') { if (!clean.length) return null; clean.pop() } else clean.push(part)
  }
  const path = clean.join('/')
  if (!path) return null
  const query = new URLSearchParams({ root: artifact.root, path })
  return `/file?${query}${fragment ? `#${encodeURIComponent(fragment)}` : ''}`
}

export function createArtifactMarkdownRenderer({ artifact = null } = {}) {
  const md = new MarkdownIt({ html: false, linkify: true, breaks: false })
  const defaultLink = md.renderer.rules.link_open || ((tokens, idx, opts, env, self) => self.renderToken(tokens, idx, opts))
  md.renderer.rules.link_open = (tokens, idx, opts, env, self) => {
    const href = tokens[idx].attrGet('href') || ''
    const local = artifactHref(href, artifact)
    if (local === null) {
      tokens[idx].attrSet('href', '#')
      tokens[idx].attrSet('aria-disabled', 'true')
    } else if (local && local !== href) {
      tokens[idx].attrSet('href', local)
    } else if (local !== href || /^[a-z][a-z0-9+.-]*:/i.test(href) || href.startsWith('//')) {
      tokens[idx].attrSet('target', '_blank')
      tokens[idx].attrSet('rel', 'noopener noreferrer')
    }
    return defaultLink(tokens, idx, opts, env, self)
  }
  md.renderer.rules.heading_open = (tokens, idx, opts, env, self) => {
    const title = tokens[idx + 1]?.content || ''
    const slug = title.toLowerCase().trim().replace(/[^\p{L}\p{N}\s-]/gu, '').replace(/[\s-]+/g, '-') || 'section'
    tokens[idx].attrSet('id', slug)
    return self.renderToken(tokens, idx, opts)
  }
  md.renderer.rules.image = (tokens, idx) => {
    const alt = md.utils.escapeHtml(tokens[idx].content || 'artifact image')
    return `<span class="md-image-block" role="img" aria-label="${alt}">Image omitted in offline mode</span>`
  }
  return md
}
