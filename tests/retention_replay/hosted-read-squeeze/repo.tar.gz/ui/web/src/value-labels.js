const LABELS = {
  complete: 'Complete', running: 'Running', failed: 'Failed', unknown: 'Unknown',
  PASS: 'Passed', FAIL: 'Failed', FIXED: 'Fixed', NOT_FIXED: 'Not fixed',
  verified_success: 'Verified success', budget_exhausted: 'Budget exhausted',
  not_run: 'Not run', available: 'Available', partial: 'Partial', missing: 'Missing',
  redacted: 'Redacted', engine: 'Engine', process: 'Process',
  minimize: 'Lower is better', maximize: 'Higher is better',
  json: 'JSON', jsonl: 'JSONL', md: 'Markdown',
}

export function valueLabel(value, fallback = 'not recorded') {
  if (value == null || value === '') return fallback
  const raw = String(value)
  if (raw === 'unknown' && fallback === 'Not graded') return fallback
  const exit = /^exit_(\d+)$/i.exec(raw)
  if (exit) return `Exited with code ${exit[1]}`
  const behavior = /^(PASS|FAIL)_behavioural$/i.exec(raw)
  if (behavior) return `Behavior check ${behavior[1].toUpperCase() === 'PASS' ? 'passed' : 'failed'}`
  if (LABELS[raw]) return LABELS[raw]
  if (/\s/.test(raw)) return raw
  const words = raw.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim()
  return words ? words.charAt(0).toUpperCase() + words.slice(1).toLowerCase() : fallback
}
