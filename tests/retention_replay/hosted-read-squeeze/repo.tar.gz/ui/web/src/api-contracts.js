/**
 * Lightweight API envelope documentation shared by the browser views.
 *
 * Successful endpoints return an endpoint-specific object. Error responses
 * always use the fields below. Capped collections additionally expose the
 * page fields so a view can distinguish an empty collection from a partial
 * response. These typedefs intentionally describe the transport boundary;
 * artifact-specific records remain validated by their server adapters.
 *
 * @typedef {Object} ApiErrorEnvelope
 * @property {string} error
 * @property {string} code
 * @property {string} [request_id]
 *
 * @typedef {Object} PageEnvelope
 * @property {number} total
 * @property {number} offset
 * @property {number} limit
 * @property {boolean} has_more
 * @property {number|null} [next_offset]
 *
 * @typedef {Object} RunsEnvelope
 * @property {Array<Record<string, unknown>>} runs
 *
 * @typedef {Object} ExperimentsEnvelope
 * @property {Array<Record<string, unknown>>} experiments
 *
 * @typedef {Object} JournalEnvelope
 * @property {Array<Record<string, unknown>>} rows
 * @property {number} matched
 * @property {number} total
 * @property {number} offset
 * @property {number} limit
 * @property {boolean} has_more
 *
 * @typedef {Object} FramesEnvelope
 * @property {Array<Record<string, unknown>>} frames
 */

export const API_CONTRACT_VERSION = 'framelab-api.v1'
