import { createApp } from 'vue'
import { createVuetify } from 'vuetify'
import { aliases, mdi } from 'vuetify/iconsets/mdi-svg'
import 'vuetify/styles'
import './tokens.css'
import './styles.css'
import App from './App.vue'
import router from './router'
import { applyThemePreference, readThemeColors, storedTheme } from './theme'

// Colors come from tokens.css only (Farside palette); theme.js resolves them for Vuetify.
const initial = applyThemePreference(storedTheme())

const vuetify = createVuetify({
  icons: { defaultSet: 'mdi', aliases, sets: { mdi } },
  theme: {
    defaultTheme: initial,
    themes: {
      light: { dark: false, colors: readThemeColors('light') },
      dark: { dark: true, colors: readThemeColors('dark') },
    },
  },
  defaults: {
    VCard: { variant: 'flat', rounded: 0, elevation: 0 },
    VBtn: { variant: 'outlined', elevation: 0, rounded: 0, size: 'small', class: 'text-none' },
    VChip: { size: 'small', variant: 'tonal', rounded: 0 },
    VTextField: { density: 'compact', variant: 'outlined', hideDetails: true, rounded: 0 },
    VSelect: { density: 'compact', variant: 'outlined', hideDetails: true, rounded: 0 },
    VAutocomplete: { density: 'compact', variant: 'outlined', hideDetails: true },
    VSwitch: { density: 'compact', hideDetails: true, color: 'primary', inset: true },
    VTabs: { density: 'compact', color: 'primary', sliderColor: 'primary' },
    VTab: { class: 'text-none' },
    VProgressLinear: { color: 'primary', height: 2 },
    VAlert: { variant: 'tonal', density: 'compact', rounded: 0 },
    VList: { density: 'compact', bgColor: 'transparent' },
    VTable: { density: 'compact' },
  },
})

createApp(App).use(vuetify).use(router).mount('#app')
