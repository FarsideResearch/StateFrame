// Shared latest-request contract for views that can be kept alive or rapidly
// navigated. A new request cancels the old one and remains identifiable even
// when a server ignores cancellation. Views own their loading/error refs, but
// all cancellation and stale-result decisions belong here.
export function createRequestState(timeoutMs = 30_000) {
  let sequence = 0
  let controller = null
  return {
    begin() {
      controller?.abort()
      controller = new AbortController()
      const id = ++sequence
      return { id, signal: controller.signal, timeoutMs }
    },
    isCurrent(id) { return id === sequence },
    cancel() {
      controller?.abort()
      controller = null
      sequence += 1
    },
  }
}
