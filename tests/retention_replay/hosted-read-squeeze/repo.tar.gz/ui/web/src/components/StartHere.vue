<template>
  <section v-if="!dismissed" class="panel start-here" aria-labelledby="start-here-title">
    <div class="panel-head">
      <h2 id="start-here-title" class="title">Start here</h2>
      <button type="button" class="copy-btn end" aria-label="Dismiss start here guide" @click="dismiss">Dismiss</button>
    </div>
    <div class="panel-body">
      <p>Frame Lab helps you inspect model requests and compare experiments. This is synthetic demo data.</p>
      <ol class="start-here__steps">
        <li v-for="step in steps" :key="step.label">
          <RouterLink :to="step.to">{{ step.label }}</RouterLink>
          <span class="muted small">{{ step.description }}</span>
        </li>
      </ol>
      <p class="small muted">To inspect your own runs: <code>framelab ui --data PATH/TO/RUNS</code></p>
    </div>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'
import { readStartHereDismissed, saveStartHereDismissed } from '../start-here-state.js'

const props = defineProps({ runId: { type: String, default: '' }, experimentName: { type: String, default: '' } })
const dismissed = ref(readStartHereDismissed())
const run = computed(() => props.runId ? { name: 'run', query: { id: props.runId } } : { name: 'runs' })
const steps = computed(() => [
  { label: 'Open a run', description: 'See its recorded result and activity.', to: run.value },
  { label: 'See what the model saw', description: 'Open the run’s Frames tab.', to: props.runId ? { name: 'run', query: { id: props.runId, tab: 'frames' } } : run.value },
  { label: 'Compare an experiment', description: 'Review variants and their recorded results.', to: props.experimentName ? { name: 'experiment', params: { name: props.experimentName } } : { name: 'experiments' } },
  { label: 'Check grades', description: 'See which proof files have a graded verdict.', to: { name: 'grades' } },
])
function dismiss() {
  dismissed.value = true
  saveStartHereDismissed()
}
</script>
