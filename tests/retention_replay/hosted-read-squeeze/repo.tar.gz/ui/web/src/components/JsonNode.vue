<template>
  <div role="treeitem" :aria-level="depth + 1" :style="{ paddingLeft: depth ? '14px' : 0 }">
    <template v-if="isContainer">
      <button type="button" class="json-toggle button" :aria-expanded="open" :aria-label="`${name || 'Value'}, ${open ? 'collapse' : 'expand'} ${sizeLabel}`" @click="open = !open">
        <v-icon :icon="open ? mdiChevronDown : mdiChevronRight" size="14" class="muted" aria-hidden="true" style="vertical-align: -2px" />
        <span v-if="name !== ''" class="json-key"> {{ name }}</span><span v-if="name !== ''">: </span>
        <span class="muted">{{ sizeLabel }}</span>
      </button>
      <template v-if="open">
        <JsonNode
          v-for="[k, v] in shownEntries" :key="k" :name="String(k)" :value="v" :depth="depth + 1"
          :open-depth="openDepth" :highlight="highlight"
        />
        <div v-if="size > limit" style="padding-left: 14px">
          <button type="button" class="json-toggle button muted" @click="limit += 200">show {{ Math.min(200, size - limit) }} more of {{ size - limit }}</button>
        </div>
      </template>
    </template>
    <template v-else>
      <span v-if="name !== ''" class="json-key">{{ name }}: </span>
      <span v-if="typeof value === 'string'" class="json-str">
        <template v-if="value.length > strLimit && !showFull">"{{ value.slice(0, strLimit) }}..." <button type="button" class="json-toggle button muted" @click="showFull = true">({{ value.length }} chars, expand)</button></template>
        <template v-else>"<HighlightText :text="value" :q="highlight" />"</template>
      </span>
      <span v-else-if="typeof value === 'number'" class="json-num">{{ value }}</span>
      <span v-else class="json-lit">{{ value === null ? 'null' : String(value) }}</span>
    </template>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { mdiChevronDown, mdiChevronRight } from '@mdi/js'
import HighlightText from './HighlightText.vue'

const props = defineProps({
  value: { type: null, default: null },
  name: { type: String, default: '' },
  depth: { type: Number, default: 0 },
  openDepth: { type: Number, default: 1 },
  highlight: { type: String, default: '' },
})
const isArray = computed(() => Array.isArray(props.value))
const isContainer = computed(() => props.value !== null && typeof props.value === 'object')
const size = computed(() => (isArray.value ? props.value.length : isContainer.value ? Object.keys(props.value).length : 0))
const sizeLabel = computed(() => (isArray.value ? "[" + size.value + "]" : "{" + size.value + " keys}"))
const open = ref(props.depth < props.openDepth)
const limit = ref(200)
const strLimit = 600
const showFull = ref(false)
const shownEntries = computed(() => {
  if (!isContainer.value) return []
  if (isArray.value) {
    const out = []
    for (let i = 0; i < Math.min(props.value.length, limit.value); i += 1) out.push([i, props.value[i]])
    return out
  }
  const out = []
  for (const key in props.value) {
    if (!Object.prototype.hasOwnProperty.call(props.value, key)) continue
    out.push([key, props.value[key]])
    if (out.length >= limit.value) break
  }
  return out
})
</script>
