<template>
  <button type="button" class="copy-btn" :class="{ done: state === 'done', fail: state === 'fail' }" :aria-label="feedbackLabel" :title="feedbackLabel" :disabled="state === 'copying'" @click.stop="copy">
    <v-icon :icon="state === 'done' ? mdiCheck : state === 'fail' ? mdiAlertCircleOutline : mdiContentCopy" size="13" />
    <span>{{ state === 'done' ? 'Copied' : state === 'fail' ? 'Failed' : state === 'copying' ? 'Copying' : text }}</span>
  </button>
  <span v-if="state === 'fail'" class="copy-help">Select the text manually.</span>
  <span v-if="copyTruncated" class="copy-help">First 2 MB copied.</span>
  <span class="sr-only" role="status" aria-live="polite">{{ feedbackLabel }}</span>
</template>

<script setup>
import { computed, onBeforeUnmount, ref } from 'vue'
import { mdiAlertCircleOutline, mdiCheck, mdiContentCopy } from '@mdi/js'

// value may be a string or a function returning one (lazy: big frames are only stringified on click).
const props = defineProps({ value: { type: [String, Function], required: true }, text: { type: String, default: 'Copy' }, label: { type: String, default: 'Copy to clipboard' } })
const state = ref('idle')
const copyTruncated = ref(false)
let timer = null
const feedbackLabel = computed(() => {
  if (state.value === 'done') return `${props.label} succeeded`
  if (state.value === 'fail') return `${props.label} failed. Select the text manually.`
  if (state.value === 'copying') return `${props.label} in progress`
  return props.label
})

async function copy() {
  clearTimeout(timer)
  copyTruncated.value = false
  state.value = 'copying'
  let v = ''
  try {
    v = typeof props.value === 'function' ? props.value() : props.value
    v = String(v ?? '')
    if (v.length > 2_000_000) {
      copyTruncated.value = true
      v = `${v.slice(0, 2_000_000)}\n\n[Frame Lab copy limit reached]`
    }
    if (!navigator.clipboard?.writeText) throw new Error('Clipboard API unavailable')
    await navigator.clipboard.writeText(v)
    state.value = 'done'
  } catch {
    // Clipboard API can be unavailable (non-secure context); fall back to a hidden textarea.
    let ta = null
    const focusTarget = document.activeElement
    try {
      if (!v) v = typeof props.value === 'function' ? String(props.value() ?? '') : String(props.value ?? '')
      ta = document.createElement('textarea')
      ta.value = v
      ta.setAttribute('readonly', '')
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      state.value = ok ? 'done' : 'fail'
    } catch { state.value = 'fail' } finally {
      ta?.remove()
      if (state.value === 'done' || state.value === 'fail') focusTarget?.focus?.({ preventScroll: true })
    }
  }
  timer = setTimeout(() => { state.value = 'idle' }, 1400)
}
onBeforeUnmount(() => clearTimeout(timer))
</script>
