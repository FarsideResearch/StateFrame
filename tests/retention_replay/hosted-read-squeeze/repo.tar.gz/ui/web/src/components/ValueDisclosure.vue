<template>
  <details class="value-disclosure" @click.stop @keydown.stop>
    <summary :aria-label="`Show full ${label}`" :title="displayValue">{{ compact ? 'Full' : displayValue }}</summary>
    <div class="value-disclosure__full">
      <span class="sr-only">Full {{ label }}</span>
      <code>{{ displayValue }}</code>
    </div>
  </details>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({
  value: { type: [String, Number], default: '' },
  label: { type: String, default: 'value' },
  compact: { type: Boolean, default: false },
})
const displayValue = computed(() => props.value === '' || props.value == null ? 'not recorded' : String(props.value))
</script>
