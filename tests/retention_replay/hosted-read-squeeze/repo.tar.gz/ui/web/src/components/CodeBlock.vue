<template>
  <div class="code" :class="{ capped: !!maxHeight, nowrap: !wrap }" :style="maxHeight ? { '--code-max': maxHeight } : undefined">
    <div class="code-bar"><CopyButton :value="() => text" text="Copy" label="Copy this code block" /></div>
    <pre ref="pre"><HighlightText :text="text" :q="q" /></pre>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import CopyButton from './CopyButton.vue'
import HighlightText from './HighlightText.vue'

// Monospace block with wrapping, optional internal scroll cap, find-highlighting and a copy button.
defineProps({ text: { type: String, default: '' }, q: { type: String, default: '' }, maxHeight: { type: String, default: '' }, wrap: { type: Boolean, default: true } })
const pre = ref(null)
defineExpose({ pre })
</script>
