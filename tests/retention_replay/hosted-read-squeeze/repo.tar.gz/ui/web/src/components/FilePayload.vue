<template>
  <div class="stack">
    <div class="row wrap">
      <span class="mono strong ellip" :title="payload.name">{{ payload.name }}</span>
      <span class="tag sm outline">{{ valueLabel(payload.kind) }}</span>
      <span class="tag sm outline">{{ fmtBytes(payload.size) }}</span>
      <span v-if="payload.truncated" class="tag sm tone-warning">truncated, showing {{ tailNote }}</span>
      <span v-if="payload.truncated && payload.read_bytes" class="tag sm outline">{{ fmtBytes(payload.read_bytes) }} read</span>
      <span v-if="payload.schema_status && payload.schema_status !== 'ok'" class="tag sm tone-warning">Schema: {{ valueLabel(payload.schema_status) }}</span>
      <span v-if="payload.pointer" class="tag sm mono outline">pointer {{ payload.pointer }}</span>
      <button v-if="payload.pointer" type="button" class="tag sm clickable outline" :disabled="busy" aria-label="Move to parent JSON value" @click="emit('query', { pointer: parentPointer(payload.pointer), offset: 0, records: undefined })">Up</button>
      <button v-if="payload.pointer" type="button" class="tag sm clickable outline" :disabled="busy" aria-label="Move to JSON root" @click="emit('query', { pointer: '', offset: 0, records: undefined })">Root</button>
    </div>

    <template v-if="payload.kind === 'markdown'">
      <v-tabs v-model="mdTab">
        <v-tab value="render">Rendered</v-tab>
        <v-tab value="tables" :disabled="!payload.tables?.length">Parsed tables ({{ payload.tables?.length || 0 }})</v-tab>
        <v-tab value="source">Source</v-tab>
      </v-tabs>
      <MdView v-if="mdTab === 'render'" :source="payload.text" :artifact="artifact" />
      <MdTables v-else-if="mdTab === 'tables'" :tables="payload.tables" />
      <CodeBlock v-else :text="payload.text" />
    </template>

    <CodeBlock v-else-if="payload.kind === 'text'" :text="payload.text" />

    <template v-else-if="payload.kind === 'json' || payload.kind === 'jsonl'">
      <div v-if="payload.arrays?.length" class="row wrap">
        <span class="kicker">Record arrays</span>
        <button
          v-for="a in payload.arrays" :key="a.pointer" type="button" class="tag mono clickable outline"
          :class="{ selected: a.pointer === payload.records?.pointer || (payload.kind === 'jsonl' && a.pointer === payload.pointer) }"
          :aria-pressed="a.pointer === payload.records?.pointer || (payload.kind === 'jsonl' && a.pointer === payload.pointer)"
          :aria-label="`Inspect record array ${a.pointer}, ${a.length} records`"
          :disabled="busy"
          @click="emit('query', { records: a.pointer, offset: 0 })"
        >{{ a.pointer }} [{{ a.length }}]</button>
      </div>

      <template v-if="payload.analysis">
        <section>
          <div class="kicker section-label">{{ payload.analysis.scope === 'dataset' ? 'Dataset' : 'Page' }} metrics, Wilson 95% CI{{ payload.analysis.arm_key ? ` by "${valueLabel(payload.analysis.arm_key)}"` : '' }}</div>
          <div class="small muted metric-note">
            {{ payload.analysis.valid_records }} valid of {{ payload.analysis.n }} records
            <span v-if="payload.analysis.excluded_records">; {{ payload.analysis.excluded_records }} invalid records excluded</span>
            <span v-if="payload.analysis.declared">; declared experiment metric</span>
          </div>
          <EmptyState v-if="!payload.analysis.metrics.length" title="No eligible metrics" hint="No declared or well-defined boolean metric has enough known values to calculate a rate." />
          <div class="table-scroll code" style="background: transparent; max-height: 50vh">
            <table class="fl-table">
              <thead><tr><th>Arm</th><th>Metric</th><th class="r">Known / eligible</th><th class="r">Rate</th><th>95% CI</th><th>Unknown</th></tr></thead>
              <tbody>
                <tr v-for="(m, i) in payload.analysis.metrics" :key="i">
                  <td class="mono">{{ m.arm }}</td><td class="mono" :title="m.field">{{ m.label || valueLabel(m.field) }} <span class="tiny muted">({{ valueLabel(m.direction) }})</span></td>
                  <td class="num">{{ m.k }} / {{ m.eligible ?? m.n }}</td>
                  <td class="num strong">{{ metricText(m) }}</td>
                  <td>
                    <template v-if="m.ci95">
                      <div class="row">
                        <div class="ci-track"><div class="ci-fill" :style="{ left: m.ci95[0] * 100 + '%', width: (m.ci95[1] - m.ci95[0]) * 100 + '%' }" /></div>
                        <span class="tiny mono muted">[{{ (m.ci95[0] * 100).toFixed(0) }}, {{ (m.ci95[1] * 100).toFixed(0) }}]</span>
                      </div>
                    </template>
                    <span v-else class="muted">unknown</span>
                  </td>
                  <td class="num">{{ m.unknown || 0 }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
        <section v-if="Object.keys(payload.analysis.categorical).length">
          <div class="kicker section-label">Categorical breakdown</div>
          <div v-for="(byArm, field) in payload.analysis.categorical" :key="field" class="stack" style="gap: 4px; margin-bottom: 10px">
            <span class="mono small strong">{{ field }}</span>
            <div v-for="(counts, arm) in byArm" :key="arm" class="row wrap" style="gap: 4px">
              <span class="mono tiny muted">{{ arm }}</span>
              <span v-for="(n, v) in counts" :key="v" class="tag sm">{{ v }} <span class="muted">{{ n }}</span></span>
            </div>
          </div>
        </section>
      </template>

      <section v-if="payload.records || payload.kind === 'jsonl'">
        <div class="row section-label">
          <span class="kicker">Cases {{ recordRows.length ? `${recordsOffset + 1}-${recordsOffset + recordRows.length}` : 'none' }} of {{ recordsTotal }}</span>
          <span class="grow" />
          <v-btn :prepend-icon="mdiChevronLeft" :disabled="busy || recordsOffset === 0" @click="emit('query', { records: payload.records?.pointer, offset: Math.max(0, recordsOffset - 200) })">Prev</v-btn>
          <v-btn :append-icon="mdiChevronRight" :disabled="busy || recordsOffset + recordRows.length >= recordsTotal" @click="emit('query', { records: payload.records?.pointer, offset: recordsOffset + 200 })">Next</v-btn>
        </div>
        <div class="table-scroll code" style="background: transparent; max-height: 60vh">
          <table class="fl-table">
            <thead><tr><th>#</th><th v-for="c in columns" :key="c" style="text-transform: none">{{ c }}</th><th>Links</th></tr></thead>
            <tbody>
              <template v-for="row in recordRows" :key="row.idx">
                <tr class="click focusable-row" tabindex="0" role="button" :aria-expanded="expanded === row.idx" :aria-label="`Expand record ${row.idx}`" @click="toggleRecord(row.idx)" @keydown.enter.prevent="toggleRecord(row.idx)" @keydown.space.prevent="toggleRecord(row.idx)">
                  <td class="mono tiny muted">{{ row.idx }}</td>
                  <td v-for="c in columns" :key="c" class="ellip" style="max-width: 220px" :title="cell(recordValue(row.record, c))">{{ cell(recordValue(row.record, c)) }}</td>
                  <td>
                    <RouterLink v-for="l in row.run_links" :key="l" class="small mono" style="margin-right: 8px; white-space: nowrap" :to="{ name: 'run', query: { id: l } }" @click.stop>{{ l.split('/').slice(-2).join('/') }}</RouterLink>
                  </td>
                </tr>
                <tr v-if="expanded === row.idx"><td :colspan="columns.length + 2" style="background: var(--fl-c-subtle)"><RawDisclosure :value="row.record" label="Raw record" :open-depth="2" /></td></tr>
              </template>
            </tbody>
          </table>
        </div>
        <EmptyState v-if="!recordRows.length" title="No records on this page" hint="This pointer is valid but the selected page is empty. Return to the previous page or choose another record array." />
      </section>

      <section v-if="payload.items" class="stack">
        <div class="row section-label">
          <span class="kicker">Values {{ payload.items.total ? `${payload.items.offset + 1}-${payload.items.offset + payload.items.rows.length}` : 'none' }} of {{ payload.items.total }}</span>
          <span class="grow" />
          <v-btn :prepend-icon="mdiChevronLeft" :disabled="busy || payload.items.offset === 0" @click="emit('query', { offset: Math.max(0, payload.items.offset - 200) })">Prev</v-btn>
          <v-btn :append-icon="mdiChevronRight" :disabled="busy || payload.items.offset + payload.items.rows.length >= payload.items.total" @click="emit('query', { offset: payload.items.offset + 200 })">Next</v-btn>
        </div>
        <div class="table-scroll code" style="background: transparent; max-height: 60vh">
          <table class="fl-table"><thead><tr><th>#</th><th>Value</th></tr></thead><tbody>
            <tr v-for="row in payload.items.rows" :key="row.idx"><td class="num">{{ row.idx }}</td><td class="mono">{{ cell(row.value) }}</td></tr>
          </tbody></table>
        </div>
        <EmptyState v-if="!payload.items.rows.length" title="No values on this page" hint="This array is empty at the selected offset. Return to the previous page or choose the root." />
      </section>

      <section>
        <RawDisclosure v-if="payload.inline && payload.has_value" :value="payload.data" label="Raw JSON" />
        <div v-else-if="payload.top" class="stack" style="gap: 6px">
          <div class="small muted">Large file. Pick a key to load it lazily.</div>
          <div class="row wrap" style="gap: 6px">
            <button
              v-for="(info, k) in payload.top" :key="k" type="button" class="tag mono clickable outline"
              :disabled="busy"
              :aria-label="`Load JSON key ${k}`"
              @click="emit('query', { pointer: `${payload.pointer || ''}/${String(k).replace(/~/g, '~0').replace(/\//g, '~1')}` })"
            >{{ k }} <span class="muted">{{ info[0] }} {{ info[1] }}</span></button>
          </div>
        </div>
        <div v-else-if="payload.chunk" class="stack">
          <div class="small muted">Large string, showing {{ payload.chunk.offset + 1 }}-{{ payload.chunk.offset + payload.chunk.text.length }} of {{ payload.chunk.total }} characters.</div>
          <CodeBlock :text="payload.chunk.text" />
           <v-btn :disabled="busy || payload.chunk.offset === 0" @click="emit('query', { chunk_offset: Math.max(0, payload.chunk.offset - payload.chunk.limit) })">Previous chunk</v-btn>
           <v-btn :disabled="busy || !payload.chunk.truncated" @click="emit('query', { chunk_offset: payload.chunk.offset + payload.chunk.limit })">Next chunk</v-btn>
        </div>
        <div v-else-if="payload.value_type === 'null'" class="small muted">This value is JSON null. It is present and intentionally has no child fields.</div>
        <div v-else-if="payload.value_type" class="small muted">This {{ valueLabel(payload.value_type).toLowerCase() }} value is outside the inline preview budget. Use its bounded page or choose a smaller child value.</div>
        <div v-else-if="payload.kind === 'jsonl'" class="small muted">JSONL lines are shown as cases above.</div>
      </section>
    </template>

    <EmptyState v-else title="No preview" :hint="`This ${valueLabel(payload.kind)} file has no preview. Choose a Markdown, text, or JSON file from the list.`" />
  </div>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { mdiChevronLeft, mdiChevronRight } from '@mdi/js'
import { fmtBytes } from '../api'
import { valueLabel } from '../value-labels.js'
import { cellText, metricText, parentPointer, recordValue } from '../evidence-state.js'
import RawDisclosure from './RawDisclosure.vue'
import MdView from './MdView.vue'
import MdTables from './MdTables.vue'
import CodeBlock from './CodeBlock.vue'
import EmptyState from './EmptyState.vue'

const props = defineProps({ payload: { type: Object, required: true }, busy: { type: Boolean, default: false }, artifact: { type: Object, default: null } })
const artifact = computed(() => props.artifact)
const emit = defineEmits(['query'])
const mdTab = ref('render')
const expanded = ref(null)
// A new file or page of records must not inherit the previous expansion or markdown tab.
watch(() => [props.payload.name, props.payload.records?.offset, props.payload.pointer], () => { expanded.value = null })
watch(() => props.payload.name, () => { mdTab.value = 'render' })
const recordRows = computed(() => props.payload.records?.rows || props.payload.rows || [])
const recordsOffset = computed(() => props.payload.records?.offset ?? props.payload.offset ?? 0)
const recordsTotal = computed(() => props.payload.records?.total ?? props.payload.total ?? 0)
const columns = computed(() => (props.payload.analysis?.columns || []).slice(0, 14))
const tailNote = computed(() => (/\.(out|log)$/.test(props.payload.name || '') ? 'the tail' : 'the head'))
function cell(v) {
  return cellText(v)
}
function toggleRecord(idx) {
  expanded.value = expanded.value === idx ? null : idx
}
</script>
