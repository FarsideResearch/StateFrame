<template>
  <span class="row-value-cell">
    <RouterLink v-if="to" ref="textEl" class="ellip" :to="to" :title="raw" @click.stop>{{ shown }}</RouterLink>
    <span v-else ref="textEl" class="ellip" :title="raw">{{ shown }}</span>
    <!-- The "Full" control appears only when the cell actually cuts the text off. -->
    <ValueDisclosure v-if="overflowing" :value="raw" :label="label" compact />
  </span>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import ValueDisclosure from './ValueDisclosure.vue'

const props = defineProps({ value: { type: [String, Number], default: '' }, display: { type: String, default: '' }, label: { type: String, required: true }, to: { type: [String, Object], default: null } })
const raw = computed(() => props.value == null || props.value === '' ? 'not recorded' : String(props.value))
const shown = computed(() => props.display || raw.value)

const textEl = ref(null)
const overflowing = ref(false)
let observer = null

function element() {
  const target = textEl.value
  return target && target.$el ? target.$el : target
}

function measure() {
  const el = element()
  overflowing.value = Boolean(el && el.scrollWidth > el.clientWidth + 1)
}

onMounted(() => {
  measure()
  const el = element()
  if (typeof ResizeObserver === 'function' && el) {
    observer = new ResizeObserver(measure)
    observer.observe(el)
  }
})
watch(shown, () => nextTick(measure))
onBeforeUnmount(() => observer?.disconnect())
</script>
