<template>
  <section class="panel comparison-panel" aria-labelledby="comparison-title">
    <div class="panel-head">
      <div>
        <h2 id="comparison-title" class="title">Experiment comparison</h2>
      </div>
      <span class="end tag sm" :class="comparison.status === 'ready' ? toneClass('success') : 'outline'">{{ comparison.status === 'ready' ? 'Ready' : comparison.status === 'partial' ? 'Limited' : 'No comparison' }}</span>
    </div>
    <div class="panel-body">
      <p class="comparison-lead">{{ lead }}</p>
      <p class="small muted">{{ comparison.paired_count ?? 0 }} matched pairs. A small sample may not predict later results. Pairs use the declared match keys.</p>
      <div v-if="comparison.arms?.length" class="comparison-arm-row">
        <span v-for="arm in comparison.arms" :key="arm.id" class="tag outline">{{ arm.label }}</span>
        <span class="tiny muted">matched by {{ comparison.match_keys?.map(valueLabel).join(', ') || 'no keys' }}</span>
      </div>
      <v-alert v-for="warning in comparison.warnings || []" :key="warning" type="warning" density="compact" class="mb-2">{{ warningText(warning) }}</v-alert>
      <div v-if="comparison.metrics?.length" class="comparison-metrics table-x">
        <table class="fl-table">
          <thead><tr><th>Metric</th><th v-for="arm in comparison.arms" :key="arm.id" class="r">{{ arm.label }}</th><th class="r">Difference</th><th>Leads on this measure</th></tr></thead>
          <tbody>
            <tr v-for="metric in comparison.metrics" :key="metric.key">
              <th>{{ metric.label }} <span class="tiny muted">({{ valueLabel(metric.direction) }})</span></th>
              <td v-for="arm in comparison.arms" :key="arm.id" class="num">{{ metricValue(metric.arms?.[arm.id]) }}</td>
              <td class="num">{{ deltaValue(metric.delta, metric.arms?.[comparison.arms?.[0]?.id]?.kind) }}</td>
              <td>{{ armLabel(metric.better_arm) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="comparison-summary row wrap">
        <span class="tag sm outline">{{ comparison.paired_count ?? 0 }} matched pairs</span>
        <span class="tag sm outline">{{ comparison.discordant?.length ?? 0 }} discordant cases</span>
        <span class="tag sm outline">{{ comparison.excluded_count ?? 0 }} excluded</span>
      </div>
      <details v-if="comparison.discordant?.length" class="comparison-cases">
        <summary>Inspect discordant cases</summary>
        <div v-for="pair in comparison.discordant" :key="JSON.stringify(pair.match)" class="comparison-case">
          <div class="comparison-case__key mono small">{{ matchLabel(pair.match) }}</div>
          <div v-for="arm in comparison.arms" :key="arm.id" class="comparison-case__arm">
            <span class="kicker">{{ arm.label }}</span>
            <span class="small">{{ caseSummary(pair.cases?.[arm.id]) }}</span>
            <RouterLink v-for="runId in pair.run_links?.[arm.id] || []" :key="runId" class="tiny" :to="{ name: 'run', query: { id: runId } }">Open {{ runId }}</RouterLink>
          </div>
        </div>
      </details>
      <div v-else class="small muted">No discordant cases are available for the declared primary metric.</div>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { toneClass } from '../api'
import { valueLabel } from '../value-labels.js'

const props = defineProps({ comparison: { type: Object, default: () => ({ status: 'unavailable' }) } })
const comparison = computed(() => props.comparison || { status: 'unavailable' })
const lead = computed(() => {
  const arms = comparison.value.arms || []
  const count = comparison.value.paired_count ?? 0
  if (!arms.length) return 'No declared variants are available for comparison.'
  const names = arms.map((arm) => arm.label).join(' and ')
  const metric = comparison.value.metrics?.[0]
  if (!metric || !count) return `${names} have no matched results to compare.`
  const winner = metric.better_arm ? armLabel(metric.better_arm) : null
  return `${names} were compared across ${count} matched pair${count === 1 ? '' : 's'}. ${winner ? `${winner} leads on ${metric.label}.` : `Neither leads on ${metric.label}.`}`
})

function metricValue(summary) {
  if (!summary || summary.value == null) return 'not recorded'
  return summary.kind === 'boolean' ? `${(summary.value * 100).toFixed(1)}% (${summary.n} eligible)` : `${summary.value.toFixed(1)} (${summary.n} eligible)`
}
function deltaValue(value, kind) {
  if (value == null) return 'not recorded'
  return `${value > 0 ? '+' : ''}${kind === 'boolean' ? `${(value * 100).toFixed(1)} pp` : value.toFixed(1)}`
}
function armLabel(id) { return comparison.value.arms?.find((arm) => arm.id === id)?.label || id || 'none' }
function warningText(value) {
  if (value.includes('stateframe.experiment.v1')) return 'This experiment needs a comparison settings file before its variants can be compared.'
  if (value.includes('match_keys')) return 'Matching fields are needed to compare cases.'
  if (value.includes('exactly two declared arms')) return 'Two named variants are needed for a paired comparison.'
  return value
}
function matchLabel(match) { return Object.entries(match || {}).map(([key, value]) => `${valueLabel(key)}: ${value}`).join(' · ') }
function caseSummary(value) {
  if (!value) return 'missing case'
  return Object.entries(value).filter(([key]) => ['pass', 'input_tokens', 'latency_ms'].includes(key)).map(([key, item]) => `${valueLabel(key)}: ${item}`).join(' · ') || 'recorded case'
}
</script>
