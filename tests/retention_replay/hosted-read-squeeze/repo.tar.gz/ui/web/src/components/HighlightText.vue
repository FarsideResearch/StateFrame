<template>
  <span><template v-for="(p, i) in parts" :key="i"><mark v-if="p.hit" class="hl">{{ p.t }}</mark><template v-else>{{ p.t }}</template></template><span v-if="limited && q" class="tiny muted"> Search limited to first 500,000 characters.</span></span>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ text: { type: String, default: '' }, q: { type: String, default: '' } })
const MAX_HIGHLIGHT_CHARS = 500_000
// Splits text around case-insensitive matches of q; rendered as text nodes (no v-html).
const parts = computed(() => {
  const t = (props.text || '').slice(0, MAX_HIGHLIGHT_CHARS)
  const q = (props.q || '').toLowerCase()
  if (!q) return [{ t, hit: false }]
  const low = t.toLowerCase()
  const out = []
  let i = 0
  for (;;) {
    const j = low.indexOf(q, i)
    if (j < 0) { out.push({ t: t.slice(i), hit: false }); break }
    if (j > i) out.push({ t: t.slice(i, j), hit: false })
    out.push({ t: t.slice(j, j + q.length), hit: true })
    i = j + q.length
    if (out.length > 2000) { out.push({ t: t.slice(i), hit: false }); break }
  }
  return out
})
const limited = computed(() => (props.text || '').length > MAX_HIGHLIGHT_CHARS)
</script>
