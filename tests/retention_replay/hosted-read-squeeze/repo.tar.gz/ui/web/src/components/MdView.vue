<template>
  <!-- markdown-it runs with html:false, so raw HTML in sources is escaped, never injected. -->
  <!-- eslint-disable-next-line vue/no-v-html -->
  <div v-if="limited" class="small muted">This document is larger than the interactive render budget; showing the first 1 MB.</div>
  <div class="md-body" v-html="html" />
</template>

<script setup>
import { computed } from 'vue'
import { createArtifactMarkdownRenderer } from '../markdown-policy'

const props = defineProps({ source: { type: String, default: '' }, artifact: { type: Object, default: null } })
const MAX_MARKDOWN_CHARS = 1_000_000
const limited = computed(() => (props.source || '').length > MAX_MARKDOWN_CHARS)
const renderSource = computed(() => {
  const source = props.source || ''
  return limited.value ? `${source.slice(0, MAX_MARKDOWN_CHARS)}\n\n[Frame Lab render limit reached]` : source
})
const html = computed(() => createArtifactMarkdownRenderer({ artifact: props.artifact }).render(renderSource.value))
</script>
