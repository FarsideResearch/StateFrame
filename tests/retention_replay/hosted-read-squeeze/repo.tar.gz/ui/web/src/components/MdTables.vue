<template>
  <div class="stack">
    <EmptyState v-if="!tables.length" title="No tables" hint="No markdown tables were parsed from this file." />
    <section v-for="(t, ti) in tables" :key="ti" class="stack" style="gap: 6px">
      <div class="row">
        <h2 class="strong">{{ t.heading || 'Table' }}</h2>
        <span class="tiny muted">line {{ t.line }}, {{ t.rows.length }} rows, showing {{ visibleRows(ti, t).length }}</span>
      </div>
      <div class="table-scroll code" style="background: transparent; max-height: 60vh">
        <table class="fl-table">
          <caption class="sr-only">{{ t.heading || 'Markdown table' }}, {{ t.rows.length }} rows</caption>
          <thead>
            <tr>
              <th v-for="(h, i) in t.header" :key="i" scope="col" class="sortable" :aria-sort="sort[ti]?.col === i ? (sort[ti].desc ? 'descending' : 'ascending') : 'none'">
                <button type="button" class="table-sort" :aria-label="`Sort by ${h}`" @click="sortBy(ti, i)">
                  {{ h }}<v-icon v-if="sort[ti]?.col === i" :icon="sort[ti].desc ? mdiArrowDown : mdiArrowUp" size="11" aria-hidden="true" />
                </button>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(r, ri) in visibleRows(ti, t)" :key="ri">
              <td v-for="(c, ci) in r" :key="ci" :class="{ num: isNum(c) }" :title="c">{{ c }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="visibleRows(ti, t).length < t.rows.length" class="row">
        <span class="muted small">Additional rows are bounded to keep the page responsive.</span>
        <v-btn size="small" variant="text" @click="showMore(ti)">Show more rows</v-btn>
      </div>
    </section>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import { mdiArrowDown, mdiArrowUp } from '@mdi/js'
import EmptyState from './EmptyState.vue'

defineProps({ tables: { type: Array, default: () => [] } })
const sort = reactive({})
const limits = reactive({})
function isNum(c) { return /^[-+]?[\d.,]+%?$/.test((c || '').replace(/[`*]/g, '').trim()) }
function key(c) {
  const s = (c || '').replace(/[`*]/g, '').trim()
  const n = parseFloat(s.replace(/,/g, ''))
  return Number.isFinite(n) && isNum(s) ? n : s.toLowerCase()
}
function sortBy(ti, i) {
  const cur = sort[ti]
  sort[ti] = cur && cur.col === i ? { col: i, desc: !cur.desc } : { col: i, desc: false }
}
function showMore(ti) { limits[ti] = (limits[ti] || 100) + 100 }
// Mixed numeric/text columns: numbers sort before text so the comparison stays total.
function cmp(x, y) {
  const nx = typeof x === 'number', ny = typeof y === 'number'
  if (nx !== ny) return nx ? -1 : 1
  return x > y ? 1 : x < y ? -1 : 0
}
function sorted(t, ti) {
  const s = sort[ti]
  if (!s) return t.rows
  return [...t.rows].sort((a, b) => cmp(key(a[s.col]), key(b[s.col])) * (s.desc ? -1 : 1))
}
function visibleRows(ti, t) { return sorted(t, ti).slice(0, limits[ti] || 100) }
</script>
