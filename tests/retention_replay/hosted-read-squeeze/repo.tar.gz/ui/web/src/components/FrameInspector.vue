<template>
  <div ref="frameBody" class="stack frame-inspector" style="height: 100%; gap: 10px">
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="loadFrame">Retry</v-btn></v-alert>
    <div v-if="loading && !f" class="panel"><LoadingRows :rows="8" /></div>
    <template v-if="f">
      <div class="row wrap" style="flex: none">
        <v-btn :icon="mdiChevronLeft" size="x-small" :disabled="!f.prev_request_id" aria-label="Previous frame" @click="emit('navigate', f.prev_request_id)" />
        <span class="mono strong">Frame {{ f.n }}</span>
        <v-btn :icon="mdiChevronRight" size="x-small" :disabled="!f.next_request_id" aria-label="Next frame" @click="emit('navigate', f.next_request_id)" />
        <span class="tag sm outline">step {{ f.step ?? 'not recorded' }}</span>
        <span class="tag sm outline">{{ f.messages.length }} messages</span>
        <span class="tag sm outline">{{ fmtNum(f.chars) }} chars</span>
        <span v-if="f.attempt_id" class="tag sm mono outline" :title="f.request_id">attempt {{ f.attempt_id.split('@event-').pop() }}</span>
        <span v-if="f.schema_status && f.schema_status !== 'ok'" class="tag sm tone-warning">schema {{ f.schema_status }}</span>
        <span v-if="f.response?.accounting?.prompt_n != null" class="tag sm tone-primary">{{ fmtNum(f.response.accounting.prompt_n) }} prompt tok</span>
        <span v-if="completionTok != null" class="tag sm tone-success">{{ fmtNum(completionTok) }} completion tok</span>
        <span v-if="f.capacity?.prompt_tokens != null" class="tag sm outline">est {{ fmtNum(f.capacity.prompt_tokens) }} / {{ fmtNum(f.capacity.context_limit) }}</span>
        <span v-if="f.overflow" class="tag sm tone-warning">overflow</span>
        <span v-if="f.response?.finish_reason" class="tag sm" :class="f.response.finish_reason === 'length' ? 'tone-error' : 'outline'">{{ f.response.finish_reason }}</span>
        <span v-if="f.response?.elapsed_s" class="tag sm outline">{{ f.response.elapsed_s }}s</span>
        <span class="grow" />
        <v-progress-circular v-if="loading" indeterminate size="16" width="2" color="primary" />
        <CopyButton :value="frameJson" text="Copy frame" label="Copy the full frame as JSON" />
        <span v-if="localQ" class="tiny muted">{{ hitTotal }} hits</span>
        <v-btn v-if="localQ" size="x-small" variant="text" :disabled="!hitTotal" aria-label="Previous frame match" @click="jumpHit(-1)">Prev hit</v-btn>
        <v-btn v-if="localQ" size="x-small" variant="text" :disabled="!hitTotal" aria-label="Next frame match" @click="jumpHit(1)">Next hit</v-btn>
        <v-text-field v-model="localQ" :prepend-inner-icon="mdiMagnify" label="Find in frame" placeholder="Text in messages or response" style="max-width: 220px; min-width: 160px" clearable />
      </div>
      <v-tabs v-model="sub">
        <v-tab value="side">Frame and response</v-tab>
        <v-tab value="selection">Selection ({{ f.selection ? f.selection.selected.length + ' in, ' + f.selection.omitted.length + ' out' : 'none' }})</v-tab>
        <v-tab value="tools">Tools ({{ f.tool_names.length }})</v-tab>
        <v-tab value="diff" :disabled="!f.prev_request_id">Diff vs previous</v-tab>
        <v-tab value="raw">Audit and raw</v-tab>
      </v-tabs>

      <div v-if="sub === 'side'" class="split frame-side grow">
        <section class="panel">
          <div class="panel-head">
            <h2 class="title" title="The exact payload.messages sent to the model">Sent to model</h2>
            <div class="end">
              <button type="button" class="copy-btn" @click="setAll(true)">Collapse</button>
              <button type="button" class="copy-btn" @click="setAll(false)">Expand</button>
            </div>
          </div>
          <div class="panel-body">
              <div v-for="(m, i) in f.messages" :key="i" class="msg" :class="`role-${m.role}`">
              <button type="button" class="msg-head" :aria-expanded="!collapsed[i]" @click="toggle(i)">
                <v-icon :icon="collapsed[i] ? mdiChevronRight : mdiChevronDown" size="14" class="muted" />
                <span class="role-label">{{ m.role }}</span>
                <span class="tiny muted">#{{ i }}, {{ fmtNum(msgText(m).length) }} chars</span>
                <span v-if="m.tool_calls" class="tiny muted">{{ m.tool_calls.length }} tool calls</span>
          <span v-if="messageHitCount(m)" class="hl tiny">{{ messageHitCount(m) }} hits</span>
              </button>
              <CodeBlock v-if="!collapsed[i]" :text="msgText(m)" :q="localQ" />
            </div>
          </div>
        </section>
        <section class="panel">
          <div class="panel-head"><h2 class="title">Model response</h2></div>
          <div class="panel-body">
            <template v-if="f.response?.message">
              <template v-if="f.response.message.reasoning_content">
                <div class="kicker section-label">Reasoning</div>
                <CodeBlock :text="f.response.message.reasoning_content" :q="localQ" />
              </template>
              <template v-if="f.response.message.content">
                <div class="kicker section-label">Content</div>
                <CodeBlock :text="String(f.response.message.content)" :q="localQ" />
              </template>
              <template v-if="(f.response.message.tool_calls || []).length">
                <div class="kicker section-label">Tool calls</div>
                <div v-for="(tc, i) in f.response.message.tool_calls" :key="i" class="msg role-assistant">
                  <div class="mono strong" style="padding-bottom: 6px">{{ tc.function?.name }}</div>
                  <CodeBlock :text="prettyArgs(tc.function?.arguments)" :q="localQ" />
                </div>
              </template>
            </template>
            <EmptyState v-else title="No response recorded" hint="There is no response_received event for this request." />
            <template v-if="f.response">
              <div class="kicker section-label">Token usage</div>
              <dl class="key-values">
                <dt>Prompt tokens</dt><dd>{{ f.response.accounting?.prompt_n ?? 'not recorded' }}</dd>
                <dt>Completion tokens</dt><dd>{{ completionTok ?? 'not recorded' }}</dd>
              </dl>
              <RawDisclosure :value="{ accounting: f.response.accounting, logical: f.response.logical_token_accounting }" label="Raw token accounting" />
            </template>
          </div>
        </section>
      </div>

      <section v-else-if="sub === 'selection'" class="panel grow">
        <div class="panel-body">
          <EmptyState v-if="!f.selection" title="No selection decision" hint="No selection_decision was recorded for this request." />
          <template v-else>
            <div class="row wrap" style="margin-bottom: 12px">
              <span class="tag sm outline">mode {{ f.selection.mode }}</span>
              <span class="tag sm outline">applied {{ f.selection.applied }}</span>
              <span class="tag sm mono outline">{{ f.selection.policy_version }}</span>
              <span class="tag sm outline">budget {{ f.selection.budget_tokens }}</span>
              <span v-for="r in f.selection.margin_reasons || []" :key="r" class="tag sm tone-warning">{{ r }}</span>
            </div>
            <div class="split flow">
              <div>
                <div class="kicker section-label">Included ({{ f.selection.selected.length }})</div>
                <div class="table-scroll code" style="background: transparent; max-height: 60vh">
                  <table class="fl-table">
                    <thead><tr><th>Item</th><th>Group</th><th class="r">Prio</th><th class="r">Chars</th><th>Action</th><th>Preview</th></tr></thead>
                    <tbody>
                      <tr v-for="it in f.selection.selected" :key="it.item_id">
                        <td class="mono tiny">{{ it.item_id }}</td><td class="mono tiny">{{ it.group }}</td><td class="num">{{ it.priority }}</td>
                        <td class="num">{{ fmtNum(it.chars) }}</td><td class="tiny">{{ it.action_required ?? 'not recorded' }}</td><td class="tiny mono ellip" style="max-width: 320px" :title="it.preview">{{ it.preview }}</td>
                      </tr>
                      <tr v-if="!f.selection.selected.length"><td colspan="6" class="muted small">No items were included. Choose another frame to inspect a different request.</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <div class="kicker section-label">Omitted ({{ f.selection.omitted.length }})</div>
                <div class="table-scroll code" style="background: transparent; max-height: 60vh">
                  <table class="fl-table">
                    <thead><tr><th>Item</th><th>Reason</th><th>Action</th><th class="r">Chars</th><th>Preview</th></tr></thead>
                    <tbody>
                      <tr v-for="it in f.selection.omitted" :key="it.item_id">
                        <td class="mono tiny">{{ it.item_id }}</td><td class="tiny">{{ it.reason || '(not recorded)' }}</td><td class="tiny">{{ it.action_required ?? 'not recorded' }}</td>
                        <td class="num">{{ fmtNum(it.chars) }}</td><td class="tiny mono ellip" style="max-width: 320px" :title="it.preview">{{ it.preview }}</td>
                      </tr>
                      <tr v-if="!f.selection.omitted.length"><td colspan="5" class="muted small">Nothing omitted.</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div v-if="f.selection_source" class="stack" style="margin-top: 14px">
              <div class="kicker section-label">Selection source event #{{ f.selection_source.event_index }}</div>
              <RawDisclosure :value="f.selection_source.event" label="Raw selection event" />
            </div>
          </template>
        </div>
      </section>

      <section v-else-if="sub === 'tools'" class="panel grow">
        <div class="panel-body">
          <div class="row wrap" style="gap: 6px; margin-bottom: 12px">
            <span v-for="t in f.tool_names" :key="t" class="tag sm mono tone-primary">{{ t }}</span>
            <span v-if="!f.tool_names?.length" class="small muted">No tools were offered in this request. Choose another frame to inspect its tools.</span>
          </div>
          <template v-if="f.tool_menu">
            <div class="kicker section-label">Tool menu composition, event #{{ f.tool_menu.event_index }}</div>
            <RawDisclosure :value="f.tool_menu" label="Raw tool menu" :open-depth="2" />
          </template>
          <div class="kicker section-label">Tool schemas offered</div>
          <RawDisclosure :value="f.tools" label="Raw tool schemas" />
        </div>
      </section>

      <section v-else-if="sub === 'diff'" class="panel grow">
        <div class="panel-body">
          <LoadingRows v-if="diffLoading" :rows="6" />
          <v-alert v-else-if="diffError" type="error">{{ diffError }} <v-btn size="small" variant="text" @click="loadPrevious">Retry previous frame</v-btn></v-alert>
          <EmptyState v-else-if="!f.prev_request_id" title="No previous frame" hint="The first frame has no predecessor to compare." />
          <DiffView v-else :before="frameText(prev)" :after="frameText(f)" />
        </div>
      </section>

      <section v-else class="panel grow">
        <div class="panel-body">
          <dl class="key-values">
            <dt>Step</dt><dd>{{ f.step ?? 'not recorded' }}</dd>
            <dt>Request ID</dt><dd class="mono">{{ f.request_id || 'not recorded' }}</dd>
            <dt>Messages</dt><dd>{{ f.messages.length }}</dd>
            <dt>Tool definitions</dt><dd>{{ f.tools?.length ?? 'not recorded' }}</dd>
          </dl>
          <RawDisclosure :value="auditBlock" label="Raw frame metadata" :highlight="localQ" />
        </div>
      </section>
    </template>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiChevronDown, mdiChevronLeft, mdiChevronRight, mdiMagnify } from '@mdi/js'
import { api, fmtNum } from '../api'
import RawDisclosure from './RawDisclosure.vue'
import DiffView from './DiffView.vue'
import CodeBlock from './CodeBlock.vue'
import CopyButton from './CopyButton.vue'
import EmptyState from './EmptyState.vue'
import LoadingRows from './LoadingRows.vue'
import { createRequestState } from '../request-state.js'

const props = defineProps({
  id: { type: String, required: true }, jref: { type: String, required: true }, rid: { type: String, required: true }, search: { type: String, default: '' }, refreshToken: { type: Number, default: 0 },
})
const emit = defineEmits(['navigate'])
const route = useRoute()
const router = useRouter()
const f = ref(null)
const prev = ref(null)
const error = ref('')
const loading = ref(false)
const SUBTABS = ['side', 'selection', 'tools', 'diff', 'raw']
const sub = computed({
  get: () => SUBTABS.includes(route.query.fsub) ? route.query.fsub : 'side',
  set: (value) => router.replace({ query: { ...route.query, fsub: value === 'side' ? undefined : value } }),
})
const localQ = ref(typeof route.query.ftext === 'string' ? route.query.ftext : '')
const frameBody = ref(null)
const hitTotal = ref(0)
const hitIndex = ref(-1)
const collapsed = reactive({})
const frameRequest = createRequestState()
const diffRequest = createRequestState()
const diffLoading = ref(false)
const diffError = ref('')
const messageTextCache = new WeakMap()
const messageHitCache = new WeakMap()
const MAX_SEARCH_CHARS = 500_000

watch(() => props.search, (v) => { if (v) localQ.value = v; else if (!route.query.ftext) localQ.value = '' }, { immediate: true })
watch(() => route.query.ftext, (value) => { const next = typeof value === 'string' ? value : ''; if (next !== localQ.value) localQ.value = next })
watch(localQ, (value) => router.replace({ query: { ...route.query, ftext: value || undefined } }))
watch(() => [localQ.value, f.value, sub.value], async () => {
  await nextTick()
  hitTotal.value = frameBody.value?.querySelectorAll('mark.hl').length || 0
  hitIndex.value = -1
})
function jumpHit(direction) {
  const hits = [...(frameBody.value?.querySelectorAll('mark.hl') || [])]
  if (!hits.length) return
  hitIndex.value = (hitIndex.value + direction + hits.length) % hits.length
  hits[hitIndex.value].scrollIntoView({ block: 'center', behavior: 'smooth' })
}
async function loadFrame() {
  const request = frameRequest.begin()
  loading.value = true
  error.value = ''
  diffRequest.cancel()
  prev.value = null
  diffError.value = ''
  f.value = null
  try {
    const fr = await api('frame', { id: props.id, j: props.jref, rid: props.rid }, { cached: true, force: props.refreshToken > 0, signal: request.signal })
    if (!frameRequest.isCurrent(request.id)) return
    f.value = fr
    for (const k of Object.keys(collapsed)) delete collapsed[k]
    // Long system prompts start collapsed; everything else open.
    fr.messages.forEach((m, i) => { collapsed[i] = m.role === 'system' && msgText(m).length > 4000 })
    if (!fr.prev_request_id && sub.value === 'diff') sub.value = 'side'
  } catch (e) { if (frameRequest.isCurrent(request.id)) error.value = e.message } finally { if (frameRequest.isCurrent(request.id)) loading.value = false }
}
watch(() => [props.id, props.jref, props.rid, props.refreshToken], loadFrame, { immediate: true })

async function loadPrevious() {
  if (!f.value?.prev_request_id) {
    sub.value = 'side'
    return
  }
  const request = diffRequest.begin()
  diffLoading.value = true
  diffError.value = ''
  prev.value = null
  try {
    const p = await api('frame', { id: props.id, j: props.jref, rid: f.value.prev_request_id }, { cached: true, force: props.refreshToken > 0, signal: request.signal })
    if (diffRequest.isCurrent(request.id)) prev.value = p
  } catch (e) { if (diffRequest.isCurrent(request.id)) diffError.value = e.message } finally { if (diffRequest.isCurrent(request.id)) diffLoading.value = false }
}
watch(() => [sub.value, f.value?.attempt_id], () => {
  if (sub.value === 'diff') loadPrevious()
  else { diffRequest.cancel(); diffLoading.value = false; diffError.value = '' }
})

function msgText(m) {
  const cached = messageTextCache.get(m)
  if (cached !== undefined) return cached
  const c = m.content
  let s = typeof c === 'string' ? c : c == null ? '' : JSON.stringify(c, null, 2)
  if (m.tool_calls) s += (s ? '\n' : '') + m.tool_calls.map((t) => `[tool_call ${t.function?.name}] ${t.function?.arguments}`).join('\n')
  if (m.tool_call_id) s = `[tool_call_id ${m.tool_call_id}]\n` + s
  messageTextCache.set(m, s)
  return s
}
function frameText(fr) {
  // Diff the complete supported request, not only rendered message text and tool names.
  return JSON.stringify(fr?.request_payload || { messages: fr?.messages || [], tools: fr?.tools || [], ...(fr?.params || {}) }, null, 2)
}
function frameJson() { return JSON.stringify(f.value?.request_payload || { messages: f.value?.messages || [], tools: f.value?.tools || [], ...(f.value?.params || {}) }, null, 2) }
function prettyArgs(a) {
  if (typeof a !== 'string') return JSON.stringify(a, null, 2)
  try { return JSON.stringify(JSON.parse(a), null, 2) } catch { return a }
}
function messageHitCount(message) {
  const q = (localQ.value || '').toLowerCase()
  if (!q) return 0
  const cached = messageHitCache.get(message)
  if (cached?.q === q) return cached.count
  const source = msgText(message).slice(0, MAX_SEARCH_CHARS).toLowerCase()
  const count = source.split(q).length - 1
  messageHitCache.set(message, { q, count })
  return count
}
function toggle(i) { collapsed[i] = !collapsed[i] }
function setAll(v) { (f.value?.messages || []).forEach((_, i) => { collapsed[i] = v }) }
const completionTok = computed(() => f.value?.response?.accounting?.raw_usage?.completion_tokens ?? f.value?.response?.accounting?.raw_timings?.predicted_n)
const auditBlock = computed(() => {
  if (!f.value) return {}
  const { messages, tools, ...rest } = f.value
  return rest
})
onBeforeUnmount(() => { frameRequest.cancel(); diffRequest.cancel() })
</script>
