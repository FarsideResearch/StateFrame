<template>
  <section class="panel evidence-overview" aria-labelledby="evidence-overview-title">
    <div class="panel-head evidence-overview__head">
      <div>
        <h2 id="evidence-overview-title" class="title">What happened in this run?</h2>
      </div>
      <span class="end tag sm outline">{{ valueLabel(evidence?.projection, 'Projection unavailable') }}</span>
    </div>
    <div class="panel-body">
      <p class="evidence-overview__intro">Follow the recorded request, actions, checks, and stop reason. Open a linked event or file for details.</p>
      <div class="evidence-question-grid">
        <article v-for="card in cards" :key="card.key" class="evidence-question">
          <div class="evidence-question__topline">
            <span class="kicker">{{ card.question }}</span>
            <span class="tag sm" :class="toneClass(card.tone)">{{ card.status }}</span>
          </div>
          <h3>{{ card.title }}</h3>
          <p>{{ card.summary }}</p>
          <div v-if="card.detail" class="evidence-question__detail mono">{{ card.detail }}</div>
          <RouterLink v-if="card.evidence" class="small evidence-link" :to="routeFor(card.evidence)">{{ card.evidence.label || 'Open supporting evidence' }}</RouterLink>
          <span v-else class="tiny muted">No supporting artifact was recorded.</span>
        </article>
      </div>

      <details class="evidence-config" aria-labelledby="effective-config-title">
        <summary id="effective-config-title">Engine settings</summary>
        <div class="evidence-config__head">
          <div>
            <h3>Requested and recorded settings</h3>
          </div>
          <span class="tag sm" :class="toneClass(configTone)">{{ valueLabel(evidence?.config?.status, 'Missing') }}</span>
        </div>
        <p class="small muted">Effective settings show what the engine recorded. They do not prove that a requested mechanism operated.</p>
        <div v-if="evidence?.config?.differences?.length" class="config-diff-list">
          <div v-for="difference in evidence.config.differences.slice(0, 8)" :key="difference.path" class="config-diff-row">
            <span class="mono small">{{ difference.path }}</span>
            <span class="tiny muted">{{ displayValue(difference.requested) }} → {{ displayValue(difference.effective) }}</span>
          </div>
        </div>
        <div v-else-if="evidence?.config?.status === 'available'" class="small muted">Requested and effective settings match for the recorded fields.</div>
        <div v-else class="small muted">The run did not include both requested and effective configuration sidecars.</div>
        <div class="row wrap evidence-config__links">
          <RouterLink v-if="evidence?.config?.files?.requested" class="small" :to="routeFor(evidence.config.files.requested)">Open requested config</RouterLink>
          <RouterLink v-if="evidence?.config?.files?.effective" class="small" :to="routeFor(evidence.config.files.effective)">Open effective config</RouterLink>
          <RouterLink v-if="evidence?.config?.files?.provider_wire" class="small" :to="routeFor(evidence.config.files.provider_wire)">Open provider wire metadata</RouterLink>
        </div>
      </details>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { fmtNum, toneClass } from '../api'
import { valueLabel } from '../value-labels.js'

const props = defineProps({ evidence: { type: Object, default: null } })
const evidence = computed(() => props.evidence || {})
const configTone = computed(() => evidence.value.config?.status === 'available' ? 'success' : evidence.value.config?.status === 'partial' ? 'warning' : 'error')

const cards = computed(() => {
  const input = evidence.value.input
  const action = evidence.value.action || {}
  const verification = evidence.value.verification || {}
  const stop = evidence.value.stop || {}
  const usage = evidence.value.usage || {}
  const actionNames = [...new Set((action.items || []).filter((item) => item.name).map((item) => valueLabel(item.name)))].join(', ')
  const taskSuccess = stop.task_success
  return [
    {
      key: 'input', question: 'What the model saw', tone: input ? 'primary' : 'warning', status: input ? 'Recorded' : 'Not recorded',
      title: input ? `${input.model || 'Model unavailable'} received ${input.message_count ?? 0} message${input.message_count === 1 ? '' : 's'}` : 'Model input unavailable',
      summary: input ? `${input.tool_count ?? 0} tool definitions, ${input.attempt_id || 'unidentified attempt'}, and a redacted request projection.` : 'No request frame was available in the configured journals.',
      detail: input?.context_hash ? `context ${input.context_hash}` : '', evidence: input?.evidence,
    },
    {
      key: 'action', question: 'What it did', tone: action.status === 'verified' ? 'success' : action.status === 'recorded' ? 'warning' : 'error', status: action.status === 'verified' ? 'Checked' : action.status === 'recorded' ? 'Recorded' : 'Not recorded',
      title: actionNames ? `Requested ${actionNames}` : 'No requested action recorded',
      summary: action.status === 'verified' ? 'A matching action receipt was recorded.' : action.status === 'recorded' ? 'An action or receipt event was recorded, but execution is not proven.' : 'A requested action and receipt chain were not found.',
      detail: `${action.items?.length || 0} action evidence item${action.items?.length === 1 ? '' : 's'}`, evidence: action.items?.[0]?.evidence,
    },
    {
      key: 'verification', question: 'How it was checked', tone: verification.status === 'verified' ? 'success' : 'warning', status: verification.status === 'verified' ? 'Checked' : verification.status === 'recorded' ? 'Recorded' : 'Not recorded',
      title: verification.items?.length ? `${verification.items.length} check${verification.items.length === 1 ? '' : 's'} recorded` : 'No checks recorded',
      summary: verification.items?.length ? 'Open the linked check to see what it established.' : 'This run has no linked check or graded proof.',
      detail: '', evidence: verification.items?.[0]?.evidence,
    },
    {
      key: 'stop', question: 'Why it stopped', tone: taskSuccess === true ? 'success' : taskSuccess === false ? 'error' : 'warning', status: taskSuccess === true ? 'Checked success' : taskSuccess === false ? 'Task failed' : 'Outcome not recorded',
      title: valueLabel(stop.disposition, 'Stop disposition unavailable'),
      summary: stop.authority === 'engine' ? valueLabel(stop.reason, 'The engine recorded why it stopped.') : 'Only process completion is recorded; task success was not graded.',
      detail: `Recorded by: ${valueLabel(stop.authority)}`, evidence: stop.evidence,
    },
    {
      key: 'cost', question: 'What did it cost?', tone: usage.input_tokens != null || usage.output_tokens != null ? 'info' : 'warning', status: usage.cost_usd != null ? 'cost recorded' : 'usage only',
      title: `${numberOrUnknown(usage.input_tokens)} in / ${numberOrUnknown(usage.output_tokens)} out tokens`,
      summary: usage.cost_usd != null ? `${usage.cost_usd} recorded cost${usage.cost_basis ? ` with ${valueLabel(usage.cost_basis)} basis` : ''}.` : 'No dollar cost was recorded, so Frame Lab does not estimate one.',
      detail: `${numberOrUnknown(usage.provider_time_s)} provider seconds · ${numberOrUnknown(usage.wall_time_s)} wall seconds · ${usage.retries ?? 'not recorded'} retries`, evidence: null,
    },
  ]
})

function numberOrUnknown(value) { return value == null ? 'not recorded' : fmtNum(value) }
function displayValue(value) {
  if (value === undefined) return 'missing'
  if (value === null) return 'null'
  if (typeof value === 'object') {
    try { return JSON.stringify(value) } catch { return '[unrenderable]' }
  }
  return String(value)
}
function routeFor(ref) {
  if (!ref) return { name: 'run' }
  return { name: ref.route, query: ref.query, params: ref.params }
}
</script>
