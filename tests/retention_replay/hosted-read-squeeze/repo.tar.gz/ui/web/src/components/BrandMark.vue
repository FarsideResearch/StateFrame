<template>
  <span class="fl-brand-lockup-wrap">
    <!-- Geometry matches the official Farside favicon and site BrandMark. -->
    <svg class="fl-brand-mark" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
      <path class="fl-brand-mark__letter" d="M12 4H52V13A3 3 0 0 1 49 16H28A4 4 0 0 0 24 20V24H40V30A6 6 0 0 1 34 36H24V60H12Z" />
      <circle class="fl-brand-mark__dot" cx="48" cy="52" r="8" />
    </svg>
    <span class="fl-brand-rule" aria-hidden="true" />
    <span class="fl-brand-lockup">
      <span class="fl-brand-name">Frame Lab</span>
      <span class="fl-brand-org">Farside Research</span>
    </span>
  </span>
</template>
