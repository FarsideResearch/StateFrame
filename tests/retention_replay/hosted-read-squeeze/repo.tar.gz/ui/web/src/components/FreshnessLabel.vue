<template>
  <span class="tag sm dot" :class="tone" :title="freshness?.reason || 'Freshness is unavailable.'">
    {{ label }}
  </span>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  freshness: { type: Object, default: () => ({}) },
})
const label = computed(() => {
  const status = props.freshness?.status
  if (status === 'FRESH') return 'fresh'
  if (status === 'STALE') return 'stale'
  return 'Time not recorded'
})
const tone = computed(() => {
  const status = props.freshness?.status
  if (status === 'FRESH') return 'tone-success'
  if (status === 'STALE') return 'tone-warning'
  return 'outline'
})
</script>
