<template>
  <div class="stack">
    <div class="row wrap">
      <span class="tag tone-success">+{{ stats.add }} lines</span>
      <span class="tag tone-error">-{{ stats.del }} lines</span>
      <span class="tag">{{ stats.same }} unchanged</span>
      <span class="tiny muted">Large changed regions use bounded block replacement.</span>
      <span v-if="renderLimited" class="tiny muted">Display is capped at 2,000 lines for responsiveness.</span>
      <v-switch v-model="onlyChanges" label="Changes only" class="ml-2 flex-grow-0" />
    </div>
    <div class="code">
      <pre><template v-for="(l, i) in shown" :key="i"><div v-if="l.t === 'gap'" class="muted">... {{ l.n }} unchanged lines ...</div><div v-else :class="l.t === '+' ? 'diff-add' : l.t === '-' ? 'diff-del' : ''">{{ l.t }} {{ l.s }}</div></template></pre>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'

const props = defineProps({ before: { type: String, default: '' }, after: { type: String, default: '' } })
const onlyChanges = ref(true)
const MAX_DIFF_INPUT_CHARS = 2_000_000
const MAX_DIFF_INPUT_LINES = 20_000
const MAX_DIFF_RENDER_LINES = 2_000

function boundedLines(text) {
  const source = String(text || '')
  const clippedSource = source.slice(0, MAX_DIFF_INPUT_CHARS)
  const lines = clippedSource.split('\n', MAX_DIFF_INPUT_LINES + 1)
  const clipped = source.length > MAX_DIFF_INPUT_CHARS || lines.length > MAX_DIFF_INPUT_LINES
  return { lines: clipped ? lines.slice(0, MAX_DIFF_INPUT_LINES).concat('[Frame Lab diff input limit reached]') : lines, clipped }
}

// Compare line strings via LCS after trimming the common prefix/suffix.
// Bounded: if the middle is huge, fall back to a block replacement.
function diffLines(a, b) {
  const boundedA = boundedLines(a), boundedB = boundedLines(b)
  const A = boundedA.lines, B = boundedB.lines
  let pre = 0
  while (pre < A.length && pre < B.length && A[pre] === B[pre]) pre++
  let suf = 0
  while (suf < A.length - pre && suf < B.length - pre && A[A.length - 1 - suf] === B[B.length - 1 - suf]) suf++
  const a2 = A.slice(pre, A.length - suf), b2 = B.slice(pre, B.length - suf)
  const out = A.slice(0, pre).map((s) => ({ t: ' ', s }))
  if (a2.length * b2.length > 4_000_000) {
    a2.forEach((s) => out.push({ t: '-', s }))
    b2.forEach((s) => out.push({ t: '+', s }))
  } else {
    const n = a2.length, m = b2.length
    const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1))
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i][j] = a2[i] === b2[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1])
    let i = 0, j = 0
    while (i < n && j < m) {
      if (a2[i] === b2[j]) { out.push({ t: ' ', s: a2[i] }); i++; j++ } else if (dp[i + 1][j] >= dp[i][j + 1]) { out.push({ t: '-', s: a2[i++] }) } else { out.push({ t: '+', s: b2[j++] }) }
    }
    while (i < n) out.push({ t: '-', s: a2[i++] })
    while (j < m) out.push({ t: '+', s: b2[j++] })
  }
  A.slice(A.length - suf).forEach((s) => out.push({ t: ' ', s }))
  return { lines: out, clipped: boundedA.clipped || boundedB.clipped }
}

const diff = computed(() => diffLines(props.before, props.after))
const lines = computed(() => diff.value.lines)
const stats = computed(() => ({
  add: lines.value.filter((l) => l.t === '+').length,
  del: lines.value.filter((l) => l.t === '-').length,
  same: lines.value.filter((l) => l.t === ' ').length,
}))
function changedWindow(source) {
  const keep = new Uint8Array(source.length), ctx = 2
  source.forEach((line, index) => {
    if (line.t !== ' ') for (let i = Math.max(0, index - ctx); i <= Math.min(source.length - 1, index + ctx); i += 1) keep[i] = 1
  })
  const out = []
  let gap = 0
  source.forEach((line, index) => {
    if (keep[index]) {
      if (gap) { out.push({ t: 'gap', n: gap }); gap = 0 }
      out.push(line)
    } else gap += 1
  })
  if (gap) out.push({ t: 'gap', n: gap })
  return out
}

const changedLines = computed(() => changedWindow(lines.value))
const shown = computed(() => (onlyChanges.value ? changedLines.value : lines.value).slice(0, MAX_DIFF_RENDER_LINES))
const renderLimited = computed(() => diff.value.clipped || (onlyChanges.value ? changedLines.value : lines.value).length > MAX_DIFF_RENDER_LINES)
</script>
