<template>
  <div class="settings-summary">
    <dl class="key-values">
      <template v-for="field in fields" :key="field.key">
        <dt>{{ field.label }}</dt><dd :title="display(field.key)">{{ display(field.key) }}</dd>
      </template>
    </dl>
    <details class="settings-technical">
      <summary>Engine settings</summary>
      <dl class="key-values">
        <template v-for="field in engineFields" :key="field.key">
          <dt>{{ field.label }}</dt><dd :title="display(field.key)">{{ display(field.key) }}</dd>
        </template>
      </dl>
    </details>
    <details class="settings-technical">
      <summary>Raw run data</summary>
      <JsonTree :value="meta" :open-depth="2" />
    </details>
  </div>
</template>

<script setup>
import JsonTree from './JsonTree.vue'
import { valueLabel } from '../value-labels.js'

const props = defineProps({ meta: { type: Object, required: true } })
const fields = [
  { key: 'id', label: 'Run' }, { key: 'task', label: 'Task' }, { key: 'status', label: 'Status' },
  { key: 'result', label: 'Recorded result' }, { key: 'run_verdict', label: 'Grade' },
  { key: 'behaviour', label: 'Behavior check' }, { key: 'run_verdict_source', label: 'Run grade source' },
  { key: 'journal_available', label: 'Journal available' }, { key: 'journal_count', label: 'Journals' },
  { key: 'task_grade.verdict', label: 'Task grade' }, { key: 'task_grade.source', label: 'Task grade source' },
  { key: 'steps', label: 'Steps' }, { key: 'edits', label: 'Edits' }, { key: 'tests', label: 'Tests' },
  { key: 'requests', label: 'Model requests' }, { key: 'prompt_tokens', label: 'Prompt tokens' },
]
const engineFields = [
  { key: 'release', label: 'Release' }, { key: 'kernel_mode', label: 'Kernel mode' },
  { key: 'projector', label: 'Projector' }, { key: 'seed', label: 'Seed' },
  { key: 'engine_state', label: 'Engine state' }, { key: 'process_state', label: 'Process state' },
]
function display(key) {
  const value = key.split('.').reduce((part, segment) => part?.[segment], props.meta)
  if (key === 'journal_available') return value ? 'Yes' : 'No'
  if (['status', 'result', 'behaviour', 'run_verdict', 'task_grade.verdict', 'kernel_mode', 'projector', 'engine_state', 'process_state'].includes(key)) return valueLabel(value, key.includes('verdict') ? 'Not graded' : 'not recorded')
  return value == null || value === '' ? 'not recorded' : String(value)
}
</script>
