<template>
  <div class="json-wrap">
    <div v-if="copyable" class="code-bar"><CopyButton :value="asText" text="Copy JSON" /><span v-if="copyCapped" class="tiny muted">Copy is capped at 2 MB.</span></div>
    <div class="json-tree" role="tree" aria-label="JSON data">
      <JsonNode :value="value" :name="rootName" :depth="0" :open-depth="openDepth" :highlight="highlight" />
    </div>
  </div>
</template>

<script setup>
import JsonNode from './JsonNode.vue'
import CopyButton from './CopyButton.vue'
import { ref } from 'vue'

const props = defineProps({
  value: { type: null, required: true },
  rootName: { type: String, default: '' },
  openDepth: { type: Number, default: 1 },
  highlight: { type: String, default: '' },
  copyable: { type: Boolean, default: true },
})
const copyCapped = ref(false)
const MAX_JSON_COPY_CHARS = 2_000_000
function asText() {
  copyCapped.value = false
  try {
    const text = JSON.stringify(props.value, null, 2)
    if (text.length <= MAX_JSON_COPY_CHARS) return text
    copyCapped.value = true
    return `${text.slice(0, MAX_JSON_COPY_CHARS)}\n\n[Frame Lab copy limit reached]`
  } catch { return String(props.value) }
}
</script>
