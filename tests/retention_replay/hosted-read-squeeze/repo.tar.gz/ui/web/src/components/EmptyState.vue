<template>
  <div class="empty">
    <v-icon :icon="icon" size="28" />
    <div class="title">{{ title }}</div>
    <div v-if="hint" class="hint">{{ hint }}</div>
    <slot />
  </div>
</template>

<script setup>
import { mdiTrayRemove } from '@mdi/js'
defineProps({ title: { type: String, required: true }, hint: { type: String, default: '' }, icon: { type: String, default: mdiTrayRemove } })
</script>
