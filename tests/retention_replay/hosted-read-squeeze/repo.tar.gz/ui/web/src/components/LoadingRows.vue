<template>
  <div class="skeleton-rows" role="status" aria-busy="true" aria-live="polite" aria-label="Loading">
    <span v-for="i in rows" :key="i" :style="{ width: `${92 - ((i * 17) % 40)}%` }" />
  </div>
</template>

<script setup>
defineProps({ rows: { type: Number, default: 6 } })
</script>
