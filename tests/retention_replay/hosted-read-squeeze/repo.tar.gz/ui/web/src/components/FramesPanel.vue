<template>
  <div class="split cols-list grow">
    <section class="panel">
      <div class="panel-sub">
        <div class="row wrap panel-sub">
          <v-text-field v-model="searchInput" :prepend-inner-icon="mdiMagnify" label="Search frame evidence" placeholder="Enter to search request, response, or audit" clearable @keyup.enter="searchAll" @click:clear="clearSearch" />
          <v-select v-model="searchScope" :items="scopeItems" label="Scope" density="compact" style="max-width: 150px" @update:model-value="searchApplied && searchAll()" />
          <v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="refresh">Refresh</v-btn>
        </div>
      </div>
      <v-progress-linear v-if="loading || searching" indeterminate class="loadbar" />
      <v-alert v-if="error" type="error" class="ma-2">{{ error }} <v-btn size="small" variant="text" @click="refresh">Retry</v-btn></v-alert>
      <div class="table-x table-x--fill">
        <div class="table-x-inner frames-table-inner" role="grid" :aria-rowcount="shownFrames.length + 1" aria-label="Model frames">
          <div class="grid-row grid-head" role="row" :style="grid">
            <span role="columnheader">#</span><span role="columnheader">Step</span><span role="columnheader" class="r">Chars</span><span role="columnheader" class="r">Prompt</span><span role="columnheader">Action</span>
          </div>
          <div class="vfill">
            <v-virtual-scroll v-if="shownFrames.length" class="vfill-abs" :items="shownFrames" :item-height="40" height="100%">
              <template #default="{ item: f }">
                <div class="grid-row focusable-row" role="button" tabindex="0" :aria-selected="f.attempt_id === rid" :class="{ active: f.attempt_id === rid }" :style="grid" @click="select(f.attempt_id)" @keydown.enter.prevent="select(f.attempt_id)" @keydown.space.prevent="select(f.attempt_id)">
                  <span class="mono">{{ f.n }}<span v-if="hits[f.attempt_id]" class="hl tiny" style="margin-left: 4px">{{ hits[f.attempt_id] }}</span></span>
                  <span class="mono">{{ f.step ?? '' }}</span>
                  <span class="num tiny" :title="f.delta_chars != null ? `delta ${f.delta_chars}` : ''">{{ fmtNum(f.chars) }}</span>
                  <span class="num tiny">{{ fmtNum(f.tokens?.prompt) }}</span>
                  <span class="ellip tiny" :title="f.action">{{ f.action || f.finish || '' }}</span>
                </div>
              </template>
            </v-virtual-scroll>
            <LoadingRows v-else-if="loading" />
            <EmptyState v-else-if="searchApplied" title="No frames match" :hint="`Nothing in this journal contains '${searchApplied}'.`" />
            <EmptyState v-else title="No model requests" hint="This journal has no request_submitted events." />
          </div>
        </div>
      </div>
      <div class="panel-foot">
        <template v-if="searchApplied">{{ shownFrames.length }} of {{ frames.length }} requests match in {{ searchScope }} scope</template>
        <template v-else>{{ frames.length }} model requests</template>
      </div>
    </section>
    <div class="stack" style="min-height: 0">
      <section v-if="invalidRid" class="panel grow"><EmptyState title="Invalid frame selection" hint="The rid query must identify one frame attempt in this journal." /></section>
      <section v-else-if="!rid" class="panel grow"><EmptyState :icon="mdiCursorDefaultClickOutline" title="Pick a request" hint="Select a request to inspect the exact frame sent to the model." /></section>
      <FrameInspector v-else :id="id" :jref="jref" :rid="rid" :search="searchApplied" :refresh-token="refreshToken" @navigate="select" />
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiCursorDefaultClickOutline, mdiMagnify, mdiRefresh } from '@mdi/js'
import { api, fmtNum, invalidateApiCache } from '../api'
import FrameInspector from './FrameInspector.vue'
import EmptyState from './EmptyState.vue'
import LoadingRows from './LoadingRows.vue'
import { createRequestState } from '../request-state.js'

const props = defineProps({ id: { type: String, required: true }, jref: { type: String, required: true } })
const route = useRoute()
const router = useRouter()
const frames = ref([])
const error = ref('')
const loading = ref(false)
const searching = ref(false)
const searchInput = ref(typeof route.query.fq === 'string' ? route.query.fq : '')
const searchApplied = ref(typeof route.query.fq === 'string' ? route.query.fq : '')
const searchScope = ref(['all', 'request', 'response', 'audit'].includes(route.query.fscope) ? route.query.fscope : 'all')
const scopeItems = [{ title: 'All evidence', value: 'all' }, { title: 'Request', value: 'request' }, { title: 'Response', value: 'response' }, { title: 'Audit', value: 'audit' }]
const refreshToken = ref(0)
const hits = ref({})
const grid = { gridTemplateColumns: '44px 40px 64px 60px minmax(0,1fr)' }
const rid = computed(() => typeof route.query.rid === 'string' ? route.query.rid : '')
const invalidRid = computed(() => route.query.rid != null && typeof route.query.rid !== 'string')
const listRequest = createRequestState()
const searchRequest = createRequestState()

async function loadFrames(force = false) {
  const request = listRequest.begin()
  loading.value = true
  error.value = ''
  frames.value = []
  searchRequest.cancel()
  hits.value = {}
  if (!searchInput.value.trim()) searchApplied.value = ''
  try {
    if (force) invalidateApiCache('frames')
    const result = await api('frames', { id: props.id, j: props.jref }, { cached: true, force, signal: request.signal })
    if (!listRequest.isCurrent(request.id)) return
    frames.value = result.frames
    if (!rid.value && frames.value.length) select(frames.value[0].attempt_id)
    if (searchInput.value.trim()) searchAll()
  } catch (e) { if (listRequest.isCurrent(request.id)) { error.value = e.message; frames.value = [] } } finally { if (listRequest.isCurrent(request.id)) loading.value = false }
}
watch(() => [props.id, props.jref], loadFrames, { immediate: true })
watch(() => route.query.fq, (value) => {
  const next = typeof value === 'string' ? value : ''
  if (next !== searchApplied.value) { searchApplied.value = next; searchInput.value = next }
})
watch(() => route.query.fscope, (value) => { if (typeof value === 'string' && scopeItems.some((item) => item.value === value)) searchScope.value = value })

const shownFrames = computed(() => (searchApplied.value ? frames.value.filter((f) => hits.value[f.attempt_id]) : frames.value))
async function searchAll() {
  const qv = (searchInput.value || '').trim()
  if (!qv) return clearSearch()
  const request = searchRequest.begin()
  searching.value = true
  error.value = ''
  hits.value = {}
  searchApplied.value = ''
  try {
    const r = await api('frames/search', { id: props.id, j: props.jref, q: qv, scope: searchScope.value }, { signal: request.signal })
    if (!searchRequest.isCurrent(request.id)) return
    hits.value = Object.fromEntries(r.results.map((x) => [x.attempt_id, x.hits]))
    searchApplied.value = qv
    router.replace({ query: { ...route.query, fq: qv, fscope: searchScope.value, rid: undefined } })
  } catch (e) { if (searchRequest.isCurrent(request.id)) error.value = e.message } finally { if (searchRequest.isCurrent(request.id)) searching.value = false }
}
function clearSearch() {
  searchRequest.cancel()
  hits.value = {}; searchApplied.value = ''; searchInput.value = ''
  router.replace({ query: { ...route.query, fq: undefined, fscope: undefined, ftext: undefined } })
}
function refresh() { refreshToken.value += 1; invalidateApiCache('frame'); loadFrames(true) }
function select(r) { router.push({ query: { ...route.query, rid: r } }) }
onBeforeUnmount(() => { listRequest.cancel(); searchRequest.cancel() })
</script>
