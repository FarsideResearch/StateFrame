<template>
  <details class="settings-technical">
    <summary>{{ label }}</summary>
    <JsonTree :value="value" :open-depth="openDepth" :highlight="highlight" />
  </details>
</template>

<script setup>
import JsonTree from './JsonTree.vue'
defineProps({
  value: { type: null, required: true },
  label: { type: String, default: 'Raw data' },
  openDepth: { type: Number, default: 1 },
  highlight: { type: String, default: '' },
})
</script>
