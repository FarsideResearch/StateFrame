<template>
  <div class="split cols-list-wide grow">
    <div class="stack" style="min-height: 0">
      <section class="panel" :class="hasTgz ? '' : 'grow'" :style="hasTgz ? 'flex: 0 1 auto; max-height: 40%' : ''">
        <div class="panel-head">
          <div>
            <h2 class="kicker">Run directory</h2>
            <div v-if="dirPath" class="tiny mono muted">{{ dirPath }}/</div>
          </div>
          <span class="end tiny muted">{{ dirFiles.length }} entries</span>
        </div>
        <div class="panel-body flush">
          <button v-if="dirPath" type="button" class="list-row" @click="goUp">
            <span class="main">..</span><span class="aside">parent</span>
          </button>
          <button
            v-for="fi in dirFiles" :key="fi.name" type="button" class="list-row" :class="{ active: sel?.kind === 'file' && sel.name === fileName(fi.name) }" :aria-pressed="sel?.kind === 'file' && sel.name === fileName(fi.name)"
            @click="openFile(fi.name)"
          >
            <span class="main mono small ellip" :title="fi.name">{{ fi.name }}</span><span class="aside">{{ fi.name.endsWith('/') ? 'directory' : fmtBytes(fi.size) }}</span>
          </button>
          <LoadingRows v-if="dirLoading" :rows="4" />
          <EmptyState v-else-if="!dirFiles.length" title="No files" hint="Files recorded with this run appear here; open another run or start framelab ui --data PATH/TO/RUNS." />
        </div>
      </section>
      <section v-if="hasTgz" class="panel grow">
        <div class="panel-head"><h2 class="kicker">worker.tgz</h2><span class="tiny muted">streamed, never extracted</span></div>
        <div class="panel-sub">
           <v-text-field v-model="memberQ" :prepend-inner-icon="mdiMagnify" label="Archive member filter" placeholder="Enter (e.g. candidates/)" @keyup.enter="loadMembers(false)" />
        </div>
        <v-progress-linear v-if="mLoading" indeterminate class="loadbar" />
        <div class="vfill">
          <v-virtual-scroll v-if="members.length" class="vfill-abs" :items="members" :item-height="40" height="100%">
            <template #default="{ item: m }">
              <div
                class="grid-row archive-member-row focusable-row" :class="{ active: sel?.kind === 'member' && sel.name === m.name, disabled: !m.file }"
                role="button" :tabindex="m.file ? 0 : -1" :aria-disabled="!m.file" :aria-pressed="sel?.kind === 'member' && sel.name === m.name" @click="m.file && openMember(m.name)" @keydown.enter.prevent="m.file && openMember(m.name)" @keydown.space.prevent="m.file && openMember(m.name)"
              >
                <span class="mono tiny ellip" :title="m.name">{{ m.name }}</span><span class="tiny muted num">{{ m.file ? fmtBytes(m.size) : '' }}</span>
              </div>
            </template>
          </v-virtual-scroll>
          <LoadingRows v-else-if="mLoading" />
          <EmptyState v-else title="No members match" :hint="memberQ ? `Nothing in worker.tgz matches '${memberQ}'.` : 'The archive is empty.'" />
        </div>
        <div class="panel-foot">
          {{ fmtNum(mTotal) }} members match<span v-if="mHasMore">, {{ fmtNum(members.length) }} listed</span>
          <v-btn v-if="mHasMore" size="small" variant="text" :loading="mLoading" @click="loadMembers(true)">Load more</v-btn>
        </div>
      </section>
    </div>
    <section class="panel">
      <div class="panel-head">
        <h2 class="title ellip mono">{{ sel ? sel.name : 'Preview' }}</h2>
        <span v-if="sel" class="tag sm outline">{{ sel.kind === 'member' ? 'tgz member' : 'file' }}</span>
      </div>
      <v-progress-linear v-if="loading" indeterminate class="loadbar" />
      <div class="panel-body">
        <v-alert v-if="error" type="error" class="mb-3">{{ error }} <v-btn size="small" variant="text" @click="retry">Retry</v-btn></v-alert>
         <FilePayload v-if="payload" :payload="payload" :busy="loading" @query="onFileQuery" />
        <LoadingRows v-else-if="loading" :rows="10" />
        <EmptyState v-else-if="!error" :icon="mdiFileSearchOutline" title="Pick a file" hint="Choose a run file or a worker.tgz member to preview it." />
      </div>
    </section>
  </div>
</template>

<script setup>
 import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
 import { useRoute, useRouter } from 'vue-router'
import { mdiFileSearchOutline, mdiMagnify } from '@mdi/js'
import { api, fmtBytes, fmtNum } from '../api'
import FilePayload from './FilePayload.vue'
import EmptyState from './EmptyState.vue'
 import LoadingRows from './LoadingRows.vue'
 import { createRequestState } from '../request-state.js'

 const props = defineProps({ id: { type: String, required: true }, files: { type: Array, default: () => [] }, hasTgz: { type: Boolean, default: false } })
 const route = useRoute()
 const router = useRouter()
const payload = ref(null)
const sel = ref(null)
const error = ref('')
const loading = ref(false)
const members = ref([])
const mTotal = ref(0)
const memberQ = ref(typeof route.query.mq === 'string' ? route.query.mq : 'candidates/')
 const mLoading = ref(false)
 const mHasMore = ref(false)
 const mOffset = ref(0)
const dirPath = ref('')
const currentFiles = ref([])
const dirLoading = ref(false)
const retryKind = ref('members')
const dirFiles = computed(() => currentFiles.value.filter((x) => x.name !== 'worker.tgz'))

 const contentRequest = createRequestState()
 const directoryRequest = createRequestState()
 const memberRequest = createRequestState()
 async function show(fn, s) {
   const request = contentRequest.begin()
   loading.value = true
   error.value = ''
   payload.value = null
   sel.value = s
   retryKind.value = 'content'
   try {
     const p = await fn()
     if (contentRequest.isCurrent(request.id)) payload.value = p
   } catch (e) { if (contentRequest.isCurrent(request.id)) { error.value = e.message; payload.value = null } } finally { if (contentRequest.isCurrent(request.id)) loading.value = false }
 }
function fileName(name) { return `${dirPath.value}${name}` }
 function openFile(name) {
   if (name.endsWith('/')) {
     loadDirectory(`${dirPath.value}${name}`)
     return
   }
   const relative = fileName(name)
   const s = { kind: 'file', name: relative }
   router.push({ query: { ...route.query, file: relative, member: undefined, fp: undefined, frecords: undefined, foffset: undefined, fchunk: undefined } })
   show(() => api('run/file', { id: props.id, name: relative }), s)
 }
 function openMember(name) {
   const s = { kind: 'member', name }
   router.push({ query: { ...route.query, member: name, file: undefined, fp: undefined, frecords: undefined, foffset: undefined, fchunk: undefined } })
   show(() => api('run/tgz/member', { id: props.id, member: name }), s)
 }
 function fileParams(patch = {}) {
   const values = { pointer: route.query.fp, records: route.query.frecords, offset: route.query.foffset, chunk_offset: route.query.fchunk, ...patch }
   return Object.fromEntries(Object.entries(values).filter(([, value]) => value !== undefined && value !== null && value !== ''))
 }
 function onFileQuery(patch) {
   const next = { ...route.query, fp: Object.prototype.hasOwnProperty.call(patch, 'pointer') ? patch.pointer : route.query.fp,
     frecords: Object.prototype.hasOwnProperty.call(patch, 'records') ? patch.records : route.query.frecords,
     foffset: Object.prototype.hasOwnProperty.call(patch, 'offset') ? patch.offset : route.query.foffset,
     fchunk: Object.prototype.hasOwnProperty.call(patch, 'chunk_offset') ? patch.chunk_offset : route.query.fchunk }
   if (Object.prototype.hasOwnProperty.call(patch, 'pointer')) {
     next.frecords = undefined; next.foffset = undefined; next.fchunk = undefined
   }
   if (Object.prototype.hasOwnProperty.call(patch, 'records')) next.fchunk = undefined
   router.push({ query: next })
   if (!sel.value) return
   const request = sel.value.kind === 'file'
     ? () => api('run/file', { id: props.id, name: sel.value.name, ...fileParams(patch) })
     : () => api('run/tgz/member', { id: props.id, member: sel.value.name, ...fileParams(patch) })
   show(request, sel.value)
 }
 async function loadDirectory(path) {
   const request = directoryRequest.begin()
   dirLoading.value = true
   error.value = ''
   payload.value = null
   sel.value = null
   dirPath.value = path
   currentFiles.value = []
   retryKind.value = 'directory'
   router.push({ query: { ...route.query, rpath: path || undefined, file: undefined, member: undefined, fp: undefined, frecords: undefined, foffset: undefined, fchunk: undefined } })
   try {
     const r = await api('run/files', { id: props.id, path })
     if (!directoryRequest.isCurrent(request.id)) return
     dirPath.value = r.path
     currentFiles.value = r.files
   } catch (e) { if (directoryRequest.isCurrent(request.id)) error.value = e.message } finally { if (directoryRequest.isCurrent(request.id)) dirLoading.value = false }
}
function goUp() {
  const parts = dirPath.value.split('/').filter(Boolean)
  parts.pop()
  loadDirectory(parts.length ? `${parts.join('/')}/` : '')
}
async function loadMembers(append = false) {
   if (!props.hasTgz) return
   const request = memberRequest.begin()
   if (!append) { mOffset.value = 0; members.value = []; mTotal.value = 0; mHasMore.value = false }
   mLoading.value = true
   error.value = ''
   retryKind.value = 'members'
   try {
     const r = await api('run/tgz', { id: props.id, q: memberQ.value, offset: append ? mOffset.value : 0, limit: 200 })
     if (!memberRequest.isCurrent(request.id)) return
     members.value = append ? [...members.value, ...r.members] : r.members
     mOffset.value = r.next_offset ?? (append ? mOffset.value : r.members.length)
     mTotal.value = r.total
     mHasMore.value = !!r.has_more
   } catch (e) { if (memberRequest.isCurrent(request.id)) error.value = e.message } finally { if (memberRequest.isCurrent(request.id)) mLoading.value = false }
}
watch(memberQ, (value) => router.replace({ query: { ...route.query, mq: value || undefined } }))
watch(() => route.query.mq, (value) => { if (typeof value === 'string' && value !== memberQ.value) memberQ.value = value })
 function retry() {
   if (retryKind.value === 'directory') loadDirectory(dirPath.value)
   else if (sel.value?.kind === 'file') show(() => api('run/file', { id: props.id, name: sel.value.name, ...fileParams() }), sel.value)
   else if (sel.value?.kind === 'member') show(() => api('run/tgz/member', { id: props.id, member: sel.value.name, ...fileParams() }), sel.value)
   else loadMembers(false)
 }
 onMounted(() => {
   currentFiles.value = props.files
   const initialPath = typeof route.query.rpath === 'string' ? route.query.rpath : ''
   if (initialPath) loadDirectory(initialPath)
   const file = route.query.file
   const member = route.query.member
   if (file) show(() => api('run/file', { id: props.id, name: file, ...fileParams() }), { kind: 'file', name: file })
   else if (member) show(() => api('run/tgz/member', { id: props.id, member, ...fileParams() }), { kind: 'member', name: member })
   loadMembers(false)
 })
// hasTgz arrives with the run metadata, which can land after this panel mounts.
watch(() => [props.id, props.hasTgz, props.files], () => {
   payload.value = null
   sel.value = null
   dirPath.value = ''
   currentFiles.value = props.files
   mOffset.value = 0
   mHasMore.value = false
   loadMembers(false)
 })
 onBeforeUnmount(() => { contentRequest.cancel(); directoryRequest.cancel(); memberRequest.cancel() })
</script>
