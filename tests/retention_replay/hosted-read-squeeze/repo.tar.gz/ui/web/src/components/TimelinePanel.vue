<template>
  <div class="stack grow" style="gap: 10px">
    <div class="toolbar">
      <button
        v-for="c in catList" :key="c.name" type="button" class="tag clickable outline" :class="{ selected: cats.includes(c.name) }"
        :aria-pressed="cats.includes(c.name)" @click="toggleCat(c.name)"
      >
        <span class="cat-dot" :style="{ background: `var(--fl-c-${catTone(c.name)})` }" />{{ c.name }} <span class="muted">{{ c.count }}</span>
      </button>
      <button v-if="cats.length" type="button" class="copy-btn" @click="cats = []">Clear</button>
    </div>
    <div class="toolbar">
      <v-autocomplete v-model="kinds" :items="kindItems" label="Event kinds" multiple chips closable-chips style="max-width: 520px; min-width: 260px" />
      <v-text-field v-model="qInput" :prepend-inner-icon="mdiMagnify" label="Search event text" placeholder="Enter to search request, response, and audit fields" style="max-width: 320px; min-width: 220px" clearable @keyup.enter="submitSearch" @click:clear="submitSearch" />
      <v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="refresh">Refresh</v-btn>
      <span v-if="data" class="count tiny muted">
        {{ fmtNum(rows.length) }} loaded, {{ fmtNum(data.matched) }} / {{ fmtNum(data.total) }} events, prompt {{ fmtNum(data.tokens.prompt) }} tok, completion {{ fmtNum(data.tokens.completion) }} tok<span v-if="data.bad_lines">, {{ data.bad_lines }} unparseable lines</span>
      </span>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="refresh">Retry</v-btn></v-alert>
    <div class="split cols-timeline grow">
      <section class="panel">
        <v-progress-linear v-if="loading" indeterminate class="loadbar" />
        <div class="table-x table-x--fill">
          <div class="table-x-inner timeline-table-inner" role="grid" :aria-rowcount="rows.length + 1" aria-label="Journal events">
            <div class="grid-row grid-head" role="row" :style="grid">
              <span role="columnheader">#</span><span role="columnheader">Step</span><span role="columnheader">Kind</span><span role="columnheader">Detail</span><span role="columnheader" class="r">Tokens</span><span role="columnheader" class="r">Size</span>
            </div>
            <div class="vfill">
              <v-virtual-scroll v-if="rows.length" ref="vs" class="vfill-abs" :items="rows" :item-height="40" height="100%">
                <template #default="{ item: r }">
                  <div class="grid-row focusable-row" role="button" tabindex="0" :aria-selected="r.i === sel" :class="{ active: r.i === sel }" :style="grid" @click="select(r.i)" @keydown.enter.prevent="select(r.i)" @keydown.space.prevent="select(r.i)">
                    <span class="mono muted">{{ r.seq }}</span>
                    <span class="mono">{{ r.step ?? '' }}</span>
                    <span class="mono ellip" :title="r.kind"><span class="cat-dot" :style="{ background: `var(--fl-c-${catTone(r.cat)})` }" />{{ r.kind }}</span>
                    <span class="ellip tiny" :title="r.label">{{ r.label || '' }}</span>
                    <span class="num tiny">{{ tokText(r.tokens) }}</span>
                    <span class="num tiny muted">{{ fmtBytes(r.bytes) }}</span>
                  </div>
                </template>
              </v-virtual-scroll>
              <LoadingRows v-else-if="loading" :rows="10" />
              <EmptyState v-else title="No events" :hint="data && data.total ? 'No events match the current filters.' : 'This journal is empty.'" />
            </div>
          </div>
        </div>
        <div v-if="data" class="panel-foot row wrap">
          <span class="muted small">{{ rows.length }} of {{ data.matched }} matching events loaded.</span>
          <v-btn v-if="data.has_more" size="small" variant="text" :loading="loadingMore" @click="loadMore">Load more events</v-btn>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head">
          <template v-if="sel != null">
            <span class="mono strong ellip">#{{ sel }} {{ event?.kind }}</span>
            <div class="end">
              <v-btn v-if="event?.request_id" :prepend-icon="mdiFileCompare" @click="openFrame(eventAttempt || event.request_id)">Open frame</v-btn>
              <v-btn :icon="mdiChevronUp" size="x-small" aria-label="Previous event" @click="step(-1)" />
              <v-btn :icon="mdiChevronDown" size="x-small" aria-label="Next event" @click="step(1)" />
            </div>
          </template>
          <h2 v-else class="title">Event</h2>
        </div>
        <v-progress-linear v-if="eventLoading" indeterminate class="loadbar" />
        <div class="panel-body">
          <EmptyState v-if="invalidSelection" title="Invalid event selection" hint="This event ID is not valid for the current journal. Choose an event from the list or remove the i parameter." />
          <EmptyState v-else-if="sel == null" :icon="mdiCursorDefaultClickOutline" title="Pick an event" hint="Select an event on the left to inspect it. Use the arrows to step through." />
          <div v-else-if="event">
            <dl class="key-values">
              <dt>Event</dt><dd>{{ event.kind || 'not recorded' }}</dd>
              <dt>Step</dt><dd>{{ event.step ?? 'not recorded' }}</dd>
              <dt>Request ID</dt><dd class="mono">{{ event.request_id || 'not recorded' }}</dd>
            </dl>
            <RawDisclosure :value="event" label="Raw event" :open-depth="2" :highlight="q" />
          </div>
          <LoadingRows v-else-if="eventLoading" />
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiMagnify, mdiChevronUp, mdiChevronDown, mdiFileCompare, mdiCursorDefaultClickOutline } from '@mdi/js'
import { api, fmtBytes, fmtNum, invalidateApiCache } from '../api'
import RawDisclosure from './RawDisclosure.vue'
import EmptyState from './EmptyState.vue'
import LoadingRows from './LoadingRows.vue'
import { createRequestState } from '../request-state.js'

const props = defineProps({ id: { type: String, required: true }, jref: { type: String, required: true } })
const route = useRoute()
const router = useRouter()
const data = ref(null)
const error = ref('')
const loading = ref(false)
const cats = ref(typeof route.query.cats === 'string' ? route.query.cats.split(',').filter(Boolean) : [])
const kinds = ref(typeof route.query.kinds === 'string' ? route.query.kinds.split(',').filter(Boolean) : [])
const q = ref(typeof route.query.tq === 'string' ? route.query.tq : '')
const qInput = ref(q.value)
const event = ref(null)
const eventAttempt = ref(null)
const eventRefreshToken = ref(0)
const eventLoading = ref(false)
const loadingMore = ref(false)
const vs = ref(null)
const grid = { gridTemplateColumns: '56px 44px minmax(150px,1.3fr) minmax(0,2fr) 110px 64px' }

const rawSel = computed(() => route.query.i)
const sel = computed(() => (rawSel.value != null && rawSel.value !== '' && !Array.isArray(rawSel.value) && Number.isInteger(Number(rawSel.value)) ? Number(rawSel.value) : null))
const invalidSelection = computed(() => rawSel.value != null && (Array.isArray(rawSel.value) || !Number.isInteger(Number(rawSel.value)) || Number(rawSel.value) < 0))

const dataRequest = createRequestState()
const eventRequest = createRequestState()
async function load(force = false) {
  const mine = dataRequest.begin()
  loading.value = true
  loadingMore.value = false
  error.value = ''
  data.value = null
  try {
    if (force) invalidateApiCache('journal')
    const d = await api('journal', {
      id: props.id,
      j: props.jref,
      q: q.value,
      cats: cats.value.join(','),
      kinds: kinds.value.join(','),
      offset: 0,
      limit: 500,
    }, { cached: true, force, signal: mine.signal })
    if (dataRequest.isCurrent(mine.id)) data.value = d
  } catch (e) { if (dataRequest.isCurrent(mine.id)) { error.value = e.message; data.value = null } } finally { if (dataRequest.isCurrent(mine.id)) loading.value = false }
}
async function loadMore() {
  if (!data.value?.has_more || loadingMore.value) return
  const mine = dataRequest.begin()
  loadingMore.value = true
  error.value = ''
  try {
    const d = await api('journal', {
      id: props.id,
      j: props.jref,
      q: q.value,
      cats: cats.value.join(','),
      kinds: kinds.value.join(','),
      offset: data.value.next_offset,
      limit: data.value.limit || 500,
    }, { cached: true, signal: mine.signal })
    if (dataRequest.isCurrent(mine.id)) data.value = { ...d, rows: [...(data.value?.rows || []), ...d.rows], offset: 0 }
  } catch (e) { if (dataRequest.isCurrent(mine.id)) error.value = e.message } finally { if (dataRequest.isCurrent(mine.id)) loadingMore.value = false }
}
watch(() => [props.id, props.jref, q.value, cats.value.join(','), kinds.value.join(',')], load, { immediate: true })
// A different journal has a different category/kind vocabulary; stale filters would hide everything.
watch(() => props.jref, () => { cats.value = []; kinds.value = []; event.value = null; router.replace({ query: { ...route.query, cats: undefined, kinds: undefined, i: undefined } }) })
watch(() => route.query.tq, (value) => { const next = typeof value === 'string' ? value : ''; if (next !== q.value) { q.value = next; qInput.value = next } })
watch(() => route.query.cats, (value) => { const next = typeof value === 'string' ? value.split(',').filter(Boolean) : []; if (JSON.stringify(next) !== JSON.stringify(cats.value)) cats.value = next })
watch(() => route.query.kinds, (value) => { const next = typeof value === 'string' ? value.split(',').filter(Boolean) : []; if (JSON.stringify(next) !== JSON.stringify(kinds.value)) kinds.value = next })
watch(cats, (value) => router.replace({ query: { ...route.query, cats: value.length ? value.join(',') : undefined } }), { deep: true })
watch(kinds, (value) => router.replace({ query: { ...route.query, kinds: value.length ? value.join(',') : undefined } }), { deep: true })
function submitSearch() { q.value = qInput.value.trim(); router.replace({ query: { ...route.query, tq: q.value || undefined, i: undefined } }) }
function refresh() { eventRefreshToken.value += 1; invalidateApiCache('journal/event'); load(true) }

const catList = computed(() => {
  const m = {}
  for (const [name, count] of Object.entries(data.value?.categories || {})) m[name] = count
  return Object.entries(m).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count)
})
const kindItems = computed(() => Object.entries(data.value?.kinds || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => ({ title: `${k} (${n})`, value: k })))
const rows = computed(() => {
  let r = data.value?.rows || []
  if (cats.value.length) r = r.filter((x) => cats.value.includes(x.cat))
  if (kinds.value.length) r = r.filter((x) => kinds.value.includes(x.kind))
  return r
})
function toggleCat(c) { cats.value = cats.value.includes(c) ? cats.value.filter((x) => x !== c) : [...cats.value, c] }

function tokText(t) {
  if (!t) return ''
  if (t.prompt != null) return `${fmtNum(t.prompt)} / ${fmtNum(t.completion)}`
  if (t.prompt_est != null) return `~${fmtNum(t.prompt_est)}`
  if (t.context_est != null) return `~${fmtNum(t.context_est)} ctx`
  return ''
}
// Category -> semantic token suffix (tokens.css --fl-c-*).
const TONES = { request: 'primary', response: 'success', test: 'warning', render: 'info', terminal: 'error', error: 'error', decision: 'primary', receipt: 'success', idealpath: 'warning' }
function catTone(c) { return TONES[c] || 'muted' }

function select(i) { router.push({ query: { ...route.query, i } }) }
function step(d) {
  const list = rows.value
  if (!list.length) return
  const pos = list.findIndex((r) => r.i === sel.value)
  const nxt = list[pos < 0 ? 0 : Math.max(0, Math.min(list.length - 1, pos + d))]
  if (nxt) { select(nxt.i); vs.value?.scrollToIndex(Math.max(0, list.indexOf(nxt) - 5)) }
}
function openFrame(rid) { router.push({ query: { ...route.query, tab: 'frames', rid } }) }

watch(() => [sel.value, props.jref, eventRefreshToken.value], async () => {
  const mine = eventRequest.begin()
  event.value = null
  eventAttempt.value = null
  if (sel.value == null || invalidSelection.value) return
  eventLoading.value = true
  try {
    const r = await api('journal/event', { id: props.id, j: props.jref, i: sel.value }, { cached: true, force: eventRefreshToken.value > 0, signal: mine.signal })
    if (eventRequest.isCurrent(mine.id)) { event.value = r.event; eventAttempt.value = r.attempt_id }
  } catch (e) { if (eventRequest.isCurrent(mine.id)) error.value = e.message } finally { if (eventRequest.isCurrent(mine.id)) eventLoading.value = false }
}, { immediate: true })
onBeforeUnmount(() => { dataRequest.cancel(); eventRequest.cancel() })
</script>
