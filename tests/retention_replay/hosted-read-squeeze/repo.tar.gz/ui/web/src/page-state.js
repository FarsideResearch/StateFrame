export function appendExperimentPage(current, next, offset) {
  if (!current || offset === 0) return next
  const files = [...current.files]
  const seen = new Set(files.map((file) => file.path))
  for (const file of next.files) {
    if (!seen.has(file.path)) { files.push(file); seen.add(file.path) }
  }
  return { ...current, files, files_total: next.files_total, files_capped: next.files_capped,
    files_has_more: next.files_has_more, files_next_offset: next.files_next_offset }
}
