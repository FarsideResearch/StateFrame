// Pure evidence-shape helpers shared by the JSON preview and its unit tests.
// They keep malformed rows visible without making templates guess at a shape.
export function recordValue(record, key) {
  return record && typeof record === 'object' && !Array.isArray(record) ? record[key] : undefined
}

export function cellText(value) {
  if (value === null) return 'null'
  if (value === undefined) return 'unknown'
  if (typeof value === 'object') {
    try { return JSON.stringify(value).slice(0, 200) } catch { return '[unrenderable value]' }
  }
  return String(value)
}

export function metricText(metric) {
  if (metric.rate == null) return 'unknown'
  return `${(metric.rate * 100).toFixed(1)}%`
}

export function jsonValueState(payload) {
  if (payload?.value_type === 'null') return 'null'
  if (payload?.inline) return 'inline'
  if (payload?.chunk) return 'chunked'
  if (payload?.items) return 'paged-array'
  if (payload?.top) return 'lazy-object'
  return 'unavailable'
}

export function parentPointer(pointer) {
  if (!pointer) return null
  const cut = pointer.lastIndexOf('/')
  return cut <= 0 ? '' : pointer.slice(0, cut)
}
