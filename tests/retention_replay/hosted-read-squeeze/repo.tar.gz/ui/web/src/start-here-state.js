export const START_HERE_KEY = 'fl-start-here-dismissed'

export function readStartHereDismissed(storage) {
  try { return (storage === undefined ? globalThis.localStorage : storage)?.getItem(START_HERE_KEY) === '1' } catch { return false }
}

export function saveStartHereDismissed(storage) {
  try { (storage === undefined ? globalThis.localStorage : storage)?.setItem(START_HERE_KEY, '1') } catch { /* The current dismissal still works. */ }
}
