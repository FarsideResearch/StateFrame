import { createRouter, createWebHistory } from 'vue-router'
import { normalizeFileLocation } from './file-root.js'

const routes = [
  { path: '/', name: 'home', component: () => import('./views/HomeView.vue') },
  { path: '/runs', name: 'runs', component: () => import('./views/RunsView.vue') },
  { path: '/run', name: 'run', component: () => import('./views/RunView.vue') },
  { path: '/experiments', name: 'experiments', component: () => import('./views/ExperimentsView.vue') },
  { path: '/experiment/:name', name: 'experiment', component: () => import('./views/ExperimentView.vue') },
  { path: '/file', name: 'file', component: () => import('./views/FileView.vue') },
  { path: '/grades', name: 'grades', component: () => import('./views/GradesView.vue') },
  { path: '/:pathMatch(.*)*', name: 'not-found', component: () => import('./views/NotFoundView.vue') },
]

const router = createRouter({ history: createWebHistory(), routes })
router.beforeEach(normalizeFileLocation)
export default router
