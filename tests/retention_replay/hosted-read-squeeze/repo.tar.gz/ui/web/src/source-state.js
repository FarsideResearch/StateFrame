export function sourceState(source) {
  const status = source?.status || 'unavailable'
  if (status === 'ready') return { tone: 'success', title: source?.mode === 'demo' ? 'Demo data ready' : 'Data ready', action: 'Open Runs to inspect the available runs.' }
  if (status === 'partial') return { tone: 'warning', title: 'Some data is available', action: 'Open Runs, or add the missing data folder.' }
  if (status === 'invalid') return { tone: 'error', title: 'Data setup needs attention', action: 'Check sources.json and restart Frame Lab.' }
  return { tone: 'warning', title: 'No data connected', action: 'Start with framelab ui --data PATH/TO/RUNS.' }
}
