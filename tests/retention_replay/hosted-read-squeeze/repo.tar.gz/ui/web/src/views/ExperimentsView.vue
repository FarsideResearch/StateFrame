<template>
  <div class="page page--fill">
    <div class="page-head">
      <div>
        <h1>Experiments</h1>
      </div>
      <div class="actions"><span class="small muted">{{ filtered.length }} of {{ list.length }} experiments</span><v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="load(true)">Refresh</v-btn></div>
    </div>
    <div class="toolbar">
      <v-text-field v-model="q" :prepend-inner-icon="mdiMagnify" label="Filter experiments" placeholder="Name or title" style="max-width: 360px; min-width: 240px" clearable />
      <v-switch v-model="resultsOnly" label="With a written report" class="flex-grow-0" />
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load(true)">Retry</v-btn></v-alert>
    <section class="panel fill">
      <v-progress-linear v-if="loading" indeterminate class="loadbar" />
      <div class="panel-body flush">
        <table v-if="filtered.length" class="fl-table">
          <thead>
            <tr>
              <th v-for="c in cols" :key="c.key" scope="col" class="sortable" :class="{ r: c.num }" :aria-sort="sortKey === c.key ? (sortDesc ? 'descending' : 'ascending') : 'none'">
                <button type="button" class="table-sort" :aria-label="`Sort experiments by ${c.label}`" @click="sortBy(c.key)">
                  {{ c.label }}<v-icon v-if="sortKey === c.key" :icon="sortDesc ? mdiArrowDown : mdiArrowUp" size="11" aria-hidden="true" />
                </button>
              </th>
              <th scope="col">Results</th>
            </tr>
          </thead>
          <tbody>
              <tr v-for="e in filtered" :key="e.name" class="click focusable-row" tabindex="0" role="link" :aria-label="`Open experiment ${e.name}`" @click="open(e)" @keydown.enter.prevent="open(e)" @keydown.space.prevent="open(e)">
                <td class="mono strong" style="white-space: nowrap"><RouterLink :to="{ name: 'experiment', params: { name: e.name } }" @click.stop>{{ e.name }}</RouterLink></td>
              <td style="max-width: 520px"><TruncatedValue :value="e.title" label="experiment title" /></td>
              <td class="small muted" style="white-space: nowrap">{{ e.date || '' }}</td>
              <td class="num">{{ e.files }}</td>
              <td class="num">{{ e.runs ?? 'not recorded' }}</td>
              <td class="small muted" style="white-space: nowrap">{{ fmtTime(e.mtime) }}</td>
              <td style="white-space: nowrap">
                <span v-if="e.has_results_md" class="tag sm tone-primary">Report</span>
                <span v-if="e.has_results_json" class="tag sm outline" style="margin-left: 4px">Data</span>
              </td>
            </tr>
          </tbody>
        </table>
        <LoadingRows v-else-if="loading" :rows="12" />
        <EmptyState v-else-if="list.length" title="No experiments match" hint="Clear the filter or turn off the written report filter." />
        <EmptyState v-else title="No experiments yet" hint="Experiment results appear here after framelab run --out PATH/TO/RUNS/experiments/NAME/RESULTS.json, then framelab ui --data PATH/TO/RUNS." />
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiArrowDown, mdiArrowUp, mdiMagnify, mdiRefresh } from '@mdi/js'
import { api, fmtTime, invalidateApiCache } from '../api'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import TruncatedValue from '../components/TruncatedValue.vue'
import { createRequestState } from '../request-state.js'
import { sortByField } from '../sort-utils.js'

defineOptions({ name: 'ExperimentsView' })
const list = ref([])
const route = useRoute()
const router = useRouter()
const q = ref(typeof route.query.eq === 'string' ? route.query.eq : '')
const resultsOnly = ref(route.query.er === '1')
const error = ref('')
const loading = ref(false)
const sortKey = ref(typeof route.query.esort === 'string' && ['name', 'title', 'date', 'files', 'runs', 'mtime'].includes(route.query.esort) ? route.query.esort : 'mtime')
const sortDesc = ref(route.query.edesc !== '0')
const cols = [
  { key: 'name', label: 'Experiment' }, { key: 'title', label: 'Title' }, { key: 'date', label: 'Date' },
  { key: 'files', label: 'Files', num: true }, { key: 'runs', label: 'Runs', num: true }, { key: 'mtime', label: 'Updated' },
]
const requestState = createRequestState()
async function load(force = false) {
  const request = requestState.begin()
  loading.value = true
  error.value = ''
  list.value = []
  try {
    if (force) invalidateApiCache('experiments')
    const response = await api('experiments', {}, { cached: true, force, signal: request.signal })
    if (requestState.isCurrent(request.id)) list.value = response.experiments
  } catch (e) { if (requestState.isCurrent(request.id)) error.value = e.message } finally { if (requestState.isCurrent(request.id)) loading.value = false }
}
function sortBy(k) {
  if (sortKey.value === k) sortDesc.value = !sortDesc.value
  else { sortKey.value = k; sortDesc.value = k === 'mtime' || k === 'files' || k === 'runs' }
  router.replace({ query: { ...route.query, esort: sortKey.value, edesc: sortDesc.value ? '1' : '0' } })
}
function open(e) { router.push({ name: 'experiment', params: { name: e.name } }) }
const filtered = computed(() => {
  const t = (q.value || '').toLowerCase()
  const rows = list.value
    .filter((e) => (!resultsOnly.value || e.has_results_md) && (!t || `${e.name} ${e.title}`.toLowerCase().includes(t)))
  return sortByField(rows, sortKey.value, sortDesc.value)
})
watch(q, (value) => router.replace({ query: { ...route.query, eq: value || undefined } }))
watch(resultsOnly, (value) => router.replace({ query: { ...route.query, er: value ? '1' : undefined } }))
watch(() => [route.query.eq, route.query.er], ([nextQ, nextResults]) => {
  q.value = typeof nextQ === 'string' ? nextQ : ''
  resultsOnly.value = nextResults === '1'
})
onMounted(load)
onBeforeUnmount(() => requestState.cancel())
</script>
