<template>
  <div class="page page--fill">
    <div class="page-head">
      <div>
        <h1>Grades</h1>
      </div>
      <div class="meta">
        <v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="load">Refresh</v-btn>
        <span class="tag tone-success">{{ counts.fixed }} unique tasks fixed</span>
        <span class="tag tone-error">{{ counts.notFixed }} unique tasks not fixed</span>
        <span class="tag outline">{{ proofs.length }} proof files</span>
      </div>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load">Retry</v-btn></v-alert>
    <div class="split grades-grid fill">
      <section class="panel">
        <div class="panel-head"><h2 class="title">Proofs and grades</h2><span class="end tiny muted">{{ proofs.length }} files</span></div>
        <v-progress-linear v-if="loading" indeterminate class="loadbar" />
        <div class="panel-body flush">
          <table v-if="proofs.length" class="fl-table">
            <thead><tr><th scope="col">Source</th><th scope="col">Task</th><th scope="col">Type</th><th scope="col">Scope</th><th scope="col">Verdict</th><th scope="col">Cases</th><th scope="col">Candidate</th><th scope="col">When</th></tr></thead>
            <tbody>
              <tr v-for="p in visibleProofs" :key="p.root + p.path" class="click focusable-row" tabindex="0" role="link" :aria-label="`Open proof ${p.task_id}`" @click="openProof(p)" @keydown.enter.prevent="openProof(p)" @keydown.space.prevent="openProof(p)">
                <td class="mono tiny" style="white-space: nowrap">{{ p.source }}</td>
                <td class="mono tiny" style="white-space: nowrap">{{ p.task_id }}</td>
                <td><span class="tag sm outline">{{ p.graded ? 'graded' : 'proof' }}</span></td>
                <td><span class="tag sm outline">{{ valueLabel(p.grade_scope) }}</span></td>
                <td><span v-if="p.verdict && p.verdict !== 'unknown'" class="tag sm" :class="toneClass(verdictColor(p.verdict))">{{ valueLabel(p.verdict) }}</span><span v-else class="tag sm outline">Not graded</span></td>
                <td>
                  <div class="row wrap" style="gap: 4px">
                    <span v-for="(s, c) in p.cases" :key="c" class="tag sm" :class="s === 'PASS' ? 'tone-success' : s === 'FAIL' ? 'tone-error' : 'outline'">{{ valueLabel(c) }}: {{ valueLabel(s) }}</span>
                  </div>
                </td>
                <td class="mono tiny muted">{{ (p.candidate_sha256 || '').slice(0, 10) }}</td>
                <td class="tiny muted" style="white-space: nowrap">{{ fmtTime(p.mtime) }}</td>
              </tr>
            </tbody>
          </table>
          <LoadingRows v-else-if="loading" :rows="10" />
          <EmptyState v-else title="No grades yet" hint="Proof and grade files appear here when you add them under PATH/TO/RUNS/grades and start framelab ui --data PATH/TO/RUNS." />
        </div>
        <div class="panel-foot">A proof's case PASS is not a verdict. Only *.graded.json carries FIXED or NOT_FIXED. A task-scoped grade is never attached to an individual run.<v-btn v-if="visibleProofs.length < proofs.length" size="small" variant="text" @click="proofLimit += 100">Show more</v-btn></div>
      </section>
      <section class="panel">
        <div class="panel-head"><h2 class="title">Reports</h2><span class="end tiny muted">{{ docs.length }} files</span></div>
        <div class="panel-body flush">
          <RouterLink v-for="d in visibleDocs" :key="d.name" class="list-row" :to="{ name: 'file', query: { root: 'grades', path: d.name } }">
            <v-icon :icon="d.name.endsWith('.md') ? mdiFileDocumentOutline : mdiCodeJson" size="15" class="muted" />
            <span class="main mono small ellip" :title="d.name">{{ d.name }}</span><span class="aside">{{ fmtBytes(d.size) }}</span>
          </RouterLink>
          <LoadingRows v-if="loading && !docs.length" />
          <EmptyState v-else-if="!docs.length" title="No reports yet" hint="Markdown or JSON reports appear here when you add them under PATH/TO/RUNS/grades and start framelab ui --data PATH/TO/RUNS." />
          <div v-if="visibleDocs.length < docs.length" class="panel-foot"><v-btn size="small" variant="text" @click="docLimit += 100">Show more</v-btn></div>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { mdiCodeJson, mdiFileDocumentOutline, mdiRefresh } from '@mdi/js'
import { api, fmtBytes, fmtTime, toneClass, verdictColor } from '../api'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import { createRequestState } from '../request-state.js'
import { valueLabel } from '../value-labels.js'

const proofs = ref([])
const router = useRouter()
const docs = ref([])
const error = ref('')
const loading = ref(false)
const proofLimit = ref(100)
const docLimit = ref(100)
const visibleProofs = computed(() => proofs.value.slice(0, proofLimit.value))
const visibleDocs = computed(() => docs.value.slice(0, docLimit.value))
const requestState = createRequestState()
const counts = computed(() => ({
  fixed: new Set(proofs.value.filter((p) => p.verdict === 'FIXED').map((p) => p.task_id)).size,
  notFixed: new Set(proofs.value.filter((p) => p.verdict === 'NOT_FIXED').map((p) => p.task_id)).size,
}))
function openProof(p) { router.push({ name: 'file', query: { root: p.root, path: p.path } }) }
async function load() {
  const request = requestState.begin()
  loading.value = true
  error.value = ''
  proofs.value = []
  docs.value = []
  try {
    const r = await api('grades', {}, { signal: request.signal })
    if (!requestState.isCurrent(request.id)) return
    proofs.value = r.proofs
    // Reports first, then manifests/proofs
    docs.value = r.docs.sort((a, b) => (a.name.endsWith('.md') === b.name.endsWith('.md') ? a.name.localeCompare(b.name) : a.name.endsWith('.md') ? -1 : 1))
  } catch (e) { if (requestState.isCurrent(request.id)) error.value = e.message } finally { if (requestState.isCurrent(request.id)) loading.value = false }
}
onMounted(load)
onBeforeUnmount(() => requestState.cancel())
</script>
