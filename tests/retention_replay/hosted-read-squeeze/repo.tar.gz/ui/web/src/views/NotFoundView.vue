<template>
  <div class="page">
    <section class="panel">
      <div class="panel-body">
        <EmptyState title="Frame Lab page not found" :hint="`No inspection route matches ${route.fullPath}.`">
          <RouterLink class="small" to="/">Return to Overview</RouterLink>
        </EmptyState>
      </div>
    </section>
  </div>
</template>

<script setup>
import { useRoute } from 'vue-router'
import EmptyState from '../components/EmptyState.vue'

const route = useRoute()
</script>
