<template>
  <div class="page page--fill">
    <div class="page-head">
      <div style="min-width: 0">
        <RouterLink to="/experiments" class="crumb"><v-icon :icon="mdiArrowLeft" size="14" />Experiments</RouterLink>
        <h1 class="mono ellip" style="font-size: 1.15rem; letter-spacing: 0">{{ name }}</h1>
      </div>
      <div v-if="d" class="meta">
        <span class="tag outline">{{ d.files.length }}{{ d.files_capped ? '+' : '' }} files</span>
        <span class="tag outline">{{ d.tables.length }} parsed tables</span>
        <span v-if="d.results_md_truncated" class="tag tone-warning">RESULTS.md truncated</span>
        <span v-if="d.manifest" class="tag tone-primary">Comparison settings available</span>
        <span v-if="d.comparison" class="tag" :class="d.comparison.status === 'ready' ? 'tone-success' : 'tone-warning'">{{ valueLabel(d.comparison.status) }} comparison</span>
      </div>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load(name, true)">Retry</v-btn></v-alert>
    <ExperimentComparison v-if="d?.comparison" :comparison="d.comparison" />
    <div class="split cols-main-side fill">
      <section class="panel">
        <div class="panel-head" style="padding-top: 0; padding-bottom: 0">
          <v-tabs v-model="tab">
            <v-tab value="results">RESULTS.md</v-tab>
            <v-tab value="tables" :disabled="!d?.tables.length">Parsed tables ({{ d?.tables.length || 0 }})</v-tab>
          </v-tabs>
        </div>
        <v-progress-linear v-if="loading" indeterminate class="loadbar" />
        <div class="panel-body">
          <LoadingRows v-if="loading && !d" :rows="12" />
            <template v-else-if="d">
            <template v-if="tab === 'results'">
              <MdView v-if="d.results_md" :source="d.results_md" :artifact="{ root: 'experiments', path: `${name}/RESULTS.md` }" />
              <EmptyState v-else :icon="mdiFileDocumentOutline" title="No written results" hint="A RESULTS.md report appears here when you add one to this experiment folder; browse its files on the right." />
            </template>
            <MdTables v-else :tables="d.tables" />
          </template>
        </div>
      </section>
      <section v-if="d?.manifest" class="panel experiment-contract">
          <div class="panel-head"><h2 class="title">Declared comparison contract</h2><span class="end tiny muted">not inferred from outcomes</span></div>
        <div class="panel-body">
          <v-alert v-if="d.manifest.schema_status" type="warning" density="compact">Comparison settings need attention. Open Raw comparison settings for details.</v-alert>
          <div class="row wrap small muted">
            <span v-if="d.manifest.match_keys">Matched by: {{ listLabel(d.manifest.match_keys) }}</span>
            <span v-if="d.manifest.arms">Variants: {{ armLabel(d.manifest.arms) }}</span>
          </div>
          <ul class="small">
            <li v-for="metric in d.manifest.metrics || []" :key="metric.key">{{ metric.label || valueLabel(metric.key) }}: {{ valueLabel(metric.direction, 'Direction not recorded') }}</li>
          </ul>
          <details class="settings-technical"><summary>Raw comparison settings</summary><JsonTree :value="d.manifest" :open-depth="2" /></details>
        </div>
      </section>
      <section class="panel">
        <div class="panel-sub"><v-text-field v-model="fq" :prepend-inner-icon="mdiMagnify" label="Filter experiment files" placeholder="Filename" clearable /></div>
        <div class="panel-body flush">
          <RouterLink v-for="fi in files" :key="fi.path" class="list-row" :to="{ name: 'file', query: { root: 'experiments', path: fi.path, offset: undefined, pointer: undefined } }">
            <span class="main mono small ellip" :title="fi.path">{{ fi.path.slice(name.length + 1) }}</span>
            <span class="aside">{{ fmtBytes(fi.size) }}</span>
          </RouterLink>
          <LoadingRows v-if="loading && !d" />
          <EmptyState v-else-if="d && !files.length" title="No files match" hint="Clear the filter, or write an experiment to PATH/TO/RUNS/experiments with framelab run --out PATH/TO/RUNS/experiments/NAME/RESULTS.json." />
        </div>
        <div v-if="d" class="panel-foot row">
          <span>{{ files.length }} of {{ d.files_total }} files</span>
          <v-btn v-if="d.files_has_more" size="small" variant="text" :loading="loading" @click="loadMore">Load more</v-btn>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiArrowLeft, mdiFileDocumentOutline, mdiMagnify } from '@mdi/js'
import { api, fmtBytes, invalidateApiCache } from '../api'
import MdView from '../components/MdView.vue'
import MdTables from '../components/MdTables.vue'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import JsonTree from '../components/JsonTree.vue'
import ExperimentComparison from '../components/ExperimentComparison.vue'
import { createRequestState } from '../request-state.js'
import { appendExperimentPage } from '../page-state.js'
import { valueLabel } from '../value-labels.js'

const route = useRoute()
const router = useRouter()
const name = computed(() => route.params.name || '')
const d = ref(null)
const error = ref('')
const loading = ref(false)
const tab = computed({ get: () => route.query.etab === 'tables' ? 'tables' : 'results', set: (value) => router.replace({ query: { ...route.query, etab: value === 'tables' ? 'tables' : undefined } }) })
const fq = ref(typeof route.query.efq === 'string' ? route.query.efq : '')
const requestState = createRequestState()
async function load(n, force = false, offset = 0) {
  if (!n) return
  const request = requestState.begin()
  loading.value = true
  error.value = ''
  if (offset === 0) d.value = null
  try {
    if (force) invalidateApiCache('experiment')
    const r = await api('experiment', { name: n, q: fq.value, offset, limit: 200 }, { force, signal: request.signal })
    if (requestState.isCurrent(request.id)) d.value = appendExperimentPage(d.value, r, offset)
  } catch (e) { if (requestState.isCurrent(request.id)) error.value = e.message } finally { if (requestState.isCurrent(request.id)) loading.value = false }
}
const files = computed(() => d.value?.files || [])
function loadMore() { if (d.value?.files_has_more) load(name.value, false, d.value.files_next_offset) }
watch(name, (n) => load(n), { immediate: true })
watch(fq, (value) => { router.replace({ query: { ...route.query, efq: value || undefined } }); if (name.value) load(name.value) })
watch(() => route.query.efq, (value) => { const next = typeof value === 'string' ? value : ''; if (next !== fq.value) fq.value = next })
function listLabel(value) { return Array.isArray(value) ? value.map(valueLabel).join(', ') : valueLabel(value) }
function armLabel(value) { return Array.isArray(value) ? value.map((a) => typeof a === 'string' ? a : a?.name || 'unknown').join(', ') : String(value) }
onBeforeUnmount(() => requestState.cancel())
</script>
