<template>
  <div class="page page--fill" style="gap: 12px">
    <div class="page-head">
      <div style="min-width: 0">
        <RouterLink to="/runs" class="crumb"><v-icon :icon="mdiArrowLeft" size="14" />Runs</RouterLink>
        <h1 class="mono ellip" style="font-size: 1.05rem; letter-spacing: 0" :title="id">{{ id }}</h1>
      </div>
      <div v-if="meta" class="run-outcome">
        <div class="run-outcome__primary"><span class="tag dot" :class="toneClass(statusColor(meta.status))">{{ valueLabel(meta.status) }}</span><span v-if="meta.result">Recorded result: {{ valueLabel(meta.result) }}</span></div>
        <div class="run-outcome__grades small muted"><span :title="meta.run_verdict_source || 'No run grade was recorded.'">Run grade: {{ valueLabel(meta.run_verdict, 'Not graded') }}</span><span v-if="meta.task_grade" :title="meta.task_grade.source">Task grade: {{ valueLabel(meta.task_grade.verdict, 'Not graded') }}</span></div>
      </div>
      <div class="actions"><v-btn :prepend-icon="mdiRefresh" :loading="loadingRun" @click="load(true)">Refresh</v-btn><CopyButton :value="id || ''" text="Copy run id" /></div>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load(true)">Retry</v-btn></v-alert>
    <RunEvidenceOverview v-if="evidence" :evidence="evidence" />
    <div class="toolbar toolbar--tabs">
      <v-tabs v-model="tab">
        <v-tab value="timeline" :prepend-icon="mdiTimelineTextOutline">Timeline</v-tab>
        <v-tab value="frames" :prepend-icon="mdiLayersTripleOutline">Frames</v-tab>
        <v-tab value="files" :prepend-icon="mdiFolderOutline">Files</v-tab>
        <v-tab value="meta" :prepend-icon="mdiCodeJson">Run details</v-tab>
      </v-tabs>
      <v-select
        v-if="tab === 'timeline' || tab === 'frames'"
         v-model="jref" :items="journalItems" item-title="title" item-value="ref" label="Journal source" placeholder="Choose a journal" class="ml-auto"
        style="max-width: 560px; min-width: 260px; margin-bottom: 6px" :loading="loadingRun" no-data-text="No journals in this run"
      />
    </div>

    <div class="fill stack">
      <LoadingRows v-if="loadingRun && !meta" :rows="10" />
      <TimelinePanel v-else-if="tab === 'timeline' && jref" :id="id" :jref="jref" />
      <FramesPanel v-else-if="tab === 'frames' && jref" :id="id" :jref="jref" />
      <RunFilesPanel v-else-if="tab === 'files'" :id="id" :files="files" :has-tgz="!!meta?.has_tgz" />
      <section v-else-if="tab === 'meta' && meta" class="panel grow">
        <div class="panel-body"><RunSettings :meta="meta" /></div>
      </section>
      <section v-else-if="!loadingRun && !id" class="panel grow">
        <EmptyState :icon="mdiFileQuestionOutline" title="No run selected" hint="Choose a run from the Runs list or open a shared run URL." />
      </section>
      <section v-else-if="!loadingRun" class="panel grow">
        <EmptyState
          :icon="mdiFileQuestionOutline" title="No journal in this run"
          hint="There is no events.jsonl in the worker dir or worker.tgz. The Files tab may still have sidecars."
        >
          <v-btn class="mt-2" @click="tab = 'files'">Open files</v-btn>
        </EmptyState>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, watch, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiArrowLeft, mdiCodeJson, mdiFileQuestionOutline, mdiFolderOutline, mdiLayersTripleOutline, mdiRefresh, mdiTimelineTextOutline } from '@mdi/js'
import { api, fmtBytes, statusColor, toneClass } from '../api'
import { valueLabel } from '../value-labels.js'
import RunSettings from '../components/RunSettings.vue'
import TimelinePanel from '../components/TimelinePanel.vue'
import FramesPanel from '../components/FramesPanel.vue'
import RunFilesPanel from '../components/RunFilesPanel.vue'
import RunEvidenceOverview from '../components/RunEvidenceOverview.vue'
import CopyButton from '../components/CopyButton.vue'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import { createRequestState } from '../request-state.js'

const route = useRoute()
const router = useRouter()
const id = computed(() => Array.isArray(route.query.id) ? route.query.id[0] : route.query.id)
const meta = ref(null)
const evidence = ref(null)
const files = ref([])
const journals = ref([])
const error = ref('')
const loadingRun = ref(false)
const runRequest = createRequestState()

const TABS = ['timeline', 'frames', 'files', 'meta']
const tab = computed({
  get: () => (TABS.includes(route.query.tab) ? route.query.tab : 'timeline'),
  set: (v) => router.push({ query: { ...route.query, tab: v } }),
})
const jref = computed({
  // A stale ?j= that is not in this run's journals would show an endless empty panel; fall back.
  get: () => { const requested = Array.isArray(route.query.j) ? route.query.j[0] : route.query.j; return journals.value.some((j) => j.ref === requested) ? requested : journals.value[0]?.ref },
  set: (v) => router.push({ query: { ...route.query, j: v, i: undefined, rid: undefined, file: undefined, member: undefined, rpath: undefined, mq: undefined, fp: undefined, frecords: undefined, foffset: undefined, fchunk: undefined } }),
})
const journalItems = computed(() => journals.value.map((j) => ({ ref: j.ref, title: `${j.ref.replace('tgz:', '[tgz] ')}  (${fmtBytes(j.size)})` })))

async function load(force = false) {
  if (!id.value || route.name !== 'run') return
  const request = runRequest.begin()
  loadingRun.value = true
  error.value = ''
  meta.value = null
  evidence.value = null
  files.value = []
  journals.value = []
  try {
    const r = await api('run', { id: id.value }, { force, signal: request.signal })
    if (!runRequest.isCurrent(request.id)) return
    meta.value = r.meta
    evidence.value = r.evidence || null
    files.value = r.files
    journals.value = r.journals
  } catch (e) { if (runRequest.isCurrent(request.id)) error.value = e.message } finally { if (runRequest.isCurrent(request.id)) loadingRun.value = false }
}
watch(id, load, { immediate: true })
onBeforeUnmount(() => runRequest.cancel())
</script>

<style scoped>
.run-outcome { display: grid; gap: var(--fl-s1); min-width: 0; }
.run-outcome__primary, .run-outcome__grades { display: flex; align-items: center; flex-wrap: wrap; gap: var(--fl-s2); }
</style>
