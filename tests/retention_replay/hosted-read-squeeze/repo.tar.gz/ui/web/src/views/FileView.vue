<template>
  <div class="page page--fill">
    <div class="page-head">
      <div style="min-width: 0">
        <RouterLink class="crumb" :to="backTo"><v-icon :icon="mdiArrowLeft" size="14" />{{ backLabel }}</RouterLink>
        <h1 class="mono ellip" style="font-size: 1rem; letter-spacing: 0" :title="`${rootLabel} / ${path}`"><span class="muted">{{ rootLabel }} /</span> {{ path }}</h1>
      </div>
      <div class="actions"><CopyButton :value="path" text="Copy path" /></div>
    </div>
    <v-alert v-if="error" type="error">{{ error }}</v-alert>
    <section class="panel fill">
      <v-progress-linear v-if="loading" indeterminate class="loadbar" />
      <div class="panel-body" :class="{ flush: payload?.kind === 'dir' }">
        <template v-if="payload?.kind === 'dir'">
          <RouterLink
            v-for="e in payload.entries" :key="e.name" class="list-row"
            :to="{ name: 'file', query: { root, path: (path ? path + '/' : '') + e.name.replace(/\/$/, ''), offset: undefined, pointer: undefined, records: undefined } }"
          >
            <v-icon :icon="e.name.endsWith('/') ? mdiFolderOutline : mdiFileOutline" size="15" class="muted" />
            <span class="main mono small ellip">{{ e.name }}</span><span class="aside">{{ fmtBytes(e.size) }}</span>
          </RouterLink>
          <div v-if="payload.has_more" class="panel-foot row">
            <span class="muted small">Showing {{ payload.offset + payload.entries.length }} of {{ payload.total }} entries.</span>
            <v-btn size="small" variant="text" :loading="loading" @click="loadNextDirectoryPage">Load more</v-btn>
          </div>
          <EmptyState v-if="!payload.entries.length" title="Empty directory" hint="Files appear here when they are added to the configured data folder; start framelab ui --data PATH/TO/RUNS to inspect them." />
        </template>
        <FilePayload v-else-if="payload" :payload="payload" :artifact="{ root, path }" :busy="loading" @query="onQuery" />
        <LoadingRows v-else-if="loading" :rows="12" />
        <EmptyState v-else-if="!error" title="No file selected" hint="Choose a file from Runs, Experiments, or Grades after starting framelab ui --data PATH/TO/RUNS." />
        <v-btn v-if="error" variant="text" @click="reload">Retry</v-btn>
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiArrowLeft, mdiFileOutline, mdiFolderOutline } from '@mdi/js'
import { api, fmtBytes } from '../api'
import FilePayload from '../components/FilePayload.vue'
import CopyButton from '../components/CopyButton.vue'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import { createRequestState } from '../request-state.js'
import { normalizeFileRoot } from '../file-root.js'

const route = useRoute()
const router = useRouter()
const root = computed(() => normalizeFileRoot(queryValue(route.query.root)) || '')
const rootLabel = computed(() => ({ capability: 'Runs', experiments: 'Experiments', grades: 'Grades' }[root.value] || 'Files'))
const path = computed(() => queryValue(route.query.path) || '')
const expName = computed(() => (root.value === 'experiments' ? path.value.split('/')[0] : null))
const backTo = computed(() => {
  if (root.value === 'experiments' && expName.value) return { name: 'experiment', params: { name: expName.value } }
  if (root.value === 'experiments') return { name: 'experiments' }
  if (root.value === 'capability') return { name: 'runs' }
  return { name: 'grades' }
})
const backLabel = computed(() => expName.value || ({ capability: 'Runs', grades: 'Grades' }[root.value] || 'Sources'))
const payload = ref(null)
const error = ref('')
const loading = ref(false)
const requestState = createRequestState()

function queryValue(value) { return Array.isArray(value) ? value[0] : value }
function requestParams(qq) {
  return Object.fromEntries(Object.entries({ root: normalizeFileRoot(queryValue(qq.root)), path: queryValue(qq.path), pointer: queryValue(qq.pointer), records: queryValue(qq.records), offset: queryValue(qq.offset), limit: queryValue(qq.limit), chunk_offset: queryValue(qq.chunk_offset), chunk_limit: queryValue(qq.chunk_limit) }).filter(([, value]) => value !== undefined && value !== ''))
}

async function reload() {
  if (route.name !== 'file') return
  const mine = requestState.begin()
  loading.value = true
  error.value = ''
  payload.value = null
  try {
    const p = await api('file', requestParams(route.query), { signal: mine.signal })
    if (requestState.isCurrent(mine.id)) payload.value = p
  } catch (e) { if (requestState.isCurrent(mine.id)) { error.value = e.message; payload.value = null } } finally { if (requestState.isCurrent(mine.id)) loading.value = false }
}
watch(() => route.query, reload, { immediate: true, deep: true })

function loadNextDirectoryPage() {
  if (!payload.value?.has_more) return
  router.push({ query: { ...route.query, offset: payload.value.next_offset, limit: payload.value.limit || 200 } })
}

function onQuery(patch) {
  const query = { ...route.query, ...patch }
  if (Object.prototype.hasOwnProperty.call(patch, 'pointer')) {
    query.records = undefined
    query.offset = undefined
    query.chunk_offset = undefined
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'records')) query.chunk_offset = undefined
  router.push({ query })
}
onBeforeUnmount(() => requestState.cancel())
</script>
