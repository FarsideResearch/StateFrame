<template>
  <div class="page page--fill">
    <div class="page-head">
      <div>
        <h1>Runs</h1>
      </div>
      <div class="actions">
        <span class="small muted">{{ fmtNum(filtered.length) }} of {{ fmtNum(runs.length) }} runs</span>
        <v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="load">Refresh</v-btn>
      </div>
    </div>
    <div class="toolbar">
      <v-text-field v-model="q" :prepend-inner-icon="mdiMagnify" label="Search runs" placeholder="Run, task, result" style="max-width: 400px; min-width: 240px" clearable />
      <v-select v-model="status" :items="statusItems" item-title="title" item-value="value" label="Status" style="max-width: 170px; min-width: 140px" clearable />
      <v-select v-model="verdict" :items="verdictItems" item-title="title" item-value="value" label="Grade" style="max-width: 180px; min-width: 150px" clearable />
      <v-switch v-model="journalOnly" label="Journal available" class="flex-grow-0" />
      <button v-if="hasFilters" type="button" class="copy-btn" @click="resetFilters">Reset filters</button>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load">Retry</v-btn></v-alert>
    <section class="panel fill" aria-labelledby="runs-list-heading">
      <h2 id="runs-list-heading" class="sr-only">Indexed runs</h2>
      <v-progress-linear v-if="loading" indeterminate class="loadbar" />
      <div class="table-x table-x--fill">
        <div class="table-x-inner runs-table-inner" role="grid" :aria-rowcount="filtered.length + 1" aria-label="Runs">
          <div class="grid-row grid-head runs-grid" role="row">
            <span v-for="c in cols" :key="c.key" role="columnheader" :aria-sort="sortKey === c.key ? (sortDesc ? 'descending' : 'ascending') : 'none'" :class="{ r: c.num }">
              <button type="button" class="grid-sort" :aria-label="`Sort runs by ${c.label}`" @click="sortBy(c.key)">
                {{ c.label }}<v-icon v-if="sortKey === c.key" :icon="sortDesc ? mdiArrowDown : mdiArrowUp" size="11" aria-hidden="true" />
              </button>
            </span>
          </div>
          <div class="vfill">
            <v-virtual-scroll v-if="filtered.length" class="vfill-abs" :items="filtered" :item-height="40" height="100%">
              <template #default="{ item: r }">
                <div class="grid-row runs-grid focusable-row" role="link" tabindex="0" :aria-rowindex="filtered.indexOf(r) + 2" :aria-label="rowLabel(r)" @click="open(r)" @keydown.enter.prevent="open(r)" @keydown.space.prevent="open(r)">
                  <TruncatedValue :value="r.id" label="run name" :to="{ name: 'run', query: { id: r.id } }" />
                  <TruncatedValue :value="r.task" label="task" />
                  <span class="ellip tiny muted" :title="fmtTime(r.mtime)">{{ fmtTime(r.mtime) }}</span>
                  <span><span class="tag sm dot" :class="toneClass(statusColor(r.status))">{{ valueLabel(r.status) }}</span></span>
                  <span>
                    <span class="tag sm" :class="r.run_verdict && r.run_verdict !== 'unknown' ? toneClass(verdictColor(r.run_verdict)) : 'outline'" :title="r.run_verdict_source || 'No run grade was recorded.'">{{ valueLabel(r.run_verdict, 'Not graded') }}</span>
                  </span>
                  <TruncatedValue :value="r.result" :display="valueLabel(r.result)" label="recorded result" />
                  <span class="num">{{ r.requests ?? 'not recorded' }}</span>
                  <span class="num">{{ r.tests ?? 'not recorded' }}</span>
                  <span class="num">{{ r.prompt_tokens == null ? 'not recorded' : fmtNum(r.prompt_tokens) }}</span>
                </div>
              </template>
            </v-virtual-scroll>
            <LoadingRows v-else-if="loading" :rows="14" />
            <EmptyState v-else-if="runs.length" title="No runs match" hint="Loosen the filters or clear the search.">
              <v-btn class="mt-2" @click="resetFilters">Reset filters</v-btn>
            </EmptyState>
            <EmptyState v-else title="No runs found" hint="Run folders appear here when you start framelab ui --data PATH/TO/RUNS." />
          </div>
        </div>
      </div>
    </section>
    <div class="footnote">A grade appears only when a proof identifies this run. The recorded result comes from the run itself. Request and token counts appear when timings.json records them.</div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { mdiArrowDown, mdiArrowUp, mdiMagnify, mdiRefresh } from '@mdi/js'
import { api, fmtNum, fmtTime, statusColor, toneClass, verdictColor } from '../api'
import EmptyState from '../components/EmptyState.vue'
import LoadingRows from '../components/LoadingRows.vue'
import TruncatedValue from '../components/TruncatedValue.vue'
import { createRequestState } from '../request-state.js'
import { sortByField } from '../sort-utils.js'
import { valueLabel } from '../value-labels.js'

defineOptions({ name: 'RunsView' })
const route = useRoute()
const router = useRouter()
const runs = ref([])
const error = ref('')
const loading = ref(false)
const q = ref(typeof route.query.rq === 'string' ? route.query.rq : '')
const status = ref(typeof route.query.rs === 'string' ? route.query.rs : null)
const verdict = ref(typeof route.query.rv === 'string' ? route.query.rv : null)
const journalOnly = ref(route.query.rj === '1')
const sortKey = ref(typeof route.query.rsort === 'string' ? route.query.rsort : 'mtime')
const sortDesc = ref(route.query.rdesc !== '0')
const requestState = createRequestState()

const cols = [
  { key: 'id', label: 'Run' }, { key: 'task', label: 'Task' },
  { key: 'mtime', label: 'When' }, { key: 'status', label: 'Status' }, { key: 'verdict', field: 'run_verdict', label: 'Grade' },
  { key: 'result', label: 'Recorded result' }, { key: 'requests', label: 'Requests', num: true }, { key: 'tests', label: 'Tests', num: true }, { key: 'prompt_tokens', label: 'Prompt tokens', num: true },
]
const verdictItems = [{ title: 'Fixed', value: 'FIXED' }, { title: 'Not fixed', value: 'NOT_FIXED' }, { title: 'Not graded', value: 'unknown' }]

async function load() {
  const request = requestState.begin()
  loading.value = true
  error.value = ''
  runs.value = []
  try {
    const result = await api('runs', {}, { signal: request.signal })
    if (requestState.isCurrent(request.id)) runs.value = result.runs
  } catch (e) { if (requestState.isCurrent(request.id)) error.value = e.message } finally { if (requestState.isCurrent(request.id)) loading.value = false }
}
onMounted(load)

const hasFilters = computed(() => !!(q.value || status.value || verdict.value || journalOnly.value))
function resetFilters() { q.value = ''; status.value = null; verdict.value = null; journalOnly.value = false; router.replace({ query: { ...route.query, rq: undefined, rs: undefined, rv: undefined, rj: undefined } }) }

const statusItems = computed(() => [...new Set(runs.value.map((r) => r.status).filter(Boolean))].sort().map((value) => ({ title: valueLabel(value), value })))
const filtered = computed(() => {
  const terms = (q.value || '').toLowerCase().split(/\s+/).filter(Boolean)
  const rows = runs.value.filter((r) => {
    if (status.value && r.status !== status.value) return false
    if (verdict.value && r.run_verdict !== verdict.value) return false
    if (journalOnly.value && !r.journal_available) return false
    if (!terms.length) return true
    const hay = `${r.id} ${r.task} ${r.release} ${r.result} ${r.behaviour} ${r.status} ${r.run_verdict} ${r.task_grade?.verdict || ''} ${r.fixture}`.toLowerCase()
    return terms.every((t) => hay.includes(t))
  })
  const field = cols.find((column) => column.key === sortKey.value)?.field || sortKey.value
  return sortByField(rows, field, sortDesc.value)
})
function sortBy(k) {
  if (sortKey.value === k) sortDesc.value = !sortDesc.value
  else { sortKey.value = k; sortDesc.value = true }
  router.replace({ query: { ...route.query, rsort: sortKey.value, rdesc: sortDesc.value ? '1' : '0' } })
}
function open(r) { router.push({ name: 'run', query: { id: r.id } }) }
function rowLabel(r) { return `Open run ${r.id || 'not recorded'}; status ${valueLabel(r.status)}; recorded result ${valueLabel(r.result)}` }
watch(q, (value) => router.replace({ query: { ...route.query, rq: value || undefined } }))
watch(status, (value) => router.replace({ query: { ...route.query, rs: value || undefined } }))
watch(verdict, (value) => router.replace({ query: { ...route.query, rv: value || undefined } }))
watch(journalOnly, (value) => router.replace({ query: { ...route.query, rj: value ? '1' : undefined } }))
watch(() => [route.query.rq, route.query.rs, route.query.rv, route.query.rj], ([nextQ, nextStatus, nextVerdict, nextJournal]) => {
  q.value = typeof nextQ === 'string' ? nextQ : ''
  status.value = typeof nextStatus === 'string' ? nextStatus : null
  verdict.value = typeof nextVerdict === 'string' ? nextVerdict : null
  journalOnly.value = nextJournal === '1'
})
watch(() => [route.query.rsort, route.query.rdesc], ([nextSort, nextDesc]) => {
  if (typeof nextSort === 'string' && cols.some((column) => column.key === nextSort)) sortKey.value = nextSort
  sortDesc.value = nextDesc !== '0'
})
onBeforeUnmount(() => requestState.cancel())
</script>

<style scoped>
/* Wide grid: scroll horizontally as one unit (header + rows) on narrow screens. */
.table-x { flex: 1 1 auto; min-height: 0; overflow-x: auto; overflow-y: hidden; display: flex; flex-direction: column; }
.table-x-inner { flex: 1 1 auto; min-height: 0; min-width: 1200px; display: flex; flex-direction: column; }
</style>
