<template>
  <div class="page">
    <div class="page-head">
      <div>
        <h1>Overview</h1>
        <p class="page-lede">See what the model saw, what it did, how it was checked, and why it stopped.</p>
      </div>
      <div class="actions">
        <v-btn :prepend-icon="mdiRefresh" :loading="loading" @click="load">Refresh</v-btn>
      </div>
    </div>
    <v-alert v-if="error" type="error">{{ error }} <v-btn size="small" variant="text" @click="load">Retry</v-btn></v-alert>

    <div v-if="!data && loading" class="kpis">
      <div v-for="i in 3" :key="i" class="kpi"><LoadingRows :rows="2" /></div>
    </div>

    <template v-if="data">
      <section class="panel source-panel" :class="`source-panel--${sourceView.tone}`">
        <div class="panel-head">
          <div>
            <div class="kicker">Data source</div>
            <div class="title">{{ sourceView.title }}</div>
          </div>
          <span class="end tag sm outline">{{ data.source?.mode === 'demo' ? 'Demo data' : data.source?.mode === 'data-root' ? 'Your data' : data.source?.mode === 'config' ? 'Configured data' : 'Not connected' }}</span>
        </div>
        <div class="panel-body source-panel__body">
          <p class="source-panel__copy">{{ data.source?.name || 'Frame Lab source' }}</p>
          <p class="muted small">{{ sourceView.action }}</p>
          <code v-if="!data.source?.ready" class="source-command">framelab ui --data PATH/TO/RUNS</code>
          <RouterLink v-else class="small" to="/runs">Inspect configured runs</RouterLink>
        </div>
      </section>

      <StartHere v-if="data.source?.mode === 'demo'" :run-id="data.product_story?.featured_runs?.[0]?.id || data.recent_runs?.[0]?.id || ''" experiment-name="paired-demo" />

      <div class="kpis">
        <RouterLink v-for="t in tiles" :key="t.label" class="kpi" :to="t.to">
          <span class="kicker">{{ t.label }}</span>
          <span class="value">{{ fmtNum(t.value) || 0 }}</span>
          <span v-if="t.sub" class="sub">{{ t.sub }}</span>
        </RouterLink>
      </div>

      <div class="split flow">
        <div class="stack">
          <section class="panel" aria-labelledby="workflow-title">
            <div class="panel-head">
              <div>
                <div class="kicker">Command line</div>
                <h2 id="workflow-title" class="title">Run a frame experiment</h2>
              </div>
            </div>
            <div class="panel-body">
              <p class="muted small workflow-lede">Pick one request a run sent, change what the model sees, and compare first responses. Returned tool calls are never executed.</p>
              <ol class="workflow">
                <li v-for="(step, index) in workflow" :key="step.label">
                  <span class="workflow__number">{{ String(index + 1).padStart(2, '0') }}</span>
                  <div class="workflow__body">
                    <strong>{{ step.label }}</strong>
                    <span class="muted small">{{ step.hint }}</span>
                    <code class="source-command">{{ step.command }}</code>
                  </div>
                </li>
              </ol>
            </div>
          </section>
        </div>
        <div class="stack">
          <section class="panel capped">
            <div class="panel-head">
              <h2 class="title">Recent runs</h2>
              <RouterLink to="/runs" class="end small">All runs</RouterLink>
            </div>
            <div class="panel-body flush">
              <table v-if="data.recent_runs.length" class="fl-table fixed">
                <colgroup><col><col style="width: 160px"><col style="width: 140px"><col style="width: 90px"><col style="width: 130px"></colgroup>
                <thead><tr><th>Run</th><th>Status</th><th>Recorded result</th><th class="r">Requests</th><th>When</th></tr></thead>
                <tbody>
                   <tr v-for="r in data.recent_runs" :key="r.id" class="click focusable-row" tabindex="0" role="link" :aria-label="`Open run ${r.id}`" @click="openRun(r)" @keydown.enter.prevent="openRun(r)" @keydown.space.prevent="openRun(r)">
                    <td class="mono small"><TruncatedValue :value="r.id" label="run name" :to="{ name: 'run', query: { id: r.id } }" /></td>
                    <td><span class="tag sm dot" :class="toneClass(statusColor(r.status))">{{ valueLabel(r.status) }}</span></td>
                    <td class="small"><TruncatedValue :value="r.result" :display="valueLabel(r.result)" label="recorded result" /></td>
                    <td class="num">{{ r.requests ?? 'not recorded' }}</td>
                    <td class="tiny muted" style="white-space: nowrap">{{ fmtTime(r.mtime) }}</td>
                  </tr>
                </tbody>
              </table>
              <EmptyState v-else title="No runs yet" hint="Run folders appear here after you start framelab ui --data PATH/TO/RUNS." />
            </div>
          </section>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { mdiRefresh } from '@mdi/js'
import { api, fmtNum, fmtTime, statusColor, toneClass } from '../api'
import { sourceState } from '../source-state'
import EmptyState from '../components/EmptyState.vue'
import StartHere from '../components/StartHere.vue'
import LoadingRows from '../components/LoadingRows.vue'
import TruncatedValue from '../components/TruncatedValue.vue'
import { createRequestState } from '../request-state.js'
import { valueLabel } from '../value-labels.js'

const data = ref(null)
const error = ref('')
const loading = ref(false)
const requestState = createRequestState()
const router = useRouter()
const sourceView = computed(() => sourceState(data.value?.source))

async function load() {
  const request = requestState.begin()
  loading.value = true
  error.value = ''
  try {
    const result = await api('overview', {}, { force: true, signal: request.signal })
    if (requestState.isCurrent(request.id)) data.value = result
  } catch (e) { if (requestState.isCurrent(request.id)) error.value = e.message } finally { if (requestState.isCurrent(request.id)) loading.value = false }
}
onMounted(load)
onBeforeUnmount(() => requestState.cancel())
function openRun(r) { router.push({ name: 'run', query: { id: r.id } }) }
const workflow = [
  { label: 'List the requests a run sent', hint: 'Each row is one model request with its step and size.', command: 'framelab requests RUN_DIR' },
  { label: 'Extract one as a base', hint: 'The request is rebuilt byte for byte and its recorded hash is checked.', command: 'framelab extract RUN_DIR --at step:5 --out base.json' },
  { label: 'Check your variants offline', hint: 'Every edit must match its anchor exactly, or it is refused.', command: 'framelab validate --base base.json --variants variants.json' },
  { label: 'Send and score', hint: 'Each variant goes to your model server n times; only the first action is scored.', command: 'framelab run --base base.json --variants variants.json --scorer scorer.json --out results/run.json' },
]
const tiles = computed(() => {
  const c = data.value?.counts || {}
  const st = c.runs_by_status || {}
  return [
    { label: 'Runs indexed', value: c.runs, sub: `${st.complete || 0} complete, ${st.running || 0} running`, to: '/runs' },
    { label: 'Grades', value: c.proofs, sub: `${c.proofs_fixed ?? 0} fixed, ${c.proofs_not_fixed ?? 0} not fixed`, to: '/grades' },
    { label: 'Experiments', value: c.experiments, sub: 'result folders', to: '/experiments' },
  ]
})
</script>
