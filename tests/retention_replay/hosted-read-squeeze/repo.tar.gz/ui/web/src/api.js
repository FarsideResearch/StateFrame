// Thin fetch wrapper: GET-only, JSON. Cache entries are short-lived and
// explicitly invalidatable because local journals and reports can grow while
// the UI remains open. The cache is bounded to 64 entries / 15 seconds and
// every request also has a bounded deadline.
// Transport fields and page-envelope semantics are documented in
// api-contracts.js; artifact-specific records stay endpoint-owned.
export { API_CONTRACT_VERSION } from './api-contracts.js'

const cache = new Map()
const MAX_CACHE_ENTRIES = 64
const DEFAULT_CACHE_TTL_MS = 15_000
const DEFAULT_TIMEOUT_MS = 30_000
const MAX_API_RESPONSE_BYTES = 32 * 1024 * 1024

function makeUrl(path, params) {
  const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ''))
  return `/api/${path}${qs.toString() ? `?${qs}` : ''}`
}

function requestError(message, code, status, requestId) {
  const err = new Error(message)
  err.code = code
  err.status = status
  err.requestId = requestId
  return err
}

function withDeadline(signal, timeoutMs) {
  const controller = new AbortController()
  let timedOut = false
  const abort = () => controller.abort()
  if (signal) {
    if (signal.aborted) controller.abort()
    else signal.addEventListener('abort', abort, { once: true })
  }
  const timer = setTimeout(() => { timedOut = true; controller.abort() }, timeoutMs)
  return { signal: controller.signal, timedOut: () => timedOut, cleanup: () => {
    clearTimeout(timer)
    signal?.removeEventListener('abort', abort)
  } }
}

export async function api(path, params = {}, { cached = false, force = false, signal, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
  const url = makeUrl(path, params)
  const now = Date.now()
  const cachedEntry = cache.get(url)
  if (cached && !force && cachedEntry && cachedEntry.expiresAt > now) {
    cachedEntry.lastUsedAt = now
    return cachedEntry.promise
  }
  if (force) cache.delete(url)
  const reusableEntry = force ? null : cachedEntry
  const deadline = withDeadline(signal, timeoutMs)
  let entry
  const p = fetch(url, {
    signal: deadline.signal,
    ...(reusableEntry?.etag ? { headers: { 'If-None-Match': reusableEntry.etag } } : {}),
  }).then(async (r) => {
    if (r.status === 304) {
      if (reusableEntry && reusableEntry.data !== undefined) return reusableEntry.data
      throw requestError('The server returned an empty unchanged response.', 'INVALID_NOT_MODIFIED', r.status)
    }
    let body = null
    let validJson = true
    const declaredLength = Number(r.headers?.get?.('content-length'))
    if (Number.isFinite(declaredLength) && declaredLength > MAX_API_RESPONSE_BYTES) {
      throw requestError('The response exceeds Frame Lab\'s payload limit.', 'RESPONSE_LIMIT', 413)
    }
    try {
      if (typeof r.text === 'function') {
        const raw = await r.text()
        if (raw.length > MAX_API_RESPONSE_BYTES) throw requestError('The response exceeds Frame Lab\'s payload limit.', 'RESPONSE_LIMIT', 413)
        body = raw ? JSON.parse(raw) : null
      } else {
        body = await r.json()
      }
    } catch (error) {
      if (error?.code === 'RESPONSE_LIMIT') throw error
      validJson = false
    }
    if (r.ok && !validJson) {
      throw requestError('The server returned invalid JSON.', 'INVALID_JSON_RESPONSE', r.status)
    }
    if (!r.ok) {
      throw requestError(body?.error || `HTTP ${r.status}`, body?.code || 'HTTP_ERROR', r.status,
        body?.request_id || r.headers?.get?.('X-FrameLab-Request-ID'))
    }
    if (entry) {
      entry.data = body
      const responseEtag = r.headers?.get?.('etag')
      if (responseEtag) entry.etag = responseEtag
    }
    return body
  }).catch((error) => {
    if (error?.name === 'AbortError') {
      throw requestError(deadline.timedOut() ? 'The request timed out. Retry when the source is ready.' : 'The request was cancelled.',
        deadline.timedOut() ? 'REQUEST_TIMEOUT' : 'REQUEST_ABORTED')
    }
    if (!error?.code && (error instanceof TypeError || error?.name === 'TypeError')) {
      throw requestError('The request could not reach Frame Lab. Check the local server and retry.', 'NETWORK_ERROR')
    }
    throw error
  }).finally(deadline.cleanup)
  if (cached) {
    entry = {
      promise: p,
      expiresAt: now + DEFAULT_CACHE_TTL_MS,
      lastUsedAt: now,
      etag: reusableEntry?.etag,
      data: reusableEntry?.data,
    }
    cache.set(url, entry)
    while (cache.size > MAX_CACHE_ENTRIES) {
      const oldest = [...cache.entries()].sort((a, b) => a[1].lastUsedAt - b[1].lastUsedAt)[0]?.[0]
      if (!oldest) break
      cache.delete(oldest)
    }
    p.catch(() => { if (cache.get(url)?.promise === p) cache.delete(url) })
  }
  return p
}

export function invalidateApiCache(prefix = '') {
  for (const key of cache.keys()) if (!prefix || key.startsWith(`/api/${prefix}`)) cache.delete(key)
}

export function clearApiCache() { cache.clear() }

export function apiCacheSize() { return cache.size }

export function fmtBytes(n) {
  if (n === null || n === undefined) return ''
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}

export function fmtNum(n) {
  if (n === null || n === undefined) return ''
  return Number(n).toLocaleString()
}

export function fmtTime(sec) {
  if (!sec) return ''
  const d = new Date(sec * 1000)
  return d.toLocaleString(undefined, { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' })
}

export function verdictColor(v) {
  if (v === 'FIXED') return 'success'
  if (v === 'NOT_FIXED') return 'error'
  return undefined
}

export function statusColor(s) {
  if (s === 'complete') return 'success'
  if (s === 'running') return 'info'
  if (s === 'timed_out' || (s || '').startsWith('exit_')) return 'error'
  if (s === 'stranded') return 'warning'
  return undefined
}

// Maps a semantic color name (from the helpers above) to a .tag tone class; neutral when unknown.
export function toneClass(c) {
  return c ? `tone-${c}` : 'outline'
}
