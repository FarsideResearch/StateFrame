export function normalizeFileRoot(root) {
  return root === ['frame', 'lab'].join('_') ? 'experiments' : root
}

export function normalizeFileLocation(to) {
  if (to.name !== 'file') return true
  const root = Array.isArray(to.query.root) ? to.query.root[0] : to.query.root
  const normalized = normalizeFileRoot(root)
  if (root === normalized) return true
  return { name: 'file', query: { ...to.query, root: normalized }, hash: to.hash, replace: true }
}
