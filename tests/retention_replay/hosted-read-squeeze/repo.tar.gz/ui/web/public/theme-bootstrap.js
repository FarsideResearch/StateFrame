// Apply the saved/effective theme before the module graph and Vuetify can paint.
// Keep this external so the server's strict script-src policy stays intact.
(function bootstrapTheme() {
  var preference = 'system'
  try {
    var stored = window.localStorage.getItem('fl-theme')
    if (stored === 'light' || stored === 'dark' || stored === 'system') preference = stored
  } catch {
    // Storage can be unavailable in private browsing; system preference remains safe.
  }
  var active = preference
  if (active === 'system') {
    try {
      active = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    } catch {
      active = 'light'
    }
  }
  document.documentElement.dataset.theme = active
  document.documentElement.dataset.themePreference = preference
})()
