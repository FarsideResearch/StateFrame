import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vuetify from 'vite-plugin-vuetify'
import { buildFingerprint } from './scripts/build-fingerprint.mjs'

function releaseManifest() {
  return {
    name: 'framelab-release-manifest',
    generateBundle() {
      this.emitFile({
        type: 'asset',
        fileName: 'framelab-build.json',
        source: JSON.stringify({
          schema: 'framelab.build.v1',
          fingerprint: buildFingerprint(),
          node: process.version,
          generated_at: new Date().toISOString(),
        }, null, 2) + '\n',
      })
    },
  }
}

export default defineConfig({
  plugins: [vue(), vuetify({ autoImport: true }), releaseManifest()],
  server: { host: '127.0.0.1', port: 5175, proxy: { '/api': 'http://127.0.0.1:8765' } },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    chunkSizeWarningLimit: 2000,
    rollupOptions: {
      output: {
        // Vue's runtime gets its own chunk, so its file (and digest) changes only when the Vue version does.
        manualChunks(id) {
          if (/[\\/]node_modules[\\/](vue|@vue)[\\/]/.test(id)) return 'vendor-vue'
          return undefined
        },
      },
    },
  },
})
