# Grades

Put grade files here, one JSON file per graded task or run.

- `<name>.graded.json` carries a verdict: `FIXED` or `NOT_FIXED`.
- `<name>.json` without the `.graded` suffix is a proof: per-case results, no verdict.
- `run_ids` (or `candidate_sha256`) ties a grade to specific runs; without it the grade applies to the task only.
