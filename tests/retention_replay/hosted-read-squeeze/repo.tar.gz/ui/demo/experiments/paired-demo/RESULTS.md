# Paired StateFrame demo

This small, sanitized comparison uses the same task and seed in both arms.
The rows are evidence for an exploratory product comparison, not a universal
claim about model quality.

| Arm | Cases | Task success | Input tokens | Latency |
| --- | ---: | ---: | ---: | ---: |
| Baseline | 4 | 50% | 92 | 151 ms |
| Bounded StateFrame | 4 | 50% | 66 | 104 ms |
