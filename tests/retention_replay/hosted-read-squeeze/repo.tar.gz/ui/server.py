"""Frame Lab UI: local, read-only HTTP API + static web app (stdlib only).

Binds 127.0.0.1 only and answers GET and HEAD; every other method is refused.

    python3 -B ui/server.py [--port 8786] [--data-root PATH | --config sources.json | --demo]
"""
from __future__ import annotations

import argparse
import json
import logging
import mimetypes
import os
import secrets
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from fl_index import docs, experiments, frames, journal, runs, grades, evidence  # noqa: E402
from fl_index.paths import PathRejected, assert_artifact_name, configure, resolve, roots, source_config, source_diagnostics, source_generation  # noqa: E402
from fl_index.redact import redact, redact_text  # noqa: E402
from fl_index.util import TTLCache, open_regular, parse_md_tables, read_text  # noqa: E402

DIST = os.path.join(HERE, "web", "dist")
log = logging.getLogger("framelab_ui")
Handler = Callable[[dict[str, str]], Any]
ROUTES: dict[str, Handler] = {}


def _artifact_weight(value: Any) -> int:
    return int(value.get("_cache_bytes", 1)) if isinstance(value, dict) else 1


_artifact_cache = TTLCache(
    60,
    max_entries=16,
    byte_cap=int(os.environ.get("FRAME_LAB_ARTIFACT_CACHE_BYTES", str(128 * 1024 * 1024))),
    weight_fn=_artifact_weight,
)
_analysis_cache = TTLCache(60, max_entries=128, byte_cap=32 * 1024 * 1024)
MAX_HTTP_RESPONSE_BYTES = int(os.environ.get("FRAME_LAB_MAX_RESPONSE_BYTES", str(32 * 1024 * 1024)))


def route(path: str):
    def deco(fn: Handler) -> Handler:
        ROUTES[path] = fn
        return fn
    return deco


def _int(q: dict[str, str], k: str, default: int, lo: int = 0, hi: int = 10**9) -> int:
    try:
        return max(lo, min(hi, int(q.get(k, default))))
    except (TypeError, ValueError):
        return default


def _req(q: dict[str, str], k: str) -> str:
    v = q.get(k)
    if not v:
        raise ValueError(f"missing parameter: {k}")
    return v


# ------------------------------------------------------------------ overview
@route("/api/health")
def _health(q):
    source = source_diagnostics()
    return {
        "ok": True,
        "ready": source["ready"],
        "roots": sorted(roots().keys()),
        "source": source,
        "budgets": {
            "max_response_bytes": MAX_HTTP_RESPONSE_BYTES,
            "artifact_cache": _artifact_cache.stats(),
            "analysis_cache": _analysis_cache.stats(),
            "journal_cache": journal.cache_stats(),
        },
    }


@route("/api/overview")
def _overview(q):
    rl = runs.list_runs()
    by_status: dict[str, int] = {}
    for r in rl:
        by_status[r.get("status") or "unknown"] = by_status.get(r.get("status") or "unknown", 0) + 1
    task_counts = grades.task_counts()
    return {
        "source": source_diagnostics(),
        "counts": {
            "runs": len(rl),
            "runs_by_status": by_status,
            "experiments": len(experiments.list_experiments()),
            "proofs": task_counts["proof_files"],
            "proofs_fixed": task_counts["fixed"],
            "proofs_not_fixed": task_counts["not_fixed"],
            "proof_files": task_counts["proof_files"],
            "graded_tasks": task_counts["graded_tasks"],
        },
        "recent_runs": rl[:12],
        "product_story": evidence.build_landing_story(rl),
    }


# ---------------------------------------------------------------------- runs
@route("/api/runs")
def _runs(q):
    return {"runs": runs.list_runs()}


@route("/api/run")
def _run(q):
    rid = _req(q, "id")
    d = resolve("capability", rid)
    if not os.path.isdir(d):
        raise FileNotFoundError(rid)
    path = q.get("path", "")
    meta = runs.run_meta(rid)
    return {"meta": meta, "evidence": evidence.build_run_story(rid, meta), "files": runs.run_files(rid, path), "path": path, "journals": journal.list_journals(d)}


@route("/api/run/evidence")
def _run_evidence(q):
    rid = _req(q, "id")
    resolve("capability", rid)
    return evidence.build_run_story(rid, runs.run_meta(rid))


@route("/api/run/files")
def _run_files(q):
    rid = _req(q, "id")
    resolve("capability", rid)
    return {"id": rid, "path": q.get("path", ""), "files": runs.run_files(rid, q.get("path", ""))}


@route("/api/run/file")
def _run_file(q):
    rid, name = _req(q, "id"), _req(q, "name")
    d = resolve("capability", rid)
    from fl_index.layout import child_path, layout
    p = child_path(layout(d), name)
    if not os.path.isfile(p):
        raise FileNotFoundError(name)
    assert_artifact_name(name)
    return _file_payload(p, q)


@route("/api/run/tgz")
def _run_tgz(q):
    d = resolve("capability", _req(q, "id"))
    members = journal.list_tgz_members(d)
    flt = q.get("q", "").lower()
    if flt:
        members = [m for m in members if flt in m["name"].lower()]
    off, lim = _int(q, "offset", 0), _int(q, "limit", 500, 1, 5000)
    page = members[off: off + lim]
    return {"total": len(members), "offset": off, "limit": lim, "members": page,
            "has_more": off + len(page) < len(members),
            "next_offset": off + len(page) if off + len(page) < len(members) else None}


@route("/api/run/tgz/member")
def _run_tgz_member(q):
    d = resolve("capability", _req(q, "id"))
    member = _req(q, "member")
    from fl_index.layout import layout
    archive = layout(d).archive
    if archive is None:
        raise FileNotFoundError("worker.tgz")
    data = journal.read_tar_member(archive, member, max_bytes=16 * 1024 * 1024)
    text = data.decode("utf-8", "replace")
    return _text_payload(member, text, q)


# ------------------------------------------------------------------ journals
def _journal(q):
    d = resolve("capability", _req(q, "id"))
    return journal.load_journal(d, _req(q, "j"))


@route("/api/journal")
def _journal_rows(q):
    j = _journal(q)
    rows = j.rows
    kinds = set(filter(None, q.get("kinds", "").split(",")))
    cats = set(filter(None, q.get("cats", "").split(",")))
    if kinds:
        rows = [r for r in rows if r["kind"] in kinds]
    if cats:
        rows = [r for r in rows if r["cat"] in cats]
    text = q.get("q", "").strip()
    if text:
        tl = redact_text(text).lower()
        rows = [r for r in rows if tl in redact_text(j.lines[r["i"]]).lower()]
    matched = len(rows)
    offset = _int(q, "offset", 0)
    limit = _int(q, "limit", 500, 1, 2000)
    page = rows[offset: offset + limit]
    total_tokens = {"prompt": 0, "completion": 0}
    categories: dict[str, int] = {}
    for r in j.rows:
        categories[r["cat"]] = categories.get(r["cat"], 0) + 1
        t = r.get("tokens") if isinstance(r.get("tokens"), dict) else {}
        total_tokens["prompt"] += t.get("prompt", 0) if isinstance(t.get("prompt", 0), (int, float)) else 0
        total_tokens["completion"] += t.get("completion", 0) if isinstance(t.get("completion", 0), (int, float)) else 0
    return {
        "total": len(j.rows),
        "matched": matched,
        "offset": offset,
        "limit": limit,
        "has_more": offset + len(page) < matched,
        "next_offset": offset + len(page) if offset + len(page) < matched else None,
        "bad_lines": j.bad_lines,
        "kinds": j.kinds,
        "categories": categories,
        "tokens": total_tokens,
        "rows": page,
    }


@route("/api/journal/event")
def _journal_event(q):
    j = _journal(q)
    raw_index = q.get("i")
    try:
        index = int(raw_index) if raw_index is not None else -1
    except (TypeError, ValueError):
        raise ValueError("event index must be an integer") from None
    if index < 0 or index >= len(j.lines):
        raise IndexError(index)
    return {"i": index, "event": j.event(index), "attempt_id": j.rows[index].get("attempt_id")}


@route("/api/frames")
def _frames(q):
    return {"frames": frames.list_frames(_journal(q))}


@route("/api/frame")
def _frame(q):
    return frames.get_frame(_journal(q), _req(q, "rid"))


@route("/api/frames/search")
def _frames_search(q):
    j = _journal(q)
    needle = redact_text(_req(q, "q")).lower()
    scope = q.get("scope", "all")
    if scope not in {"all", "request", "response", "audit"}:
        raise ValueError("invalid frame search scope")
    out = []
    for fr in frames.list_frames(j):
        try:
            detail = frames.get_frame(j, fr["attempt_id"])
        except (KeyError, ValueError):
            continue
        sections = {
            "request": detail.get("request_payload"),
            "response": detail.get("response"),
            "audit": {k: v for k, v in detail.items() if k not in {"request_payload", "response", "messages", "tools"}},
        }
        selected = sections.values() if scope == "all" else (sections[scope],)
        text = redact_text(json.dumps(list(selected), default=str, separators=(",", ":"))).lower()
        c = text.count(needle)
        if c:
            matched_scopes = [name for name, value in sections.items()
                              if needle in redact_text(json.dumps(value, default=str, separators=(",", ":"))).lower()]
            out.append({"request_id": fr["request_id"], "attempt_id": fr["attempt_id"], "n": fr["n"],
                        "hits": c, "scopes": matched_scopes})
    return {"scope": scope, "total": len(out), "results": out}


# --------------------------------------------------------------- experiments
@route("/api/experiments")
def _experiments(q):
    return {"experiments": experiments.list_experiments()}


@route("/api/experiment")
def _experiment(q):
    return experiments.experiment_detail(_req(q, "name"), _int(q, "offset", 0), _int(q, "limit", 200, 1, 500), q.get("q", ""))


ROOT_FILE_KEYS = ("experiments", "grades", "capability")


@route("/api/file")
def _file(q):
    root = _req(q, "root")
    if root == "frame" + "_lab":
        root = "experiments"
    if root not in ROOT_FILE_KEYS and not root.startswith("proof:"):
        raise PathRejected("root not browsable")
    p = resolve(root, q.get("path", ""))
    if os.path.isdir(p):
        all_entries = []
        for entry in sorted(os.scandir(p), key=lambda e: (not e.is_dir(follow_symlinks=False), e.name)):
            if entry.name.startswith("."):
                continue
            try:
                assert_artifact_name(entry.name)
            except PathRejected:
                continue
            if entry.is_dir(follow_symlinks=False):
                all_entries.append({"name": entry.name + "/", "size": None})
            elif entry.is_file(follow_symlinks=False):
                all_entries.append({"name": entry.name, "size": entry.stat(follow_symlinks=False).st_size})
        offset, limit = _int(q, "offset", 0), _int(q, "limit", 200, 1, 500)
        entries = all_entries[offset: offset + limit]
        return {"kind": "dir", "entries": entries, "offset": offset, "limit": limit,
                "total": len(all_entries), "has_more": offset + len(entries) < len(all_entries),
                "next_offset": offset + len(entries) if offset + len(entries) < len(all_entries) else None}
    if not os.path.isfile(p):
        raise FileNotFoundError(q.get("path"))
    assert_artifact_name(p)
    manifest = None
    if root == "experiments":
        relative_parts = [part for part in (q.get("path", "") or "").replace("\\", "/").split("/") if part]
        if relative_parts:
            try:
                manifest = experiments._read_manifest(resolve("experiments", relative_parts[0]))
            except (FileNotFoundError, PathRejected, ValueError):
                manifest = None
    return _file_payload(p, q, manifest)


def _json_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "unknown"


def _record_row(index: int, value: Any) -> dict[str, Any]:
    valid = isinstance(value, dict) and value.get("schema_status") not in {"invalid_json", "invalid_record"}
    return {
        "idx": index,
        "record": value,
        "valid": valid,
        "schema_status": "ok" if valid else "invalid_record",
        "run_links": experiments.find_run_links(value) if valid else [],
    }


def _file_signature(path: str) -> tuple[str, int, int, int]:
    st = os.stat(path)
    return path, st.st_mtime_ns, st.st_size, st.st_ino


def _load_projected_json(path: str) -> dict[str, Any]:
    size = os.path.getsize(path)
    with open_regular(path, "r", encoding="utf-8", errors="replace") as fh:
        value = redact(json.load(fh))
    return {"data": value, "_cache_bytes": max(1, size)}


def _load_projected_jsonl(path: str) -> dict[str, Any]:
    size = os.path.getsize(path)
    records: list[Any] = []
    bad_lines = 0
    with open_regular(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            try:
                records.append(redact(json.loads(line)))
            except json.JSONDecodeError:
                bad_lines += 1
                records.append({"unparseable": line[:2000], "schema_status": "invalid_json"})
    return {"records": records, "bad_lines": bad_lines, "_cache_bytes": max(1, size)}


def _analysis_for(records: list[Any], manifest: dict[str, Any] | None, cache_key: Any) -> Any:
    if cache_key is None:
        return experiments.analyze_records(records, manifest)
    manifest_key = json.dumps(manifest or {}, sort_keys=True, default=str, separators=(",", ":"))
    key = ("analysis", cache_key, manifest_key)
    return _analysis_cache.get_or(key, lambda: experiments.analyze_records(records, manifest))


def _json_payload(
    name: str,
    data: Any,
    q: dict[str, str],
    size: int,
    manifest: dict[str, Any] | None = None,
    *,
    projected: bool = False,
    cache_key: Any = None,
) -> dict[str, Any]:
    pointer = q.get("pointer", "")
    projection = data if projected else redact(data)
    sub = experiments.get_pointer(projection, pointer) if pointer else projection
    arrays = experiments.find_record_arrays(sub)
    analysis = None
    recs_ptr = q.get("records")
    if recs_ptr is None and arrays:
        recs_ptr = max(arrays, key=lambda a: a["length"])["pointer"]
    records_page = None
    items_page = None
    if recs_ptr is not None:
        try:
            recs = experiments.get_pointer(sub, recs_ptr)
        except (KeyError, IndexError, ValueError):
            recs = None
        if isinstance(recs, list):
            analysis = _analysis_for(recs, manifest, (cache_key, pointer, recs_ptr))
            off, lim = _int(q, "offset", 0), _int(q, "limit", 200, 1, 2000)
            page = recs[off: off + lim]
            records_page = {"pointer": recs_ptr, "offset": off, "total": len(recs),
                            "rows": [_record_row(off + k, redact(r)) for k, r in enumerate(page)],
                            "analysis_scope": "dataset"}
        else:
            recs_ptr = None
    if recs_ptr is None and isinstance(sub, list):
        off, lim = _int(q, "offset", 0), _int(q, "limit", 200, 1, 2000)
        page = sub[off: off + lim]
        items_page = {"pointer": pointer, "offset": off, "total": len(sub),
                      "rows": [{"idx": off + k, "value": redact(v)} for k, v in enumerate(page)]}
    enc = json.dumps(sub, allow_nan=False)
    inline = len(enc) <= experiments.INLINE_JSON_BYTES
    top = None
    if not inline and isinstance(sub, dict):
        top = {k: (_json_type(v), len(v) if isinstance(v, (list, dict, str)) else v) for k, v in sub.items()}
    value_type = _json_type(sub)
    chunk = None
    if value_type == "string" and not inline:
        chunk_offset, chunk_limit = _int(q, "chunk_offset", 0), _int(q, "chunk_limit", 4000, 1, 16000)
        chunk = {"offset": chunk_offset, "limit": chunk_limit, "total": len(sub), "text": sub[chunk_offset: chunk_offset + chunk_limit], "truncated": chunk_offset + chunk_limit < len(sub)}
    return {"kind": "json", "name": name, "size": size, "pointer": pointer, "arrays": arrays, "analysis": analysis,
            "records": records_page, "items": items_page, "data": sub if inline else None, "has_value": True,
            "value_type": value_type, "value_size": len(sub) if isinstance(sub, (list, dict, str)) else None,
            "chunk": chunk, "top": top, "inline": inline, "schema_status": "ok"}


def _jsonl_payload(
    name: str,
    cached: dict[str, Any],
    q: dict[str, str],
    size: int,
    manifest: dict[str, Any] | None = None,
    cache_key: Any = None,
) -> dict[str, Any]:
    all_records = cached["records"]
    off, lim = _int(q, "offset", 0), _int(q, "limit", 200, 1, 2000)
    recs = all_records[off: off + lim]
    return {"kind": "jsonl", "name": name, "size": size, "total": len(all_records), "offset": off,
            "rows": [_record_row(off + k, r) for k, r in enumerate(recs)],
            "bad_lines": cached["bad_lines"], "analysis_scope": "dataset",
            "analysis": _analysis_for(all_records, manifest, (cache_key, "jsonl"))}


def _text_payload(name: str, text: str, q: dict[str, str], size: int | None = None, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    size = size if size is not None else len(text)
    if name.endswith(".json"):
        try:
            return _json_payload(name, json.loads(text), q, size, manifest)
        except json.JSONDecodeError:
            raise ValueError("invalid JSON artifact") from None
    if name.endswith(".jsonl"):
        lines = text.splitlines()
        all_records = []
        bad_lines = 0
        for ln in lines:
            try:
                all_records.append(redact(json.loads(ln)))
            except json.JSONDecodeError:
                bad_lines += 1
                all_records.append({"unparseable": ln[:2000], "schema_status": "invalid_json"})
        return _jsonl_payload(name, {"records": all_records, "bad_lines": bad_lines}, q, size, manifest)
    out = {"kind": "markdown" if name.endswith(".md") else "text", "name": name, "size": size, "text": text}
    if name.endswith(".md"):
        out["tables"] = parse_md_tables(text)
    return out


def _file_payload(p: str, q: dict[str, str], manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    size = os.path.getsize(p)
    name = os.path.basename(p)
    if name.endswith(".json"):
        if size > experiments.MAX_JSON_BYTES:
            raise ValueError(f"JSON too large to parse ({size} bytes)")
        key = ("json", source_generation(), _file_signature(p))
        cached = _artifact_cache.get_or(key, lambda: _load_projected_json(p))
        return _json_payload(name, cached["data"], q, size, manifest, projected=True, cache_key=key)
    if name.endswith(".jsonl"):
        if size > 128 * 1024 * 1024:
            raise ValueError("JSONL too large")
        key = ("jsonl", source_generation(), _file_signature(p))
        cached = _artifact_cache.get_or(key, lambda: _load_projected_jsonl(p))
        return _jsonl_payload(name, cached, q, size, manifest, key)
    tail = q.get("tail") == "1" or name.endswith((".out", ".log"))
    text, trunc = read_text(p, 2 * 1024 * 1024, tail=tail)
    out = _text_payload(name, text, q, size, manifest)
    out["truncated"] = trunc
    return out


# -------------------------------------------------------------------- grades
@route("/api/grades")
def _grades(q):
    return {"proofs": grades.proofs(), "docs": docs.grades_docs()}


# -------------------------------------------------------------------- server
class FrameLabHandler(BaseHTTPRequestHandler):
    server_version = "FrameLab/1.0"

    def log_message(self, fmt, *args):  # quiet, no query strings in logs
        log.debug("%s %s", self.command, self.path.split("?")[0])

    def _send(self, code: int, body: bytes, ctype: str, cache: str = "no-store", request_id: str | None = None, etag: str | None = None, extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-FrameLab-Projection", "redacted")
        self.send_header("Content-Security-Policy", "default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'none'; img-src 'self' data:; font-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        if request_id:
            self.send_header("X-FrameLab-Request-ID", request_id)
        if etag:
            self.send_header("ETag", etag)
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code: int, obj: Any, request_id: str | None = None, etag: str | None = None, extra_headers: dict[str, str] | None = None) -> None:
        body = json.dumps(redact(obj), default=str, allow_nan=False, separators=(",", ":")).encode()
        if len(body) > MAX_HTTP_RESPONSE_BYTES and code < 400:
            return self._error(413, "RESPONSE_LIMIT", "The response exceeds Frame Lab's configured payload limit.", request_id or secrets.token_hex(8))
        self._send(code, body, "application/json; charset=utf-8", request_id=request_id, etag=etag, extra_headers=extra_headers)

    def _error(self, code: int, error_code: str, message: str, request_id: str, details: dict[str, object] | None = None) -> None:
        payload: dict[str, object] = {"error": message, "code": error_code, "request_id": request_id}
        if details:
            payload["details"] = details
        self._json(code, payload, request_id)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        request_id = secrets.token_hex(8)
        url = urlparse(self.path)
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost", ""):
            return self._error(403, "HOST_NOT_ALLOWED", "Host is not allowed.", request_id)  # DNS-rebinding guard
        if url.path.startswith("/api/"):
            fn = ROUTES.get(url.path)
            if fn is None:
                return self._error(404, "ENDPOINT_NOT_FOUND", "Endpoint was not found.", request_id)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            t0 = time.time()
            try:
                return self._json(200, fn(q), request_id)
            except PathRejected:
                return self._error(403, "PATH_REJECTED", "The requested artifact is outside the allowed read policy.", request_id)
            except journal.ArchiveLimitError:
                return self._error(413, "RESOURCE_LIMIT", "The artifact exceeds Frame Lab's configured safety limit; choose a smaller item or adjust the documented limit.", request_id)
            except FileNotFoundError:
                return self._error(404, "ARTIFACT_NOT_FOUND", "The requested artifact was not found.", request_id)
            except (KeyError, IndexError, TypeError):
                return self._error(422, "ARTIFACT_INVALID", "The artifact could not be interpreted safely.", request_id)
            except ValueError:
                return self._error(400, "INVALID_REQUEST", "The request or artifact is invalid.", request_id)
            except Exception:  # noqa: BLE001 - keep internal details out of responses and logs
                log.error("handler error route=%s request_id=%s", url.path, request_id)
                return self._error(500, "INTERNAL_ERROR", "Frame Lab could not complete the request.", request_id)
            finally:
                log.debug("%s took %.2fs", url.path, time.time() - t0)
        return self._static(url.path)

    def _static(self, path: str) -> None:
        if not os.path.isdir(DIST):
            return self._send(503, b"web app not built: run ui/start.sh", "text/plain")
        rel = path.lstrip("/") or "index.html"
        if ".." in rel.split("/"):
            return self._send(403, b"forbidden", "text/plain")
        full = os.path.realpath(os.path.join(DIST, rel))
        if not full.startswith(os.path.realpath(DIST) + os.sep) or not os.path.isfile(full):
            # SPA fallback is for navigational URLs only. Returning index.html
            # for a missing module makes a broken release look like a healthy
            # page and produces opaque browser MIME errors.
            ext = os.path.splitext(rel)[1].lower()
            if rel.startswith("assets/") or ext in {".js", ".css", ".map", ".ico", ".png", ".jpg", ".jpeg", ".svg", ".woff", ".woff2"}:
                return self._send(404, b"asset not found", "text/plain; charset=utf-8")
            full = os.path.join(DIST, "index.html")  # SPA history fallback
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        with open_regular(full, "rb") as fh:
            body = fh.read()
        cache = "public, max-age=31536000, immutable" if "/assets/" in full else "no-store"
        self._send(200, body, ctype, cache)

    def _read_only(self) -> None:
        self._error(405, "READ_ONLY", "Frame Lab is read-only; only GET and HEAD are served.", secrets.token_hex(8))

    do_POST = do_PUT = do_DELETE = do_PATCH = _read_only


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--port", type=int, default=int(os.environ.get("FRAME_LAB_PORT", "8786")))
    source_group = ap.add_mutually_exclusive_group()
    source_group.add_argument("--config", default=os.environ.get("FRAME_LAB_CONFIG"), help="versioned source manifest JSON")
    source_group.add_argument("--data-root", default=os.environ.get("FRAME_LAB_DATA"), help="portable export directory")
    source_group.add_argument("--demo", action="store_true", default=os.environ.get("FRAME_LAB_DEMO", "").lower() in {"1", "true", "yes"}, help="use the sanitized bundled demo")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    if not a.config and not a.data_root and not a.demo:
        a.demo = True
    configure(config_path=a.config, data_root=a.data_root, demo=a.demo)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), FrameLabHandler)
    srv.daemon_threads = True
    print(f"Frame Lab UI: http://127.0.0.1:{a.port}/", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
