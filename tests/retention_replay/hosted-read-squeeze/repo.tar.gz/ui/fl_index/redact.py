"""Secret redaction for everything the API returns.

Two layers: (1) values under secret-looking keys are replaced wholesale;
(2) secret-looking substrings inside any string are masked. Patterns never
consume quote characters so they are also safe on raw text.
"""
from __future__ import annotations

import re
import math
import os
from typing import Any

MASK = "[REDACTED]"

_KEY_RE = re.compile(
    r"(?i)(^|[_\-.])(api[_\-]?key|apikey|secret|secret[_\-]?key|password|passwd|pwd|"
    r"token|access[_\-]?token|refresh[_\-]?token|auth[_\-]?token|bearer|private[_\-]?key|"
    r"access[_\-]?key[_\-]?id|secret[_\-]?access[_\-]?key|credentials?|cookie|authorization)$"
)

_VALUE_PATTERNS = [
    re.compile(r"(?<![A-Za-z0-9_\-])sk-(?:proj-|ant-)?[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}\b"),
    re.compile(r"\bglpat-[A-Za-z0-9_\-]{20,}\b"),
    re.compile(r"\bxox[abposr]-[A-Za-z0-9\-]{10,}\b"),
    re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----"),
]
# key=value / key: value forms inside free text (keeps the key, masks the value)
_INLINE_PREFIX = (
    r"(?:api[_\-]?key|secret|password|passwd|pwd|access[_\-]?token|auth[_\-]?token|"
    r"aws_secret_access_key|bearer|credentials?)"
)
_QUOTED_INLINE_RE = re.compile(
    rf"(?i)(\b{_INLINE_PREFIX}\s*[=:]\s*|Authorization:\s*Bearer\s+|Bearer\s+)([\"'])[^\"']*\2"
)
_SERIALIZED_INLINE_RE = re.compile(
    rf"(?i)([\"']?{_INLINE_PREFIX}[\"']?\s*[=:]\s*)([\"'])(?:\\.|(?!\2).)*\2"
)
_BARE_INLINE_RE = re.compile(
    rf"(?i)(\b{_INLINE_PREFIX}\s*[=:]\s*|Authorization:\s*Bearer\s+|Bearer\s+)([A-Za-z0-9_\-./+=]{{1,}})"
)
_SENSITIVE_CONTAINER_RE = re.compile(
    rf"(?i)(\b{_INLINE_PREFIX}\s*[=:]\s*)(\[[^\]]*\]|\{{[^}}]*\}})"
)
# credentials in URLs: scheme://user:pass@host
_URL_CRED_RE = re.compile(r"([a-z][a-z0-9+.\-]*://[^\s:/@\"']+:)([^\s@/\"']+)(@)", re.I)
_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b", re.I)
_LOCAL_PATH_RE = re.compile(r"(?<![A-Za-z0-9_])(?:/(?:Users|home)/|/private/tmp/|/var/folders/)[^\s\"']+")


def _configured_identifiers() -> tuple[str, ...]:
    raw = os.environ.get("FRAME_LAB_REDACT_IDENTIFIERS", "")
    return tuple(value for value in (part.strip() for part in raw.split(",")) if value)


def redact_text(s: str) -> str:
    if not s:
        return s
    for pat in _VALUE_PATTERNS:
        s = pat.sub(MASK, s)
    s = _SENSITIVE_CONTAINER_RE.sub(lambda m: m.group(1) + MASK, s)
    s = _SERIALIZED_INLINE_RE.sub(lambda m: m.group(1) + m.group(2) + MASK + m.group(2), s)
    s = _QUOTED_INLINE_RE.sub(lambda m: m.group(1) + MASK, s)
    s = _BARE_INLINE_RE.sub(lambda m: m.group(1) + MASK, s)
    s = _URL_CRED_RE.sub(lambda m: m.group(1) + MASK + m.group(3), s)
    s = _EMAIL_RE.sub(MASK, s)
    s = _LOCAL_PATH_RE.sub("[REDACTED_PATH]", s)
    for identifier in _configured_identifiers():
        s = s.replace(identifier, MASK)
    return s


def is_secret_key(key: str) -> bool:
    return bool(_KEY_RE.search(key or ""))


def redact(obj: Any) -> Any:
    """Return a redacted deep copy of a JSON-like structure."""
    if isinstance(obj, str):
        return redact_text(obj)
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if is_secret_key(str(k)) and v not in (None, "", [], {}):
                out[k] = MASK
            else:
                out[k] = redact(v)
        return out
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    return obj
