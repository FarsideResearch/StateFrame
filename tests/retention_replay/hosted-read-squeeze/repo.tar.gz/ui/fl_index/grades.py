"""Grades bug-replay proofs and grades from explicitly configured sources."""
from __future__ import annotations

import os
from typing import Any

from .paths import artifact_name_allowed, roots, safe_existing_path, source_generation
from .util import TTLCache, read_json

_cache = TTLCache(30)


def _scan() -> list[dict[str, Any]]:
    out = []
    configured = []
    grades_root = roots().get("grades")
    if grades_root:
        configured.append(("grades", grades_root.path))
        proof_dir = os.path.join(grades_root.path, "proof")
        if os.path.isdir(proof_dir):
            configured.append(("proof:grades", proof_dir))
    configured.extend((key, root.path) for key, root in roots().items() if key.startswith("proof:"))
    for key, directory in configured:
        for name in sorted(os.listdir(directory)):
            if not name.endswith(".json"):
                continue
            if not artifact_name_allowed(name):
                continue
            try:
                p = safe_existing_path(directory, name, expect="file")
            except (FileNotFoundError, ValueError):
                continue
            data = read_json(p) or {}
            if not isinstance(data, dict):
                continue
            cases = data.get("cases") if isinstance(data.get("cases"), dict) else {}
            run_values = data.get("run_ids") if isinstance(data.get("run_ids"), list) else [data.get("run_id"), data.get("source_run_id")]
            run_ids = sorted({value for value in run_values if isinstance(value, str) and value})
            candidate = data.get("candidate_sha256") or data.get("candidate_hash")
            raw_verdict = data.get("verdict")
            verdict = raw_verdict if raw_verdict in ("FIXED", "NOT_FIXED") else None
            out.append({
                "root": key,
                "source": key.split(":", 1)[1] if ":" in key else key,
                "path": name,
                "graded": name.endswith(".graded.json"),
                "task_id": data.get("task_id") or name.split(".")[0],
                "verdict": verdict,
                "candidate_sha256": data.get("candidate_sha256"),
                "candidate_identity": candidate,
                "run_ids": run_ids,
                "grade_scope": "run" if run_ids or candidate else "task",
                "cases": {k: (v or {}).get("status") for k, v in cases.items() if isinstance(v, dict)},
                "mtime": os.path.getmtime(p),
                "size": os.path.getsize(p),
            })
    out.sort(key=lambda r: -r["mtime"])
    return out


def proofs() -> list[dict[str, Any]]:
    return _cache.get_or(("proofs", source_generation()), _scan)


def latest_verdicts() -> dict[str, dict[str, Any]]:
    """Most recent graded verdict per task_id (task-level, never a run verdict)."""
    best: dict[str, dict[str, Any]] = {}
    for p in proofs():
        if p["graded"] and p["verdict"] and p["task_id"] not in best:
            best[p["task_id"]] = p
    return best


def verdict_for_run(run_id: str, candidate_identity: str | None = None) -> dict[str, Any] | None:
    """Return a grade only when the proof declares a run/candidate identity."""
    for proof in proofs():
        if not proof["graded"] or not proof["verdict"]:
            continue
        if run_id in proof.get("run_ids", []) or (
            candidate_identity and candidate_identity == proof.get("candidate_identity")
        ):
            return proof
    return None


def task_counts() -> dict[str, int]:
    """Count unique graded tasks, not historical proof files."""
    latest = latest_verdicts()
    return {
        "fixed": sum(1 for proof in latest.values() if proof["verdict"] == "FIXED"),
        "not_fixed": sum(1 for proof in latest.values() if proof["verdict"] == "NOT_FIXED"),
        "graded_tasks": len(latest),
        "proof_files": len(proofs()),
    }
