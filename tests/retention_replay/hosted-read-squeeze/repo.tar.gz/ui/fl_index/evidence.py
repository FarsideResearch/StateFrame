"""Product-level evidence projections for the Frame Lab release story.

The projection is deliberately separate from the raw journal/frame adapters.
It gives the UI a small, provenance-carrying answer to four questions without
turning process completion, a requested tool call, or missing cost data into
task-success claims.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from . import frames, journal, grades
from .layout import layout, metadata_path
from .paths import resolve
from .util import read_json

SCHEMA = "stateframe.product_evidence.v1"
_ACTION_RE = re.compile(r"action|tool.*(complete|execut|receipt)|receipt|observation_committed", re.I)
_VERIFY_RE = re.compile(r"verify|proof|certif|test|obligation|check", re.I)
_STOP_RE = re.compile(r"completion_authority|attempt_terminated|run_(complete|completed|stopped)|terminal|final", re.I)


def _source_path(run_dir: str, path: str) -> str:
    return os.path.relpath(path, run_dir).replace(os.sep, "/")


def _sidecar(run_dir: str, run_layout: Any, name: str) -> tuple[Any, str | None]:
    try:
        path = metadata_path(run_layout, name)
    except (FileNotFoundError, OSError, ValueError):
        return None, None
    if not os.path.isfile(path):
        return None, None
    value = read_json(path, 8 * 1024 * 1024)
    return value, _source_path(run_dir, path)


def _ref(run_id: str, jref: str, index: int, tab: str = "timeline", rid: str | None = None) -> dict[str, Any]:
    query: dict[str, str] = {"id": run_id, "tab": tab, "j": jref}
    if tab == "timeline":
        query["i"] = str(index)
    if rid:
        query["rid"] = rid
    return {"route": "run", "query": query, "label": f"Open event {index}"}


def _file_ref(run_id: str, path: str) -> dict[str, Any]:
    return {
        "route": "run",
        "query": {"id": run_id, "tab": "files", "file": path},
        "label": f"Open {path}",
    }


def _value_number(value: Any) -> int | float | None:
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _first_number(values: list[Any]) -> int | float | None:
    for value in values:
        number = _value_number(value)
        if number is not None:
            return number
    return None


def _flatten_diff(left: Any, right: Any, path: str = "", out: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    out = [] if out is None else out
    if len(out) >= 40:
        return out
    if isinstance(left, dict) and isinstance(right, dict):
        for key in sorted(set(left) | set(right)):
            child = f"{path}.{key}" if path else str(key)
            if key not in left or key not in right:
                out.append({"path": child, "requested": left.get(key), "effective": right.get(key)})
            else:
                _flatten_diff(left[key], right[key], child, out)
        return out
    if left != right:
        out.append({"path": path or "$", "requested": left, "effective": right})
    return out


def _config_projection(run_id: str, run_dir: str, run_layout: Any) -> dict[str, Any]:
    requested, requested_path = _sidecar(run_dir, run_layout, "requested-config.json")
    effective, effective_path = _sidecar(run_dir, run_layout, "effective-config.json")
    wire, wire_path = _sidecar(run_dir, run_layout, "provider-wire.json")
    requested = requested if isinstance(requested, dict) else None
    effective = effective if isinstance(effective, dict) else None
    diffs = _flatten_diff(requested, effective) if requested is not None and effective is not None else []
    files = {
        "requested": _file_ref(run_id, requested_path) if requested_path else None,
        "effective": _file_ref(run_id, effective_path) if effective_path else None,
        "provider_wire": _file_ref(run_id, wire_path) if wire_path else None,
    }
    available = [name for name, value in (("requested", requested), ("effective", effective), ("provider_wire", wire)) if value is not None]
    return {
        "status": "available" if requested is not None and effective is not None else "partial" if available else "missing",
        "projection": "redacted",
        "requested": requested,
        "effective": effective,
        "provider_wire_available": wire is not None,
        "differences": diffs,
        "files": files,
        "available": available,
        "note": "Effective settings are evidence only; requested flags do not prove a mechanism operated.",
    }


def _event_chain(run_id: str, jref: str, parsed: Any, frame: dict[str, Any] | None) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any] | None]:
    actions: list[dict[str, Any]] = []
    verification: list[dict[str, Any]] = []
    stop: dict[str, Any] | None = None
    request_id = frame.get("request_id") if frame else None
    response_tools: list[dict[str, Any]] = []
    if frame and isinstance(frame.get("response"), dict):
        message = frame["response"].get("message")
        if isinstance(message, dict) and isinstance(message.get("tool_calls"), list):
            response_tools = [tool for tool in message["tool_calls"] if isinstance(tool, dict)]
    for index, row in enumerate(parsed.rows):
        kind = str(row.get("kind") or "")
        if request_id and row.get("request_id") not in (None, request_id):
            continue
        try:
            event = parsed.event(index)
        except (IndexError, KeyError):
            continue
        if _ACTION_RE.search(kind):
            receipt_status = event.get("status") or event.get("outcome") or event.get("result")
            actions.append({
                "kind": kind,
                "status": receipt_status if isinstance(receipt_status, (str, int, float, bool)) else "recorded",
                "name": event.get("action") or event.get("tool") or event.get("name"),
                "receipt_id": event.get("receipt_id") or event.get("action_id"),
                "evidence": _ref(run_id, jref, index),
            })
        if _VERIFY_RE.search(kind) and not _STOP_RE.search(kind):
            status = event.get("status") or event.get("outcome") or event.get("verdict") or event.get("exit_code")
            verification.append({
                "kind": kind,
                "status": status if isinstance(status, (str, int, float, bool)) else "recorded",
                "evidence": _ref(run_id, jref, index),
            })
        if (kind in {"completion_authority", "attempt_terminated"} or _STOP_RE.search(kind)) and kind not in {"run_started", "terminal_started"}:
            result = event.get("result") if isinstance(event.get("result"), dict) else {}
            completion = result.get("completion") if isinstance(result.get("completion"), dict) else {}
            disposition = event.get("disposition") or event.get("stop_reason") or event.get("outcome") or result.get("outcome") or completion.get("outcome") or event.get("status")
            explicit_success = event.get("task_success")
            if not isinstance(explicit_success, bool):
                explicit_success = True if str(disposition).lower() in {"verified", "verified_success", "pass", "passed", "success"} else False if str(disposition).lower() in {"fail", "failed", "not_fixed", "budget_exhausted", "provider_error", "verification_failed"} else None
            candidate_stop = {
                "disposition": disposition or "recorded",
                "authority": event.get("authority") or "engine",
                "reason": event.get("reason") or event.get("failure_reason") or event.get("stop_reason"),
                "task_success": explicit_success,
                "evidence": _ref(run_id, jref, index),
            }
            if stop is None or event.get("authority") or kind == "completion_authority":
                stop = candidate_stop
    for tool in response_tools:
        function = tool.get("function") if isinstance(tool.get("function"), dict) else tool
        name = function.get("name") if isinstance(function, dict) else None
        actions.insert(0, {
            "kind": "requested_tool_call",
            "status": "requested",
            "name": name or "unnamed tool",
            "arguments": function.get("arguments") if isinstance(function, dict) else None,
            "evidence": _ref(run_id, jref, frame.get("event_index", 0), "frames", frame.get("attempt_id")),
        })
    return actions[:12], verification[:12], stop


def _usage_projection(run_id: str, run_dir: str, run_layout: Any, meta: dict[str, Any], parsed: Any | None, frame_count: int) -> dict[str, Any]:
    timings, timings_path = _sidecar(run_dir, run_layout, "timings.json")
    timings_summary = timings.get("summary") if isinstance(timings, dict) and isinstance(timings.get("summary"), dict) else {}
    usage_sidecar, usage_path = _sidecar(run_dir, run_layout, "usage.json")
    usage_sidecar = usage_sidecar if isinstance(usage_sidecar, dict) else {}
    responses = [row for row in (parsed.rows if parsed is not None else []) if row.get("kind") == "response_received"]
    def token_sum(key: str) -> int | None:
        values = [(row.get("tokens") or {}).get(key) for row in responses if isinstance(row.get("tokens"), dict) and isinstance((row.get("tokens") or {}).get(key), (int, float))]
        return sum(values) if values else None
    prompt = _first_number([usage_sidecar.get("input_tokens"), timings_summary.get("prompt_n_total"), token_sum("prompt")])
    output = _first_number([usage_sidecar.get("output_tokens"), timings_summary.get("completion_n_total"), token_sum("completion")])
    cached = _first_number([usage_sidecar.get("cached_tokens"), timings_summary.get("cached_n_total")])
    reasoning = _first_number([usage_sidecar.get("reasoning_tokens"), timings_summary.get("reasoning_n_total")])
    cost = _first_number([usage_sidecar.get("cost_usd"), usage_sidecar.get("total_cost_usd"), timings_summary.get("cost_usd")])
    cost_basis = usage_sidecar.get("cost_basis") or timings_summary.get("cost_basis")
    prompt_source = usage_path or timings_path or ("journal:response_received" if responses else None)
    return {
        "input_tokens": prompt,
        "output_tokens": output,
        "cached_tokens": cached,
        "reasoning_tokens": reasoning,
        "cost_usd": cost,
        "cost_basis": cost_basis if cost is not None else None,
        "wall_time_s": meta.get("elapsed_s"),
        "provider_time_s": meta.get("provider_request_s"),
        "requests": frame_count if frame_count else None,
        "retries": max(0, frame_count - len({row.get("request_id") for row in (parsed.rows if parsed is not None else []) if row.get("kind") == "request_submitted"})),
        "provenance": {
            "tokens": prompt_source,
            "wall_time": "live-receipt.json:elapsed_seconds" if meta.get("elapsed_s") is not None else None,
            "provider_time": "timings.json:summary.wall_s_in_requests" if meta.get("provider_request_s") is not None else None,
            "cost": usage_path or None,
        },
        "note": "Unavailable values are shown as unknown; no local-model dollar estimate is inferred.",
    }


def build_run_story(run_id: str, meta: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build the bounded, provenance-aware product story for one run."""
    run_dir = resolve("capability", run_id)
    run_layout = layout(run_dir)
    if meta is None:
        from .runs import run_meta
        meta = run_meta(run_id)
    journals = journal.list_journals(run_dir)
    parsed = None
    selected_ref = None
    selected_frame = None
    journal_errors: list[str] = []
    for ref in journals:
        try:
            candidate = journal.load_journal(run_dir, ref["ref"])
            rows = frames.list_frames(candidate)
            if rows:
                selected_ref = ref["ref"]
                parsed = candidate
                selected_frame = frames.get_frame(candidate, rows[0]["attempt_id"])
                break
            if parsed is None:
                selected_ref, parsed = ref["ref"], candidate
        except Exception:  # source diagnostics belong in the projection, not a 500 response
            journal_errors.append(ref.get("ref", "unknown"))
    actions: list[dict[str, Any]] = []
    verification: list[dict[str, Any]] = []
    stop = None
    if parsed is not None and selected_ref:
        actions, verification, stop = _event_chain(run_id, selected_ref, parsed, selected_frame)
    if stop is None:
        receipt = meta.get("status")
        stop = {
            "disposition": receipt or "unknown",
            "authority": "process" if receipt in {"complete", "timed_out"} or str(receipt).startswith("exit_") else "unknown",
            "reason": None,
            "task_success": None,
            "evidence": _file_ref(run_id, "run/live-receipt.json") if meta.get("layout") else None,
        }
    proofs = [p for p in grades.proofs() if run_id in (p.get("run_ids") or [])]
    for proof in proofs[:4]:
        verification.append({
            "kind": "graded_proof",
            "status": proof.get("verdict") or "unknown",
            "scope": proof.get("grade_scope"),
            "evidence": {"route": "file", "query": {"root": proof.get("root", "grades"), "path": proof.get("path", "")}, "label": f"Open {proof.get('path', 'proof')}"},
        })
    input_evidence = None
    if selected_frame and selected_ref:
        payload = selected_frame.get("request_payload") if isinstance(selected_frame.get("request_payload"), dict) else {}
        input_evidence = {
            "provider": selected_frame.get("backend_identity", {}).get("provider") if isinstance(selected_frame.get("backend_identity"), dict) else None,
            "model": payload.get("model") or (meta.get("effective_config") or {}).get("model"),
            "attempt_id": selected_frame.get("attempt_id"),
            "message_count": len(selected_frame.get("messages") or []),
            "tool_count": len(selected_frame.get("tools") or []),
            "context_hash": selected_frame.get("context_hash"),
            "evidence": _ref(run_id, selected_ref, selected_frame.get("event_index", 0), "frames", selected_frame.get("attempt_id")),
        }
    config = _config_projection(run_id, run_dir, run_layout)
    if input_evidence and isinstance(config.get("effective"), dict):
        input_evidence["provider"] = input_evidence.get("provider") or config["effective"].get("provider")
        input_evidence["model"] = input_evidence.get("model") or config["effective"].get("model")
    usage = _usage_projection(run_id, run_dir, run_layout, meta, parsed, len(frames.list_frames(parsed)) if parsed is not None else 0)
    warnings = []
    if journal_errors:
        warnings.append({"code": "JOURNAL_PARTIAL", "message": "Some journal sources could not be opened safely."})
    if not input_evidence:
        warnings.append({"code": "INPUT_UNAVAILABLE", "message": "No request frame is available in the configured journals."})
    if stop.get("authority") != "engine":
        warnings.append({"code": "PROCESS_NOT_TASK_PROOF", "message": "Process completion is not an authoritative task-success claim."})
    return {
        "schema": SCHEMA,
        "projection": "redacted",
        "run_id": run_id,
        "input": input_evidence,
        "action": {"status": "verified" if any(item.get("status") in {"success", "succeeded", "verified", 0} for item in actions) else "recorded" if actions else "unavailable", "items": actions},
        "verification": {"status": "verified" if any(item.get("status") in {"pass", "passed", "FIXED", "verified", 0} for item in verification) else "recorded" if verification else "unavailable", "items": verification},
        "stop": stop,
        "usage": usage,
        "config": config,
        "journal": {"selected": selected_ref, "count": len(journals), "errors": journal_errors},
        "warnings": warnings,
    }


def build_landing_story(recent_runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Select a success and a non-success example without hiding uncertainty."""
    featured = []
    for row in recent_runs[:6]:
        run_id = row.get("id")
        if not isinstance(run_id, str):
            continue
        try:
            story = build_run_story(run_id, row)
        except Exception:
            continue
        featured.append({
            "id": run_id,
            "status": row.get("status"),
            "result": row.get("result"),
            "disposition": story["stop"].get("disposition"),
            "task_success": story["stop"].get("task_success"),
            "evidence": {"route": "run", "query": {"id": run_id}, "label": "Inspect evidence"},
        })
    featured.sort(key=lambda item: (item.get("task_success") is not True, item["id"]))
    return {
        "title": "From task to evidence",
        "description": "Follow one run from model input to executed action, receipt, verification, and authoritative stop. Unknown and process-only outcomes stay explicit.",
        "steps": [
            {"label": "Input", "description": "What the model received", "tab": "frames"},
            {"label": "Action", "description": "What was requested and what produced a receipt", "tab": "timeline"},
            {"label": "Verification", "description": "What evidence checked the result", "tab": "timeline"},
            {"label": "Stop and usage", "description": "Why execution ended and what was recorded", "tab": "meta"},
        ],
        "featured_runs": featured[:4],
    }
