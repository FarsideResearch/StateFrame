"""Journal (events.jsonl) access: plain files and members streamed out of worker.tgz.

Nothing is ever extracted to disk: tar members are read through
``tarfile.open(mode="r|gz")`` and decoded line by line in memory.
"""
from __future__ import annotations

import json
import math
import os
import re
import tarfile
import threading
from contextlib import contextmanager
from collections import OrderedDict
from typing import Any, Callable

from .layout import child_path, layout
from .paths import PathRejected, assert_artifact_name, safe_existing_path, safe_member_name
from .schema import event_object, object_or_empty
from .util import open_regular

TGZ_PREFIX = "tgz:"
_JOURNAL_RE = re.compile(r"(^|/)(measurement-runs/[^/]+/events\.jsonl|results/react_events/[^/]+\.jsonl)$")
MAX_JOURNAL_BYTES = int(os.environ.get("FRAME_LAB_MAX_JOURNAL_BYTES", str(400 * 1024 * 1024)))
MAX_JOURNAL_LINES = int(os.environ.get("FRAME_LAB_MAX_JOURNAL_LINES", "2000000"))
MAX_ARCHIVE_COMPRESSED_BYTES = int(os.environ.get("FRAME_LAB_MAX_ARCHIVE_COMPRESSED_BYTES", str(256 * 1024 * 1024)))
MAX_ARCHIVE_MEMBER_BYTES = int(os.environ.get("FRAME_LAB_MAX_ARCHIVE_MEMBER_BYTES", str(64 * 1024 * 1024)))
MAX_ARCHIVE_TOTAL_BYTES = int(os.environ.get("FRAME_LAB_MAX_ARCHIVE_TOTAL_BYTES", str(512 * 1024 * 1024)))
MAX_ARCHIVE_MEMBERS = int(os.environ.get("FRAME_LAB_MAX_ARCHIVE_MEMBERS", "20000"))


class ArchiveLimitError(ValueError):
    """Raised when archive work exceeds a configured safety budget."""


def _check_archive_source(tgz_path: str) -> None:
    try:
        compressed = os.path.getsize(tgz_path)
    except OSError as exc:
        raise FileNotFoundError(tgz_path) from exc
    if compressed > MAX_ARCHIVE_COMPRESSED_BYTES:
        raise ArchiveLimitError("archive exceeds the compressed-size limit")


@contextmanager
def _tar_stream(tgz_path: str):
    with open_regular(tgz_path, "rb") as archive:
        with tarfile.open(fileobj=archive, mode="r|gz") as tf:
            yield tf


def is_journal_name(name: str) -> bool:
    return bool(_JOURNAL_RE.search(name)) or (
        name.endswith("events.jsonl")
        and ("measurement-runs" in name or "results/react_events" in name)
    )


# ---------------------------------------------------------------- tar helpers
def iter_tar_names(tgz_path: str) -> Iterator[tuple[str, int, bool]]:
    """Yield (name, size, is_file) for every member, streaming."""
    _check_archive_source(tgz_path)
    count = 0
    total = 0
    with _tar_stream(tgz_path) as tf:
        for m in tf:
            count += 1
            total += max(0, m.size)
            if count > MAX_ARCHIVE_MEMBERS:
                raise ArchiveLimitError("archive has too many members")
            if total > MAX_ARCHIVE_TOTAL_BYTES:
                raise ArchiveLimitError("archive exceeds the uncompressed-size limit")
            yield m.name, m.size, m.isfile()


def read_tar_member(tgz_path: str, member: str, max_bytes: int = MAX_JOURNAL_BYTES) -> bytes:
    """Stream-read one regular-file member's bytes (never extracted to disk)."""
    _check_archive_source(tgz_path)
    member = safe_member_name(member)
    assert_artifact_name(member)
    limit = min(max_bytes, MAX_ARCHIVE_MEMBER_BYTES)
    count = 0
    total = 0
    with _tar_stream(tgz_path) as tf:
        for m in tf:
            count += 1
            total += max(0, m.size)
            if count > MAX_ARCHIVE_MEMBERS or total > MAX_ARCHIVE_TOTAL_BYTES:
                raise ArchiveLimitError("archive exceeds the configured scan budget")
            if m.name != member:
                continue
            if not m.isfile():
                raise PathRejected("member is not a regular file")
            if m.size > limit:
                raise ArchiveLimitError("archive member exceeds the byte limit")
            fh = tf.extractfile(m)
            if fh is None:
                raise FileNotFoundError(member)
            data = fh.read(limit + 1)
            if len(data) > limit:
                raise ArchiveLimitError("archive member exceeds the byte limit")
            return data
    raise FileNotFoundError(member)


def iter_tar_member_lines(tgz_path: str, member: str) -> Iterator[str]:
    _check_archive_source(tgz_path)
    member = safe_member_name(member)
    assert_artifact_name(member)
    count = 0
    total = 0
    with _tar_stream(tgz_path) as tf:
        for m in tf:
            count += 1
            total += max(0, m.size)
            if count > MAX_ARCHIVE_MEMBERS or total > MAX_ARCHIVE_TOTAL_BYTES:
                raise ArchiveLimitError("archive exceeds the configured scan budget")
            if m.name == member and m.isfile():
                if m.size > min(MAX_JOURNAL_BYTES, MAX_ARCHIVE_MEMBER_BYTES):
                    raise ArchiveLimitError("journal member exceeds the byte limit")
                fh = tf.extractfile(m)
                if fh is None:
                    return
                seen = 0
                lines = 0
                for raw in fh:
                    seen += len(raw)
                    lines += 1
                    if seen > MAX_JOURNAL_BYTES or lines > MAX_JOURNAL_LINES:
                        raise ArchiveLimitError("journal exceeds the configured limit")
                    yield raw.decode("utf-8", "replace")
                return
            if m.name == member:
                raise PathRejected("member is not a regular file")
    raise FileNotFoundError(member)


# ------------------------------------------------------------- classification
CATEGORIES = [
    ("request", re.compile(r"^(request_submitted|request_prepared|capacity_preflight)$")),
    ("response", re.compile(r"^(response_received|native_batch_received)$")),
    ("test", re.compile(r"test|host_obligation_check|boundary_check")),
    ("idealpath", re.compile(r"idealpath|ideal_path|stage_transition|phase")),
    ("render", re.compile(r"render|overflow|degrad|exposure|selection_decision|history_decision|latest_exchange|budget_fit|compact")),
    ("decision", re.compile(r"decision|router|verdict|menu|authority|readiness|green_lock")),
    ("receipt", re.compile(r"receipt|outcome_closed|completed_action|observation_committed")),
    ("terminal", re.compile(r"terminat|completion|certification|final|stopped|run_started")),
    ("error", re.compile(r"error|refused|blocked|unrenderable")),
]


def categorize(kind: str) -> str:
    for name, pat in CATEGORIES:
        if pat.search(kind or ""):
            return name
    return "other"


def _num(v: Any) -> int | None:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    if isinstance(v, float) and not math.isfinite(v):
        return None
    return int(v)


def summarize_event(idx: int, ev: dict[str, Any], nbytes: int) -> dict[str, Any]:
    kind = str(ev.get("kind") or ev.get("type") or ev.get("event") or "?")
    row: dict[str, Any] = {
        "i": idx,
        "seq": ev.get("sequence", idx),
        "kind": kind,
        "cat": categorize(kind),
        "step": ev.get("step"),
        "request_id": ev.get("request_id"),
        "ts": ev.get("timestamp_ns"),
        "bytes": nbytes,
    }
    tok: dict[str, int] = {}
    if kind == "response_received":
        acc, _ = object_or_empty(ev.get("accounting"))
        usage, _ = object_or_empty(acc.get("raw_usage"))
        p = _num(acc.get("prompt_n")) or _num(usage.get("prompt_tokens"))
        c = _num(usage.get("completion_tokens")) or _num((acc.get("raw_timings") or {}).get("predicted_n"))
        if p is not None:
            tok["prompt"] = p
        if c is not None:
            tok["completion"] = c
        try:
            response, _ = object_or_empty(ev.get("response"))
            ch = response.get("choices") or [{}]
            choice, _ = object_or_empty(ch[0])
            row["finish"] = choice.get("finish_reason")
            message, _ = object_or_empty(choice.get("message"))
            tcs = message.get("tool_calls") or []
            row["label"] = ", ".join(
                str(object_or_empty(t.get("function"))[0].get("name") or t.get("name"))
                for t in tcs if isinstance(t, dict)
            )[:200]
        except (AttributeError, IndexError, TypeError):
            pass
        if ev.get("elapsed_ns"):
            row["elapsed_s"] = round(ev["elapsed_ns"] / 1e9, 2)
    elif kind == "capacity_preflight":
        if _num(ev.get("prompt_tokens")) is not None:
            tok["prompt_est"] = ev["prompt_tokens"]
        row["label"] = f"fits={ev.get('fits')} limit={ev.get('context_limit')}"
    elif kind == "exposure_composition":
        if _num(ev.get("estimated_context_tokens")) is not None:
            tok["context_est"] = ev["estimated_context_tokens"]
        row["label"] = str(ev.get("reason") or "")[:200]
    elif kind == "test_subprocess_completed":
        selectors = ev.get("selectors") if isinstance(ev.get("selectors"), list) else []
        row["label"] = f"exit={ev.get('exit_code')} selectors={len(selectors)}"
    elif kind == "request_submitted":
        payload, _ = object_or_empty(ev.get("payload"))
        msgs = payload.get("messages") if isinstance(payload.get("messages"), list) else []
        tools = payload.get("tools") if isinstance(payload.get("tools"), list) else []
        row["label"] = f"{len(msgs)} msgs, {len(tools)} tools, {len(ev.get('payload_utf8') or '') or sum(len(json.dumps(m)) for m in msgs)} chars"
    elif kind == "attempt_terminated":
        res, _ = object_or_empty(ev.get("result"))
        completion, _ = object_or_empty(res.get("completion"))
        row["label"] = f"{res.get('behaviour', '')} {completion.get('outcome', '')}".strip()
    else:
        for key in ("reason", "msg", "decision", "outcome", "mode", "tool", "status", "verdict"):
            v = ev.get(key)
            if isinstance(v, (str, int, float, bool)):
                row["label"] = f"{key}={v}"[:200]
                break
    if tok:
        row["tokens"] = tok
    return row


# ------------------------------------------------------------------- caching
class Journal:
    """Parsed journal held in memory: raw lines + summary rows."""

    def __init__(self, lines: list[str]):
        self.lines = lines
        self.size_bytes = sum(len(line.encode("utf-8", "replace")) for line in lines)
        self.rows: list[dict[str, Any]] = []
        self.bad_lines = 0
        self._parsed: dict[int, dict[str, Any]] = {}
        self._memo: dict[str, Any] = {}
        self._memo_inflight: dict[str, threading.Event] = {}
        self._memo_lock = threading.Lock()
        for i, line in enumerate(lines):
            try:
                ev = event_object(json.loads(line), line)
            except json.JSONDecodeError:
                self.bad_lines += 1
                ev = {"kind": "unparseable_line", "schema_status": "invalid_json", "raw": line[:20000]}
            self.rows.append(summarize_event(i, ev, len(line)))
        self._assign_attempt_ids()
        self.kinds: dict[str, int] = {}
        for r in self.rows:
            self.kinds[r["kind"]] = self.kinds.get(r["kind"], 0) + 1

    def _assign_attempt_ids(self) -> None:
        request_positions: dict[str, list[tuple[int, str]]] = {}
        for row in self.rows:
            rid = row.get("request_id")
            if isinstance(rid, str) and rid and row["kind"] == "request_submitted":
                request_positions.setdefault(rid, []).append((row["i"], f"{rid}@event-{row['i']}"))
        pre_request_kinds = {
            "selection_decision", "exposure_composition", "capacity_preflight", "history_decision",
            "latest_exchange_decision", "thinking_router_classified", "f4_budget_fit",
            "prompt_compact_applied", "request_prepared",
        }
        for row in self.rows:
            rid = row.get("request_id")
            if not isinstance(rid, str) or not rid:
                continue
            if row["kind"] == "request_submitted":
                row["attempt_id"] = f"{rid}@event-{row['i']}"
                continue
            choices = request_positions.get(rid, [])
            previous = [attempt for event_i, attempt in choices if event_i < row["i"]]
            following = [attempt for event_i, attempt in choices if event_i > row["i"]]
            if row["kind"] in pre_request_kinds and following:
                row["attempt_id"] = following[0]
            elif previous:
                row["attempt_id"] = previous[-1]
            elif following:
                row["attempt_id"] = following[0]

    def event(self, i: int) -> dict[str, Any]:
        if i < 0 or i >= len(self.lines):
            raise IndexError(i)
        if i not in self._parsed:
            try:
                value = event_object(json.loads(self.lines[i]), self.lines[i])
            except json.JSONDecodeError:
                value = {"kind": "unparseable_line", "schema_status": "invalid_json", "raw": self.lines[i][:20000]}
            if len(self._parsed) < int(os.environ.get("FRAME_LAB_MAX_PARSED_EVENTS", "5000")):
                self._parsed[i] = value
            return value
        return self._parsed[i]

    def memo_get_or(self, key: str, build: Callable[[], Any]) -> Any:
        """Memoize immutable derived indexes for this bounded journal."""
        while True:
            with self._memo_lock:
                if key in self._memo:
                    return self._memo[key]
                waiter = self._memo_inflight.get(key)
                if waiter is None:
                    waiter = threading.Event()
                    self._memo_inflight[key] = waiter
                    break
            waiter.wait()
        try:
            value = build()
        except BaseException:
            with self._memo_lock:
                self._memo_inflight.pop(key, None)
                waiter.set()
            raise
        with self._memo_lock:
            self._memo[key] = value
            self._memo_inflight.pop(key, None)
            waiter.set()
        return value


class _LRU:
    def __init__(self, cap: int, byte_cap: int | None = None):
        self.cap = cap
        self.byte_cap = byte_cap
        self.d: OrderedDict[Any, Any] = OrderedDict()
        self.weights: dict[Any, int] = {}
        self.bytes = 0
        self.lock = threading.Lock()

    def get(self, k):
        with self.lock:
            if k in self.d:
                self.d.move_to_end(k)
                return self.d[k]
        return None

    def put(self, k, v, weight: int = 0):
        with self.lock:
            self.bytes -= self.weights.pop(k, 0)
            self.d[k] = v
            self.weights[k] = max(0, weight)
            self.bytes += self.weights[k]
            self.d.move_to_end(k)
            while len(self.d) > self.cap or (self.byte_cap is not None and self.bytes > self.byte_cap):
                old, _ = self.d.popitem(last=False)
                self.bytes -= self.weights.pop(old, 0)

    def stats(self) -> dict[str, int | None]:
        with self.lock:
            return {"entries": len(self.d), "max_entries": self.cap, "bytes": self.bytes, "byte_cap": self.byte_cap}


_journals = _LRU(
    int(os.environ.get("FRAME_LAB_JOURNAL_CACHE", "6")),
    int(os.environ.get("FRAME_LAB_JOURNAL_CACHE_BYTES", str(128 * 1024 * 1024))),
)
_listings = _LRU(64, 8 * 1024 * 1024)
_journal_build_lock = threading.Lock()
_listing_build_lock = threading.Lock()


def _stat_key(p: str) -> tuple[str, float, int]:
    st = os.stat(p)
    return (p, st.st_mtime, st.st_size)


def _cached_journal(key: tuple[Any, ...], build) -> Journal:
    cached = _journals.get(key)
    if cached is not None:
        return cached
    # ThreadingHTTPServer may receive duplicate misses; serialize only the
    # bounded parse/build phase and recheck after waiting.
    with _journal_build_lock:
        cached = _journals.get(key)
        if cached is None:
            cached = build()
            _journals.put(key, cached, cached.size_bytes)
        return cached


def _cached_listing(key: tuple[Any, ...], build: Callable[[], list[Any]]) -> list[Any]:
    cached = _listings.get(key)
    if cached is not None:
        return cached
    # Archive scans are sequential gzip work; one bounded builder also avoids
    # duplicate decompression when several browser panels open together.
    with _listing_build_lock:
        cached = _listings.get(key)
        if cached is None:
            cached = build()
            weight = sum(len(str(item)) for item in cached)
            _listings.put(key, cached, weight)
        return cached
def load_journal(run_dir: str, jref: str) -> Journal:
    """``jref`` is relative to a run, or ``tgz:<member>`` in its archive."""
    run_layout = layout(run_dir)
    if jref.startswith(TGZ_PREFIX):
        src = run_layout.archive
        if src is None:
            raise FileNotFoundError("worker.tgz")
        member = safe_member_name(jref[len(TGZ_PREFIX):])
        if not is_journal_name(member):
            raise PathRejected("not a journal member")
        key = (_stat_key(src), member)
        return _cached_journal(key, lambda: Journal(list(iter_tar_member_lines(src, member))))
    # The run layout already discovers supported journal locations. Keep this
    # boundary permissive for engine exports that use a nested journal path,
    # while still rejecting non-journal sidecars and traversal attempts.
    if os.path.basename(jref) != "events.jsonl" or ".." in jref.split("/") or jref.startswith("/"):
        raise PathRejected("not a journal path")
    p = child_path(run_layout, jref)
    if not os.path.isfile(p):
        raise FileNotFoundError(jref)
    if os.path.getsize(p) > MAX_JOURNAL_BYTES:
        raise ArchiveLimitError("journal exceeds the byte limit")
    key = (_stat_key(p), "")
    def build_plain() -> Journal:
        lines: list[str] = []
        with open_regular(p, "r", encoding="utf-8", errors="replace") as fh:
            for line_no, line in enumerate(fh, 1):
                if line_no > MAX_JOURNAL_LINES:
                    raise ArchiveLimitError("journal has too many lines")
                lines.append(line)
        return Journal(lines)
    return _cached_journal(key, build_plain)


def list_journals(run_dir: str) -> list[dict[str, Any]]:
    """Journals for a run: extracted files under worker/ (or run/worker/) and tgz members."""
    out: list[dict[str, Any]] = []
    run_layout = layout(run_dir)
    for wd in run_layout.workers:
        for sub in ("measurement-runs", "results/react_events"):
            relative_dir = os.path.relpath(os.path.join(wd, sub), run_layout.outer)
            try:
                d = safe_existing_path(run_layout.outer, relative_dir, expect="dir")
            except (FileNotFoundError, PathRejected):
                continue
            for name in sorted(os.listdir(d)):
                cand = os.path.join(d, name, "events.jsonl") if sub == "measurement-runs" else os.path.join(d, name)
                relative = os.path.relpath(cand, run_layout.outer)
                if not is_journal_name(relative):
                    continue
                try:
                    safe_cand = safe_existing_path(run_layout.outer, relative, expect="file")
                except (FileNotFoundError, PathRejected):
                    continue
                out.append({"ref": relative, "size": os.path.getsize(safe_cand), "source": "file"})
    tgz = run_layout.archive
    if tgz:
        key = _stat_key(tgz)
        def build_members():
            members = []
            for n, s, is_file in iter_tar_names(tgz):
                if not is_file or not is_journal_name(n):
                    continue
                try:
                    safe_member_name(n)
                    assert_artifact_name(n)
                except PathRejected:
                    continue
                members.append((n, s))
            return members
        members = _cached_listing(key, build_members)
        for n, s in members:
            out.append({"ref": TGZ_PREFIX + n, "size": s, "source": "tgz"})
    # main measurement journals first, then legacy react_events
    out.sort(key=lambda j: (0 if "measurement-runs" in j["ref"] else 1, -j["size"]))
    return out


def list_tgz_members(run_dir: str) -> list[dict[str, Any]]:
    tgz = layout(run_dir).archive
    if tgz is None:
        raise FileNotFoundError("worker.tgz")
    key = ("all",) + _stat_key(tgz)
    def build_members():
        cached = []
        for n, s, is_file in iter_tar_names(tgz):
            try:
                safe_member_name(n)
                assert_artifact_name(n)
            except PathRejected:
                continue
            if is_file:
                cached.append({"name": n, "size": s, "file": True})
        return cached
    cached = _cached_listing(key, build_members)
    return cached


def cache_stats() -> dict[str, dict[str, int | None]]:
    """Expose bounded cache accounting for health/debug qualification."""
    return {"journals": _journals.stats(), "archive_listings": _listings.stats()}
