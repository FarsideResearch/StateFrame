"""Read-only indexers for Frame Lab UI.

Every module in this package only READS from the allowlisted source roots
defined in ``paths.py``. Nothing here writes, extracts or deletes.
"""
