"""Portable, read-only source configuration and traversal-safe paths.

The UI inspects an explicit versioned source manifest, a data-root folder
(or one StateFrame run directory), or the bundled demo. Optional sources are
absent from the path map when they do not exist; callers must expose that as a
diagnostic state rather than indexing unrelated machine directories.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

CONFIG_VERSION = 1
SOURCE_KEYS = ("capability", "experiments", "grades")
_SOURCE_FILES: set[str] = set()
# Accept the pre-release experiment source key in user manifests only.
ALIASES = {"runs": "capability", "frame" + "_lab": "experiments"}


class PathRejected(ValueError):
    """Raised when a requested path escapes the allowlist."""


@dataclass(frozen=True)
class Root:
    key: str
    path: str  # real (symlink-resolved) absolute path
    is_file: bool = False


@dataclass(frozen=True)
class SourceSpec:
    key: str
    path: str
    is_file: bool = False
    required: bool = False


@dataclass(frozen=True)
class SourceConfig:
    mode: str
    name: str
    specs: tuple[SourceSpec, ...]
    config_path: str | None = None
    error: str | None = None
    explicit_run: str | None = None
    share_mode: str = "curated"


_active: SourceConfig | None = None
_generation = 0


def _looks_like_run(path: str) -> bool:
    try:
        names = set(os.listdir(path))
    except OSError:
        return False
    return bool({"spec.json", "worker.tgz", "live-receipt.json", "first-outcome.json"} & names) or (
        "run" in names and os.path.isdir(os.path.join(path, "run", "worker"))
    ) or ("worker" in names and os.path.isdir(os.path.join(path, "worker")))


def _has_run_children(path: str) -> bool:
    try:
        entries = list(os.scandir(path))
    except OSError:
        return False
    return any(entry.is_dir(follow_symlinks=False) and _looks_like_run(entry.path) for entry in entries)


def _normalise_specs(specs: list[SourceSpec]) -> tuple[list[SourceSpec], str | None]:
    """Allow a manifest to point directly at one engine-produced run."""
    result: list[SourceSpec] = []
    explicit_run = None
    for spec in specs:
        path = os.path.realpath(os.path.expanduser(spec.path))
        if spec.key == "capability" and _looks_like_run(path):
            explicit_run = os.path.basename(path)
            path = os.path.dirname(path)
        result.append(SourceSpec(spec.key, path, spec.is_file, spec.required))
    return result, explicit_run


def _manifest_specs(config_path: str) -> tuple[list[SourceSpec], str | None, str]:
    with open(config_path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    if not isinstance(raw, dict) or raw.get("version") != CONFIG_VERSION:
        raise ValueError(f"source manifest must declare version {CONFIG_VERSION}")
    sources = raw.get("sources")
    if not isinstance(sources, dict):
        raise ValueError("source manifest requires an object at 'sources'")
    base = os.path.dirname(config_path)
    specs: list[SourceSpec] = []
    for raw_key, raw_path in sources.items():
        key = ALIASES.get(str(raw_key), str(raw_key))
        if key == "proofs":
            continue
        if key not in SOURCE_KEYS:
            raise ValueError(f"unsupported source key: {raw_key}")
        if not isinstance(raw_path, str) or not raw_path.strip():
            raise ValueError(f"source '{raw_key}' must be a non-empty path")
        path = raw_path if os.path.isabs(raw_path) else os.path.join(base, raw_path)
        specs.append(SourceSpec(key, path, key in _SOURCE_FILES, key == "capability"))
    if not any(s.key == "capability" for s in specs):
        specs.append(SourceSpec("capability", os.path.join(base, "runs"), required=True))
    specs, explicit_run = _normalise_specs(specs)
    return specs, explicit_run, str(raw.get("name") or "Configured sources")


def _data_root_specs(data_root: str) -> tuple[list[SourceSpec], str | None]:
    base = os.path.realpath(os.path.expanduser(data_root))
    if _looks_like_run(base):
        return _normalise_specs([SourceSpec("capability", base, required=True)])
    # A data root has a runs/ folder; a plain folder whose children are run directories is used as that folder.
    runs_dir = os.path.join(base, "runs")
    if not os.path.isdir(runs_dir) and _has_run_children(base):
        runs_dir = base
    return _normalise_specs([
        SourceSpec("capability", runs_dir, required=True),
        SourceSpec("experiments", os.path.join(base, "experiments")),
        SourceSpec("grades", os.path.join(base, "grades")),
    ])


def configure(*, config_path: str | None = None, data_root: str | None = None, demo: bool = False) -> SourceConfig:
    """Select a source contract without touching or copying source artifacts."""
    global _active, _generation
    try:
        if demo:
            demo_path = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "demo", "sources.json"))
            specs, explicit_run, name = _manifest_specs(demo_path)
            _active = SourceConfig("demo", name, tuple(specs), demo_path, explicit_run=explicit_run, share_mode="curated")
        elif config_path:
            path = os.path.realpath(os.path.expanduser(config_path))
            specs, explicit_run, name = _manifest_specs(path)
            _active = SourceConfig("config", name, tuple(specs), path, explicit_run=explicit_run, share_mode=_configured_share_mode())
        elif data_root:
            specs, explicit_run = _data_root_specs(data_root)
            _active = SourceConfig("data-root", "Data root", tuple(specs), explicit_run=explicit_run, share_mode=_configured_share_mode())
        else:
            # Nothing configured: show the bundled synthetic demo rather than guessing at local folders.
            return configure(demo=True)
    except (OSError, ValueError, json.JSONDecodeError):
        mode = "demo" if demo else "config" if config_path else "data-root"
        _active = SourceConfig(mode, "Source configuration error", (), config_path, error="SOURCE_CONFIG_INVALID", share_mode=_configured_share_mode())
    _generation += 1
    return _active


def source_config() -> SourceConfig:
    global _active
    if _active is None:
        env_config = os.environ.get("FRAME_LAB_CONFIG")
        env_data = os.environ.get("FRAME_LAB_DATA")
        env_demo = os.environ.get("FRAME_LAB_DEMO", "").lower() in {"1", "true", "yes"}
        configure(config_path=env_config, data_root=env_data, demo=env_demo)
    return _active


def source_generation() -> int:
    source_config()
    return _generation


def _configured_share_mode() -> str:
    value = os.environ.get("FRAME_LAB_SHARE_MODE", "curated").strip().lower()
    return value if value in {"curated", "private"} else "curated"


def share_mode() -> str:
    return source_config().share_mode


def _roots_spec() -> list[tuple[str, str, bool]]:
    """Compatibility view used by older integrations."""
    return [(s.key, s.path, s.is_file) for s in source_config().specs]


def roots() -> dict[str, Root]:
    """Return only existing configured roots; missing roots remain diagnostics."""
    out: dict[str, Root] = {}
    for spec in source_config().specs:
        expected = os.path.isfile(spec.path) if spec.is_file else os.path.isdir(spec.path)
        if expected:
            out[spec.key] = Root(spec.key, os.path.realpath(spec.path), spec.is_file)
    return out


def source_diagnostics() -> dict[str, Any]:
    cfg = source_config()
    statuses: list[dict[str, Any]] = []
    by_key = {s.key: s for s in cfg.specs}
    for key in SOURCE_KEYS:
        spec = by_key.get(key)
        if spec is None:
            statuses.append({"key": key, "status": "not_configured", "required": key == "capability"})
            continue
        exists = os.path.isfile(spec.path) if spec.is_file else os.path.isdir(spec.path)
        readable = os.access(spec.path, os.R_OK) if exists else False
        statuses.append({
            "key": key,
            "status": "available" if exists and readable else "missing" if not exists else "unreadable",
            "required": spec.required,
            "kind": "file" if spec.is_file else "directory",
        })
    available = sum(s["status"] == "available" for s in statuses)
    capability = next((s for s in statuses if s["key"] == "capability"), None)
    if cfg.error:
        status, next_action = "invalid", "Fix the source manifest and restart Frame Lab."
    elif capability and capability["status"] == "available":
        status, next_action = "ready", "Open Runs to inspect the configured engine artifacts."
    elif available:
        status, next_action = "partial", "Add a readable runs source, or start with the bundled demo."
    else:
        status, next_action = "unavailable", "Start with --demo, --data-root PATH, or --config PATH."
    return {
        "mode": cfg.mode,
        "name": cfg.name,
        "config_name": os.path.basename(cfg.config_path) if cfg.config_path else None,
        "share_mode": cfg.share_mode,
        "projection": "redacted",
        "status": status,
        "ready": status in {"ready", "partial"},
        "next_action": next_action,
        "error": cfg.error,
        "sources": statuses,
    }


def _within(path: str, base: str) -> bool:
    try:
        return os.path.commonpath([path, base]) == base
    except ValueError:
        return False


_ALWAYS_BLOCKED_NAMES = {
    ".env", ".netrc", ".npmrc", ".pypirc", "id_rsa", "id_ed25519", "authorized_keys",
}
_ALWAYS_BLOCKED_EXTENSIONS = {".pem", ".key", ".crt", ".cer", ".p12", ".pfx", ".jks", ".keystore", ".sqlite", ".sqlite3", ".db"}
_CURATED_BLOCKED_EXTENSIONS = {".log", ".out", ".sh", ".py", ".pyc", ".pem", ".key"}


def artifact_name_allowed(name: str, mode: str | None = None) -> bool:
    """Apply the filename side of the private/curated read policy."""
    base = os.path.basename(name.rstrip("/"))
    lower = base.lower()
    if not base or base.startswith(".") or lower in _ALWAYS_BLOCKED_NAMES:
        return False
    if lower.endswith(tuple(_ALWAYS_BLOCKED_EXTENSIONS)) or any(
        marker in lower for marker in ("credentials", "secret", "password", "private-key")
    ):
        return False
    return (mode or share_mode()) == "private" or not lower.endswith(tuple(_CURATED_BLOCKED_EXTENSIONS))


def assert_artifact_name(name: str, mode: str | None = None) -> str:
    if not artifact_name_allowed(name, mode):
        raise PathRejected("artifact type is not available under the read policy")
    return name


def safe_existing_path(base: str, relative: str, *, expect: str | None = None) -> str:
    """Resolve one artifact below ``base`` and reject symlink escapes."""
    base_real = os.path.realpath(base)
    candidate = os.path.join(base_real, *[p for p in relative.replace("\\", "/").split("/") if p not in ("", ".")])
    resolved = os.path.realpath(candidate)
    if not _within(resolved, base_real) or (os.path.lexists(candidate) and not os.path.exists(candidate)):
        raise PathRejected("artifact path escapes or is unavailable")
    if expect == "file" and not os.path.isfile(resolved):
        raise FileNotFoundError(relative)
    if expect == "dir" and not os.path.isdir(resolved):
        raise FileNotFoundError(relative)
    return resolved


def resolve(root_key: str, rel: str = "", root_map: dict[str, Root] | None = None) -> str:
    """Return the real absolute path of ``rel`` inside configured root."""
    rmap = root_map if root_map is not None else roots()
    root = rmap.get(root_key)
    if root is None:
        raise PathRejected(f"unknown or unavailable root: {root_key!r}")
    rel = rel or ""
    if "\x00" in rel or rel.startswith(("/", "\\")) or os.path.isabs(rel):
        raise PathRejected("absolute or invalid path")
    parts = [p for p in rel.replace("\\", "/").split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise PathRejected("path traversal")
    if root.is_file:
        if parts:
            raise PathRejected("file root has no children")
        return root.path
    return safe_existing_path(root.path, "/".join(parts)) if parts else root.path



def safe_member_name(name: str) -> str:
    """Validate a tar member name requested by a client."""
    if not name or "\x00" in name or name.startswith("/") or "\\" in name:
        raise PathRejected("invalid member name")
    if any(p == ".." for p in name.split("/")):
        raise PathRejected("member traversal")
    return name
