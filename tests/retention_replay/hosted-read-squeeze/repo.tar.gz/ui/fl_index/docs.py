"""Supporting documents that sit beside grade files (Markdown or JSON reports)."""
from __future__ import annotations

import os
from typing import Any

from .paths import artifact_name_allowed, roots, safe_existing_path


def grades_docs() -> list[dict[str, Any]]:
    root = roots().get("grades")
    if root is None:
        return []
    base = root.path
    out = []
    try:
        names = sorted(os.listdir(base))
    except OSError:
        return []
    for name in names:
        if not name.endswith((".md", ".json")) or not artifact_name_allowed(name):
            continue
        try:
            p = safe_existing_path(base, name, expect="file")
        except (FileNotFoundError, ValueError):
            continue
        if os.path.isfile(p):
            try:
                out.append({"name": name, "size": os.path.getsize(p), "mtime": os.path.getmtime(p)})
            except OSError:
                continue
    return out
