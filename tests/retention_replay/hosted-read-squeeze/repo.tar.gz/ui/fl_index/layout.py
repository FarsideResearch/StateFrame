"""One run-layout contract for StateFrame run directories, nested exports and archives."""
from __future__ import annotations

import os
from dataclasses import dataclass

from .paths import PathRejected, artifact_name_allowed, safe_existing_path


@dataclass(frozen=True)
class RunLayout:
    outer: str
    metadata_root: str
    archive: str | None
    workers: tuple[str, ...]

    @property
    def has_archive(self) -> bool:
        return self.archive is not None

    @property
    def has_worker(self) -> bool:
        return bool(self.workers)


def layout(run_dir: str) -> RunLayout:
    """Resolve direct, nested, extracted, and archive artifacts consistently."""
    outer = os.path.realpath(run_dir)
    nested = os.path.join(outer, "run")
    safe_nested = _safe_dir(outer, "run")
    metadata_root = safe_nested if safe_nested and any(
        os.path.exists(os.path.join(safe_nested, name))
        for name in ("completion.json", "live-receipt.json", "first-outcome.json", "timings.json", "release-start.json")
    ) else outer
    archive = next((p for p in (
        _safe_file(outer, "worker.tgz"),
        _safe_file(outer, "run/worker.tgz"),
    ) if p), None)
    workers = tuple(p for p in (
        _safe_dir(outer, "worker"),
        _safe_dir(outer, "run/worker"),
    ) if p)
    return RunLayout(outer, metadata_root, archive, workers)


def _safe_file(base: str, relative: str) -> str | None:
    try:
        if not artifact_name_allowed(relative):
            return None
        return safe_existing_path(base, relative, expect="file")
    except (FileNotFoundError, PathRejected):
        return None


def _safe_dir(base: str, relative: str) -> str | None:
    try:
        return safe_existing_path(base, relative, expect="dir")
    except (FileNotFoundError, PathRejected):
        return None


def child_path(run_layout: RunLayout, relative: str) -> str:
    """Resolve a user-visible run file below the outer run directory."""
    relative = relative or ""
    if "\x00" in relative or relative.startswith(("/", "\\")) or os.path.isabs(relative):
        raise PathRejected("absolute or invalid run path")
    parts = [p for p in relative.replace("\\", "/").split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise PathRejected("run path traversal")
    return safe_existing_path(run_layout.outer, "/".join(parts)) if parts else run_layout.outer


def metadata_path(run_layout: RunLayout, name: str) -> str:
    """Prefer nested engine sidecars, falling back to the outer run directory."""
    for base in (run_layout.metadata_root, run_layout.outer):
        try:
            return safe_existing_path(base, name, expect="file")
        except FileNotFoundError:
            continue
    return os.path.join(run_layout.metadata_root, name)


def list_files(run_layout: RunLayout, relative: str = "") -> list[dict[str, object]]:
    directory = child_path(run_layout, relative)
    if not os.path.isdir(directory):
        raise FileNotFoundError(relative)
    out: list[dict[str, object]] = []
    for entry in sorted(os.scandir(directory), key=lambda item: (not item.is_dir(follow_symlinks=False), item.name)):
        if not artifact_name_allowed(entry.name):
            continue
        if entry.is_dir(follow_symlinks=False):
            out.append({"name": f"{entry.name}/", "size": None})
        elif entry.is_file(follow_symlinks=False):
            out.append({"name": entry.name, "size": entry.stat().st_size})
    return out
