"""Discovery of capability-study runs and cheap per-run metadata.

A run directory is any directory under the capability-study root that holds
spec.json, worker.tgz, worker/ or run/worker/. Journals are NOT parsed here
(that happens lazily on drill-in); only small sidecar JSON files are read.
"""
from __future__ import annotations

import os
import re
import time
from collections import OrderedDict
from typing import Any

from .layout import layout, list_files, metadata_path
from .paths import resolve, roots, source_config, source_generation
from . import grades
from .util import TTLCache, read_json

SKIP_DIRS = {"runtime-releases", "worker", "candidates", "measurement-runs", "continuation-workspaces", "node_modules", ".git", "__pycache__"}
MAX_DEPTH = 4
_cache = TTLCache(60)
_meta_cache: OrderedDict[tuple[int, str, float, int], dict[str, Any]] = OrderedDict()
_META_CACHE_ENTRIES = max(16, int(os.environ.get("FRAME_LAB_META_CACHE_ENTRIES", "256")))


def _is_run_dir(path: str, names: set[str]) -> bool:
    return bool({"spec.json", "worker.tgz", "live-receipt.json", "first-outcome.json"} & names) or "worker" in names and os.path.isdir(os.path.join(path, "worker")) or (
        "run" in names and os.path.isdir(os.path.join(path, "run", "worker"))
    )


def discover() -> list[str]:
    capability = roots().get("capability")
    if capability is None:
        return []
    base = capability.path
    found: list[str] = []

    explicit_run = source_config().explicit_run
    if explicit_run:
        return [explicit_run] if os.path.isdir(os.path.join(base, explicit_run)) else []

    def walk(d: str, depth: int) -> None:
        try:
            entries = list(os.scandir(d))
        except OSError:
            return
        names = {e.name for e in entries}
        if depth > 0 and _is_run_dir(d, names):
            found.append(os.path.relpath(d, base))
            return
        if depth >= MAX_DEPTH:
            return
        for e in entries:
            if e.is_dir(follow_symlinks=False) and e.name not in SKIP_DIRS and not e.name.startswith("."):
                walk(e.path, depth + 1)

    walk(base, 0)
    return sorted(found)


_SEED_RE = re.compile(r"-\d{6}-.*$")


def fixture_of(task_dir: str) -> str:
    t = _SEED_RE.sub("", task_dir)
    return t


def _batch_of(rel: str) -> str:
    parts = rel.split("/")
    return "/".join(parts[:-1]) if len(parts) > 1 else parts[0]


def _status(d: str, comp: Any, receipt: Any) -> str:
    if isinstance(receipt, dict):
        if receipt.get("timed_out"):
            return "timed_out"
        if receipt.get("return_code") not in (None, 0):
            return f"exit_{receipt.get('return_code')}"
        if receipt.get("complete"):
            return "complete"
    if isinstance(comp, dict):
        outs = comp.get("outcomes") or []
        if any(o.get("timed_out") for o in outs if isinstance(o, dict)):
            return "timed_out"
        codes = [o.get("exit_code") for o in outs if isinstance(o, dict)]
        if codes and all(c == 0 for c in codes):
            return "complete"
        if codes:
            return f"exit_{codes[-1]}"
    launch = os.path.join(d, "launch.log")
    if os.path.exists(launch) and time.time() - os.path.getmtime(launch) < 900:
        return "running"
    if "_stranded" in d:
        return "stranded"
    return "unknown"


def _status_source(d: str, comp: Any, receipt: Any) -> str:
    if isinstance(receipt, dict) and receipt.get("timed_out"):
        return "live-receipt.json:timed_out"
    if isinstance(receipt, dict) and receipt.get("return_code") not in (None, 0):
        return "live-receipt.json:return_code"
    if isinstance(receipt, dict) and receipt.get("complete"):
        return "live-receipt.json:complete"
    if isinstance(comp, dict) and comp.get("outcomes"):
        return "completion.json:outcomes"
    launch = os.path.join(d, "launch.log")
    if os.path.exists(launch) and time.time() - os.path.getmtime(launch) < 900:
        return "launch.log:recent-activity"
    if "_stranded" in d:
        return "run-id:stranded"
    return "no-authoritative-receipt"


def run_meta(rel: str) -> dict[str, Any]:
    d = resolve("capability", rel)
    run_layout = layout(d)
    try:
        mt = os.path.getmtime(d)
    except OSError:
        mt = 0
    for f in ("completion.json", "first-outcome.json", "live-receipt.json", "timings.json", "release-start.json", "spec.json", "effective-config.json", "requested-config.json", "provider-wire.json", "summary.json", "worker.tgz", "launch.log"):
        p = metadata_path(run_layout, f)
        if f == "worker.tgz" and run_layout.archive:
            p = run_layout.archive
        if os.path.exists(p):
            mt = max(mt, os.path.getmtime(p))
    for worker_root in run_layout.workers:
        try:
            mt = max(mt, os.path.getmtime(worker_root))
        except OSError:
            pass
    # Running-state is time-sensitive even when no artifact changes.
    ck = (source_generation(), rel, mt, int(time.time() // 60))
    if ck in _meta_cache:
        _meta_cache.move_to_end(ck)
        return _meta_cache[ck]
    task = os.path.basename(d)
    comp = read_json(metadata_path(run_layout, "completion.json"))
    receipt = read_json(metadata_path(run_layout, "live-receipt.json"))
    outcome_value = read_json(metadata_path(run_layout, "first-outcome.json"), 8 * 1024 * 1024)
    outcome = outcome_value if isinstance(outcome_value, dict) else {}
    timings_value = read_json(metadata_path(run_layout, "timings.json"), 8 * 1024 * 1024)
    timings_obj = timings_value if isinstance(timings_value, dict) else {}
    timings = timings_obj.get("summary") if isinstance(timings_obj.get("summary"), dict) else {}
    rel_start_value = read_json(metadata_path(run_layout, "release-start.json"))
    rel_start = rel_start_value if isinstance(rel_start_value, dict) else {}
    spec_value = read_json(metadata_path(run_layout, "spec.json"))
    spec = spec_value if isinstance(spec_value, dict) else {}
    env = spec.get("environment") or {}
    release = os.path.basename(str(rel_start.get("release") or ""))[:12] or None
    receipt_dict = receipt if isinstance(receipt, dict) else {}
    fixture = receipt_dict.get("task_id") or fixture_of(task)
    candidate_identity = None
    summary_value = read_json(metadata_path(run_layout, "summary.json"))
    engine_summary = summary_value if isinstance(summary_value, dict) else {}
    for source in (receipt, outcome, comp, spec, engine_summary):
        if isinstance(source, dict):
            candidate_identity = source.get("candidate_sha256") or source.get("candidate_hash") or candidate_identity
    try:
        from .journal import list_journals
        journal_refs = list_journals(d)
        journal_error = None
    except Exception:  # bounded source diagnostics; the route remains usable
        journal_refs = []
        journal_error = "JOURNAL_UNAVAILABLE"
    run_grade = grades.verdict_for_run(rel, candidate_identity)
    task_grade = grades.latest_verdicts().get(fixture or "")
    engine_state = "complete" if receipt_dict.get("complete") else "failed" if receipt_dict.get("return_code") not in (None, 0) else "unknown"
    launch_path = os.path.join(run_layout.metadata_root, "launch.log")
    try:
        activity_mtime = os.path.getmtime(launch_path)
    except OSError:
        activity_mtime = None
    process_state = _status(run_layout.metadata_root, comp, receipt)
    m = {
        "id": rel,
        "batch": _batch_of(rel),
        "task": task,
        "fixture": fixture,
        "release": release,
        "kernel_mode": env.get("KERNEL_MODE"),
        "projector": env.get("STATEFRAME_PROJECTOR"),
        "seed": env.get("REACT_SEED"),
        "mtime": mt,
        "artifact_mtime": mt,
        "activity_mtime": activity_mtime,
        "status": process_state,
        "status_source": _status_source(run_layout.metadata_root, comp, receipt),
        "process_state": process_state,
        "engine_state": engine_state,
        "result": outcome.get("result"),
        "behaviour": outcome.get("behaviour"),
        "steps": outcome.get("steps"),
        "edits": outcome.get("edits"),
        "tests": outcome.get("tests"),
        "requests": timings.get("responses"),
        "prompt_tokens": timings.get("prompt_n_total"),
        "wall_s": timings.get("wall_s_in_requests"),
        "provider_request_s": timings.get("wall_s_in_requests"),
        "has_tgz": run_layout.has_archive,
        "has_worker": run_layout.has_worker,
        "layout": {
            "metadata_root": os.path.relpath(run_layout.metadata_root, d),
            "archive": os.path.relpath(run_layout.archive, d) if run_layout.archive else None,
            "worker_roots": [os.path.relpath(p, d) for p in run_layout.workers],
        },
        "elapsed_s": receipt_dict.get("elapsed_seconds"),
        "journal_available": bool(journal_refs),
        "has_journal": bool(journal_refs),
        "journal_status": "available" if journal_refs else "unavailable",
        "journal_count": len(journal_refs),
        "journal_error": journal_error,
        "candidate_identity": candidate_identity,
        "run_verdict": run_grade["verdict"] if run_grade else "unknown",
        "run_verdict_source": f"{run_grade['root']}:{run_grade['path']}" if run_grade else None,
        "task_grade": {
            "verdict": task_grade["verdict"],
            "source": f"{task_grade['root']}:{task_grade['path']}",
            "scope": "task",
        } if task_grade else None,
    }
    _apply_engine_summary(m, engine_summary)
    _meta_cache[ck] = m
    _meta_cache.move_to_end(ck)
    while len(_meta_cache) > _META_CACHE_ENTRIES:
        _meta_cache.popitem(last=False)
    return m


def _apply_engine_summary(meta: dict[str, Any], summary: dict[str, Any]) -> None:
    """Fill run facts from the summary.json that `stateframe run` writes, where no richer sidecar exists."""
    if not summary:
        return
    succeeded = summary.get("succeeded")
    exit_code = summary.get("exit_code")
    if meta.get("status") == "unknown":
        if succeeded is True:
            status = "complete"
        elif type(exit_code) is int and exit_code != 0:
            status = f"exit_{exit_code}"
        else:
            status = "unknown"
        meta["status"] = meta["process_state"] = status
        meta["status_source"] = "summary.json"
    if meta.get("result") is None and isinstance(succeeded, bool):
        meta["result"] = "PASS" if succeeded else "FAIL"
    outcome = summary.get("runtime_outcome")
    meta["engine_outcome"] = outcome if isinstance(outcome, str) else None
    for key, source in (("requests", "requests"), ("prompt_tokens", "prompt_tokens_sent"), ("wall_s", "wall_seconds")):
        value = summary.get(source)
        if meta.get(key) is None and type(value) in (int, float):
            meta[key] = value


def list_runs() -> list[dict[str, Any]]:
    def build():
        rows = []
        for rel in discover():
            try:
                m = dict(run_meta(rel))
            except Exception:  # one broken run dir must not hide the rest
                m = {
                    "id": rel,
                    "batch": _batch_of(rel),
                    "task": os.path.basename(rel),
                    "status": "index_error",
                    "error": "RUN_METADATA_UNAVAILABLE",
                }
            v = m.get("run_verdict")
            m["verdict"] = v if v in ("FIXED", "NOT_FIXED") else "unknown"
            m["verdict_source"] = m.get("run_verdict_source")
            rows.append(m)
        # Newest first; equal times (e.g. a fresh install) fall back to a stable id order.
        rows.sort(key=lambda r: (-(r.get("mtime") or 0), str(r.get("id") or "")))
        return rows

    return _cache.get_or(("runs", source_generation()), build)


def run_files(rel: str, path: str = "") -> list[dict[str, Any]]:
    d = resolve("capability", rel)
    return list_files(layout(d), path)
