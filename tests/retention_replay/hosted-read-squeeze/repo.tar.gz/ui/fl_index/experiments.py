"""Frame Lab experiments: tolerant adapters over heterogeneous RESULTS files.

Formats vary per experiment, so instead of per-experiment parsers we:
  * render RESULTS.md and parse its pipe tables;
  * for any JSON, locate arrays of record objects ("cases"), infer columns,
    and compute per-arm rates with Wilson 95% CIs for boolean/PASS-like fields;
  * fall back to raw JSON (redacted) addressed by a JSON pointer for lazy loading.
"""
from __future__ import annotations

import json
import math
import os
import re
from typing import Any

from .paths import artifact_name_allowed, resolve, roots, safe_existing_path, source_generation
from .runs import discover
from .util import TTLCache, open_regular, parse_md_tables, read_text

LIST_EXTS = (".md", ".json", ".jsonl", ".log", ".txt", ".sh", ".out")
MAX_LISTED = 600
MAX_JSON_BYTES = 64 * 1024 * 1024
INLINE_JSON_BYTES = 3 * 1024 * 1024
_cache = TTLCache(30)


def list_experiments() -> list[dict[str, Any]]:
    def build():
        root = roots().get("experiments")
        if root is None:
            return []
        base = root.path
        out = []
        for e in sorted(os.scandir(base), key=lambda e: e.name):
            if not e.is_dir(follow_symlinks=False) or e.name.startswith((".", "_")) or not artifact_name_allowed(e.name):
                continue
            try:
                res_md = safe_existing_path(e.path, "RESULTS.md", expect="file")
            except (FileNotFoundError, ValueError):
                res_md = None
            title, date = None, None
            if res_md:
                try:
                    txt, _ = read_text(res_md, 20000)
                except OSError:
                    txt = ""
                for line in txt.splitlines():
                    if line.startswith("#") and not title:
                        title = line.lstrip("#").strip()
                    m = re.match(r"\s*(?:\*\*)?Date(?:\*\*)?:\s*(.+)", line)
                    if m and not date:
                        date = m.group(1).strip()
            try:
                names = [n for n in os.listdir(e.path) if artifact_name_allowed(n)]
            except OSError:
                continue
            mtimes = []
            for n in names:
                try:
                    mtimes.append(os.path.getmtime(safe_existing_path(e.path, n)))
                except (FileNotFoundError, ValueError):
                    continue
            mtime = max(mtimes + [e.stat(follow_symlinks=False).st_mtime]) if mtimes else e.stat(follow_symlinks=False).st_mtime
            try:
                results_json = safe_existing_path(e.path, "RESULTS.json", expect="file")
            except (FileNotFoundError, ValueError):
                results_json = None
            manifest = _read_manifest(e.path)
            out.append({
                "name": e.name,
                "title": title,
                "date": date,
                "has_results_md": res_md is not None,
                "has_results_json": results_json is not None,
                "has_manifest": manifest is not None,
                "files": len(names),
                "runs": sum(1 for n in names if n.startswith("run-")),
                "mtime": mtime,
            })
        out.sort(key=lambda r: -r["mtime"])
        return out

    return _cache.get_or(("experiments", source_generation()), build)


def experiment_detail(name: str, offset: int = 0, limit: int = 200, query: str = "") -> dict[str, Any]:
    d = resolve("experiments", name)
    if not os.path.isdir(d):
        raise FileNotFoundError(name)
    md = ""
    md_trunc = False
    try:
        p = safe_existing_path(d, "RESULTS.md", expect="file")
    except (FileNotFoundError, ValueError):
        p = None
    if p:
        md, md_trunc = read_text(p, 4 * 1024 * 1024)
    all_files = []
    for dirpath, dirnames, filenames in os.walk(d):
        depth = os.path.relpath(dirpath, d).count(os.sep) + (0 if dirpath == d else 1)
        dirnames[:] = [x for x in sorted(dirnames) if not x.startswith((".", "__")) and artifact_name_allowed(x)] if depth < 3 else []
        for fn in sorted(filenames):
            if fn.endswith(LIST_EXTS) and artifact_name_allowed(fn):
                rel = os.path.relpath(os.path.join(dirpath, fn), roots()["experiments"].path)
                try:
                    fp = safe_existing_path(roots()["experiments"].path, rel, expect="file")
                except (FileNotFoundError, ValueError):
                    continue
                all_files.append({"path": rel, "size": os.path.getsize(fp), "mtime": os.path.getmtime(fp)})
        # Keep the priority ordering deterministic, then filter/page the full
        # discovered set so a late RESULTS file cannot disappear behind a cap.
    all_files.sort(key=lambda f: (0 if os.path.basename(f["path"]).startswith("RESULTS") else 1, f["path"].count("/"), f["path"]))
    needle = query.strip().lower()
    filtered_files = [f for f in all_files if not needle or needle in f["path"].lower()]
    page = filtered_files[offset: offset + limit]
    manifest = _read_manifest(d)
    return {"name": name, "results_md": md, "results_md_truncated": md_trunc,
            "results_md_bytes": len(md.encode("utf-8")),
            "tables": parse_md_tables(md), "manifest": manifest, "comparison": comparison_for(name, d, manifest), "files": page,
            "files_offset": offset, "files_limit": limit, "files_total": len(filtered_files),
            "files_has_more": offset + len(page) < len(filtered_files),
            "files_next_offset": offset + len(page) if offset + len(page) < len(filtered_files) else None,
            "files_capped": len(filtered_files) > len(page)}


def _read_manifest(directory: str) -> dict[str, Any] | None:
    """Read the optional versioned experiment contract without guessing it."""
    for name in ("experiment.json", "manifest.json"):
        try:
            path = safe_existing_path(directory, name, expect="file")
        except (FileNotFoundError, ValueError):
            continue
        try:
            with open_regular(path, "r", encoding="utf-8") as fh:
                value = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return {"schema_status": "invalid_manifest", "name": name}
        if not isinstance(value, dict):
            return {"schema_status": "invalid_manifest", "name": name}
        schema = value.get("schema")
        if schema not in (None, "stateframe.experiment.v1"):
            value["schema_status"] = "unsupported_manifest"
        else:
            value.setdefault("schema", "stateframe.experiment.v1")
        return value
    return None


# ---------------------------------------------------------- paired comparison
def _case_records(directory: str, manifest: dict[str, Any]) -> tuple[list[Any], str | None, list[str]]:
    """Read the explicitly declared case file, with a conservative fallback."""
    configured = manifest.get("cases_file") or manifest.get("data_file") or manifest.get("records_file")
    candidates = [configured] if isinstance(configured, str) else []
    candidates.extend(name for name in ("cases.json", "RESULTS.json", "results.json", "cases.jsonl") if name not in candidates)
    for name in candidates:
        try:
            path = safe_existing_path(directory, name, expect="file")
        except (FileNotFoundError, ValueError):
            continue
        if os.path.getsize(path) > MAX_JSON_BYTES:
            return [], name, ["case file exceeds the configured comparison limit"]
        try:
            with open_regular(path, "r", encoding="utf-8") as fh:
                text = fh.read()
        except OSError:
            return [], name, ["case file could not be read"]
        if name.endswith(".jsonl"):
            records, errors = [], []
            for line_no, line in enumerate(text.splitlines()[:10000], 1):
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    errors.append(f"invalid JSONL row {line_no}")
            return records, name, errors
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            return [], name, ["case file is invalid JSON"]
        pointer = manifest.get("cases_pointer", "")
        try:
            value = get_pointer(value, pointer) if pointer else value
        except (KeyError, IndexError, ValueError):
            return [], name, ["cases_pointer does not resolve"]
        if isinstance(value, list):
            return value[:10000], name, []
        arrays = find_record_arrays(value)
        if arrays:
            try:
                return get_pointer(value, arrays[0]["pointer"])[:10000], name, []
            except (KeyError, IndexError, TypeError):
                pass
        return [], name, ["case file does not contain a record array"]
    return [], None, ["no case file declared or found"]


def _comparison_arms(manifest: dict[str, Any], records: list[Any], arm_key: str) -> list[dict[str, str]]:
    declared = manifest.get("arms")
    out: list[dict[str, str]] = []
    if isinstance(declared, list):
        for item in declared:
            if isinstance(item, str):
                out.append({"id": item, "label": item})
            elif isinstance(item, dict) and isinstance(item.get("id"), str):
                out.append({"id": item["id"], "label": str(item.get("label") or item["id"])})
    if out:
        return out
    values = sorted({str(row.get(arm_key)) for row in records if isinstance(row, dict) and row.get(arm_key) is not None})
    return [{"id": value, "label": value} for value in values]


def _comparison_metric_defs(manifest: dict[str, Any], records: list[Any]) -> list[dict[str, Any]]:
    declared = manifest.get("metrics")
    if isinstance(declared, list):
        out = []
        for item in declared:
            if isinstance(item, str):
                out.append({"key": item, "label": item, "direction": "maximize", "kind": "auto"})
            elif isinstance(item, dict) and isinstance(item.get("key"), str):
                out.append({"key": item["key"], "label": str(item.get("label") or item["key"]), "direction": item.get("direction") if item.get("direction") in {"maximize", "minimize"} else "maximize", "kind": item.get("kind", "auto")})
        return out
    return []


def _metric_summary(rows: list[dict[str, Any]], key: str, kind: str) -> dict[str, Any]:
    values = [row.get(key) for row in rows]
    booleans = [_as_bool(value) for value in values]
    known_boolean = [value for value in booleans if value is not None]
    numbers = [value for value in values if isinstance(value, (int, float)) and not isinstance(value, bool)]
    use_boolean = kind == "boolean" or (kind == "auto" and known_boolean)
    if use_boolean:
        return {"kind": "boolean", "n": len(known_boolean), "unknown": len(values) - len(known_boolean), "value": (sum(known_boolean) / len(known_boolean)) if known_boolean else None}
    return {"kind": "number", "n": len(numbers), "unknown": len(values) - len(numbers), "value": (sum(numbers) / len(numbers)) if numbers else None}


def comparison_for(name: str, directory: str | None = None, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build a declared, paired comparison; heuristic data stays exploratory."""
    directory = directory or resolve("experiments", name)
    manifest = manifest if manifest is not None else _read_manifest(directory)
    base = {"schema": manifest.get("schema") if isinstance(manifest, dict) else None, "status": "unavailable", "name": name, "arms": [], "match_keys": [], "metrics": [], "pairs": [], "discordant": [], "excluded": [], "warnings": []}
    if not isinstance(manifest, dict) or manifest.get("schema") != "stateframe.experiment.v1":
        base["warnings"] = ["A versioned stateframe.experiment.v1 manifest is required for a defensible comparison."]
        return base
    records, source_name, warnings = _case_records(directory, manifest)
    arm_key = manifest.get("arm_key") if isinstance(manifest.get("arm_key"), str) else next((key for key in _ARM_KEYS if any(isinstance(row, dict) and key in row for row in records)), "arm")
    arms = _comparison_arms(manifest, records, arm_key)
    arm_ids = [arm["id"] for arm in arms]
    match_keys = [key for key in manifest.get("match_keys", []) if isinstance(key, str)]
    if not match_keys:
        warnings.append("match_keys are required to establish paired cases")
    if len(arm_ids) != 2:
        warnings.append("exactly two declared arms are required for paired comparison")
    groups: dict[tuple[str, ...], list[dict[str, Any]]] = {}
    for index, row in enumerate(records):
        if not isinstance(row, dict):
            base["excluded"].append({"index": index, "reason": "invalid_record"})
            continue
        missing = [key for key in match_keys + [arm_key] if row.get(key) in (None, "")]
        if missing:
            base["excluded"].append({"index": index, "reason": "missing_key", "keys": missing})
            continue
        groups.setdefault(tuple(str(row[key]) for key in match_keys), []).append(row)
    pairs = []
    for match, rows in sorted(groups.items()):
        by_arm: dict[str, list[dict[str, Any]]] = {}
        for row in rows:
            by_arm.setdefault(str(row[arm_key]), []).append(row)
        if any(len(by_arm.get(arm_id, [])) != 1 for arm_id in arm_ids):
            base["excluded"].append({"match": dict(zip(match_keys, match)), "reason": "missing_or_duplicate_arm"})
            continue
        pair = {"match": dict(zip(match_keys, match)), "cases": {arm_id: by_arm[arm_id][0] for arm_id in arm_ids}}
        pair["run_links"] = {arm_id: find_run_links(by_arm[arm_id][0]) for arm_id in arm_ids}
        pairs.append(pair)
    metric_defs = _comparison_metric_defs(manifest, records)
    if not metric_defs:
        warnings.append("No declared metrics are available")
    metric_summaries = []
    for definition in metric_defs:
        arms_summary = {arm_id: _metric_summary([pair["cases"][arm_id] for pair in pairs], definition["key"], definition["kind"]) for arm_id in arm_ids}
        left = arms_summary.get(arm_ids[0], {}).get("value") if arm_ids else None
        right = arms_summary.get(arm_ids[1], {}).get("value") if len(arm_ids) > 1 else None
        delta = right - left if isinstance(left, (int, float)) and isinstance(right, (int, float)) else None
        better = None
        if delta is not None and delta != 0:
            better = arm_ids[1] if (delta > 0) == (definition["direction"] == "maximize") else arm_ids[0]
        metric_summaries.append({**definition, "arms": arms_summary, "delta": delta, "better_arm": better})
    primary_key = metric_defs[0]["key"] if metric_defs else None
    discordant = []
    if primary_key and len(arm_ids) == 2:
        for pair in pairs:
            left = _as_bool(pair["cases"][arm_ids[0]].get(primary_key))
            right = _as_bool(pair["cases"][arm_ids[1]].get(primary_key))
            if left is not None and right is not None and left != right:
                discordant.append(pair)
    base.update({"status": "ready" if len(arm_ids) == 2 and bool(match_keys) and bool(pairs) and bool(metric_summaries) else "partial",
                 "source": {"file": source_name, "schema": manifest.get("schema")}, "arm_key": arm_key,
                 "arms": arms, "match_keys": match_keys, "metrics": metric_summaries,
                 "pairs": pairs[:200], "discordant": discordant[:50], "sample_size": len(records),
                 "paired_count": len(pairs), "excluded_count": len(base["excluded"]), "warnings": warnings})
    return base


# ------------------------------------------------------------------ analysis
def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


_PASS_WORDS = {"pass", "passed", "fixed", "true", "yes", "ok", "success", "green", "valid", "correct", "hit"}
_FAIL_WORDS = {"fail", "failed", "not_fixed", "false", "no", "error", "red", "invalid", "incorrect", "miss"}
_ARM_KEYS = ("arm", "variant", "condition", "mode", "policy", "treatment")


def _as_bool(v: Any) -> bool | None:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip().lower()
        if s in _PASS_WORDS:
            return True
        if s in _FAIL_WORDS:
            return False
    return None


def find_record_arrays(obj: Any, path: str = "", depth: int = 0, out: list | None = None) -> list[dict[str, Any]]:
    out = [] if out is None else out
    if depth > 4 or len(out) > 40:
        return out
    if isinstance(obj, list):
        dicts = [x for x in obj if isinstance(x, dict)]
        if dicts and len(dicts) >= max(1, len(obj) // 2):
            out.append({"pointer": path, "length": len(obj)})
            return out
        for i, x in enumerate(obj[:50]):
            find_record_arrays(x, f"{path}/{i}", depth + 1, out)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            find_record_arrays(v, f"{path}/{_esc(str(k))}", depth + 1, out)
    return out


def _esc(k: str) -> str:
    return k.replace("~", "~0").replace("/", "~1")


def get_pointer(obj: Any, pointer: str) -> Any:
    if pointer == "":
        return obj
    if not pointer.startswith("/"):
        raise KeyError(pointer)
    for raw in pointer[1:].split("/"):
        k = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(obj, list):
            if not re.fullmatch(r"0|[1-9][0-9]*", k):
                raise KeyError(pointer)
            index = int(k)
            if index >= len(obj):
                raise IndexError(pointer)
            obj = obj[index]
        elif isinstance(obj, dict):
            obj = obj[k]
        else:
            raise KeyError(pointer)
    return obj


def _declared_metrics(manifest: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    if not isinstance(manifest, dict) or not isinstance(manifest.get("metrics"), list):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for item in manifest["metrics"]:
        if isinstance(item, str):
            out[item] = {"key": item, "label": item, "direction": "maximize"}
        elif isinstance(item, dict) and isinstance(item.get("key"), str):
            out[item["key"]] = {
                "key": item["key"],
                "label": item.get("label") or item["key"],
                "direction": item.get("direction") if item.get("direction") in ("maximize", "minimize") else "maximize",
            }
    return out


def _metric_candidate(name: str, values: list[Any], arm_key: str | None) -> bool:
    if name == arm_key or not values:
        return False
    lowered = name.lower()
    if any(token in lowered for token in ("timed_out", "timeout", "error", "exit_code", "status", "duration", "latency")):
        return False
    known = [_as_bool(value) for value in values]
    return any(value is not None for value in known) and sum(value is not None for value in known) >= max(1, 0.5 * len(values))


def analyze_records(records: list[Any], manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    dicts = [r for r in records if isinstance(r, dict) and r.get("schema_status") not in {"invalid_json", "invalid_record"}]
    cols: dict[str, int] = {}
    for r in dicts:
        for k, v in r.items():
            if isinstance(v, (str, int, float, bool)) or v is None:
                cols[k] = cols.get(k, 0) + 1
    columns = [k for k, _ in sorted(cols.items(), key=lambda kv: -kv[1])][:24]
    arm_key = next((k for k in _ARM_KEYS if k in cols), None)
    metrics: list[dict[str, Any]] = []
    declared = _declared_metrics(manifest)
    bool_fields = list(declared)
    for k in columns:
        vals = [_as_bool(r.get(k)) for r in dicts if k in r]
        if not declared and _metric_candidate(k, vals, arm_key):
            bool_fields.append(k)
    groups: dict[str, list[dict[str, Any]]] = {}
    for r in dicts:
        arm = str(r.get(arm_key)) if arm_key and r.get(arm_key) is not None else "all"
        groups.setdefault(arm, []).append(r)
    for arm, rows in groups.items():
        for f in bool_fields:
            vals = [_as_bool(r.get(f)) for r in rows]
            known = [v for v in vals if v is not None]
            k = sum(1 for v in known if v)
            lo, hi = wilson(k, len(known))
            definition = declared.get(f, {"label": f, "direction": "maximize"})
            metrics.append({
                "arm": arm, "field": f, "label": definition["label"], "direction": definition["direction"],
                "k": k, "n": len(known), "eligible": len(known), "unknown": len(vals) - len(known),
                "rate": (k / len(known)) if known else None,
                "ci95": [round(lo, 4), round(hi, 4)] if known else None,
            })
    categorical = {}
    for k in columns:
        vals = [r.get(k) for r in dicts if isinstance(r.get(k), str)]
        uniq = set(vals)
        if vals and 1 < len(uniq) <= 12 and k not in bool_fields:
            counts: dict[str, dict[str, int]] = {}
            for r in dicts:
                if isinstance(r.get(k), str):
                    a = str(r.get(arm_key)) if arm_key and r.get(arm_key) is not None else "all"
                    counts.setdefault(a, {})[r[k]] = counts.setdefault(a, {}).get(r[k], 0) + 1
            categorical[k] = counts
    return {
        "scope": "dataset",
        "columns": columns,
        "arm_key": arm_key,
        "metrics": metrics,
        "categorical": categorical,
        "n": len(records),
        "valid_records": len(dicts),
        "invalid_records": len(records) - len(dicts),
        "excluded_records": len(records) - len(dicts),
        "declared": bool(declared),
        "manifest_schema": manifest.get("schema") if isinstance(manifest, dict) else None,
    }


# ---------------------------------------------------------------- run links
_link_cache = TTLCache(120)


def _run_ids() -> set[str]:
    return _link_cache.get_or(("ids", source_generation()), lambda: set(discover()))


def find_run_links(record: Any) -> list[str]:
    try:
        s = json.dumps(record)
    except (TypeError, ValueError):
        return []
    ids = _run_ids()
    out = []
    for run_id in sorted(ids, key=len, reverse=True):
        if run_id in s and run_id not in out:
            out.append(run_id)
    return out[:5]
