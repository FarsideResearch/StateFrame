"""Shared bounded-read, Markdown-table, and cache helpers.

The Markdown table extractor intentionally implements a small, documented
pipe-table contract rather than pretending to be a second Markdown renderer.
It accepts GitHub-style header/separator tables, skips fenced code examples,
and normalizes the inline syntax that the table view can represent. Unsupported
Markdown constructs remain in their source form so extracted evidence is never
silently invented.
"""
from __future__ import annotations

import json
import os
import re
import stat
import threading
import time
from typing import Any, Callable

MAX_SMALL_JSON = 4 * 1024 * 1024


def open_regular(path: str, mode: str = "rb", **kwargs):
    """Open one regular file without following a final symlink replacement."""
    info = os.lstat(path)
    if not stat.S_ISREG(info.st_mode):
        raise OSError("not a regular file")
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        final = os.fstat(fd)
        if not stat.S_ISREG(final.st_mode):
            raise OSError("not a regular file")
        return os.fdopen(fd, mode, **kwargs)
    except Exception:
        os.close(fd)
        raise


def read_json(path: str, max_bytes: int = MAX_SMALL_JSON) -> Any:
    """Read a JSON file if it exists and is small enough; None otherwise."""
    try:
        if not stat.S_ISREG(os.lstat(path).st_mode) or os.path.getsize(path) > max_bytes:
            return None
        with open_regular(path, "r", encoding="utf-8", errors="replace") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None


def read_text(path: str, max_bytes: int = 8 * 1024 * 1024, tail: bool = False) -> tuple[str, bool]:
    """Return (text, truncated)."""
    size = os.path.getsize(path)
    with open_regular(path, "rb") as fh:
        if size > max_bytes:
            if tail:
                fh.seek(size - max_bytes)
            data = fh.read(max_bytes)
            return data.decode("utf-8", "replace"), True
        return fh.read().decode("utf-8", "replace"), False


_ROW_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def _split_row(line: str) -> list[str]:
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    trailing_backslashes = 0
    for ch in reversed(s[:-1]):
        if ch != "\\":
            break
        trailing_backslashes += 1
    if s.endswith("|") and trailing_backslashes % 2 == 0:
        s = s[:-1]
    cells, cur = [], []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch == "\\" and i + 1 < len(s) and s[i + 1] in ("|", "\\"):
            cur.append(s[i + 1])
            i += 2
            continue
        if ch == "|":
            cells.append(_normalize_table_cell("".join(cur)))
            cur = []
        else:
            cur.append(ch)
        i += 1
    cells.append(_normalize_table_cell("".join(cur)))
    return cells


_INLINE_CODE = re.compile(r"(?<!\\)(`+)(.+?)(?<!\\)\1")
_STRONG = re.compile(r"(?<!\\)(\*\*|__)(.+?)(?<!\\)\1")
_EMPHASIS = re.compile(r"(?<![\\\w])(\*|_)([^*_\n]+?)(?<!\\)\1(?!\w)")


def _normalize_table_cell(value: str) -> str:
    """Return the visible subset supported by the extracted-table view.

    Escaped pipes/backslashes and simple inline code/emphasis are normalized;
    links, HTML, nested formatting, and extensions remain source text because
    this helper is not a full CommonMark parser.
    """
    cell = value.strip()
    cell = _INLINE_CODE.sub(lambda match: match.group(2), cell)
    cell = _STRONG.sub(lambda match: match.group(2), cell)
    cell = _EMPHASIS.sub(lambda match: match.group(2), cell)
    return cell


def _fence_marker(line: str) -> tuple[str, int] | None:
    """Return a CommonMark-style fence marker for up to three spaces indent."""
    stripped = line.lstrip(" ")
    if len(line) - len(stripped) > 3 or not stripped:
        return None
    marker = stripped[0]
    if marker not in ("`", "~"):
        return None
    length = len(stripped) - len(stripped.lstrip(marker))
    return (marker, length) if length >= 3 else None


def _is_fence_close(line: str, marker: tuple[str, int]) -> bool:
    stripped = line.lstrip(" ")
    char, length = marker
    if len(line) - len(stripped) > 3 or not stripped.startswith(char * length):
        return False
    return not stripped[length:].strip(char + " ")


def parse_md_tables(md: str) -> list[dict[str, Any]]:
    """Extract supported pipe tables with their nearest preceding heading.

    Contract: the header and the immediately following separator must be
    outside a fenced code block; data rows continue while they contain a pipe.
    The returned ``line`` is one-based and cells contain normalized visible
    text for escaped pipes, inline code, and simple emphasis. Links, HTML,
    nested formatting, alignment details, and other Markdown extensions are
    intentionally unsupported and remain source text where applicable.
    """
    tables: list[dict[str, Any]] = []
    lines = md.splitlines()
    heading = ""
    fence: tuple[str, int] | None = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if fence is not None:
            if _is_fence_close(line, fence):
                fence = None
            i += 1
            continue
        marker = _fence_marker(line)
        if marker is not None:
            fence = marker
            i += 1
            continue
        if line.startswith("#"):
            heading = line.lstrip("#").strip()
        if "|" in line and i + 1 < len(lines) and _ROW_SEP.match(lines[i + 1]):
            header = _split_row(line)
            rows = []
            j = i + 2
            while j < len(lines) and "|" in lines[j] and lines[j].strip():
                rows.append(_split_row(lines[j]))
                j += 1
            tables.append({"heading": heading, "header": header, "rows": rows, "line": i + 1})
            i = j
            continue
        i += 1
    return tables


class TTLCache:
    """Thread-safe LRU/TTL cache with byte and duplicate-build bounds.

    ``get_or`` is deliberately single-flight per key: concurrent HTTP requests
    for one expensive source share the same build instead of multiplying parse
    work.  Entries are evicted by age, entry count, or estimated weight.
    """

    def __init__(
        self,
        ttl: float,
        max_entries: int = 64,
        byte_cap: int | None = 32 * 1024 * 1024,
        weight_fn: Callable[[Any], int] | None = None,
    ):
        self.ttl = max(0.0, ttl)
        self.max_entries = max(1, max_entries)
        self.byte_cap = byte_cap
        self.weight_fn = weight_fn or self._default_weight
        self.data: dict[Any, tuple[float, float, Any, int]] = {}
        self.inflight: dict[Any, threading.Event] = {}
        self.lock = threading.Lock()

    @staticmethod
    def _default_weight(value: Any) -> int:
        if isinstance(value, (str, bytes, bytearray)):
            return len(value)
        if isinstance(value, (list, tuple, dict, set)):
            return min(32 * 1024 * 1024, max(1, len(value) * 128))
        return 1

    def _evict_locked(self, now: float) -> None:
        expired = [key for key, (created, _, _, _) in self.data.items() if now - created >= self.ttl]
        for key in expired:
            self.data.pop(key, None)
        while len(self.data) > self.max_entries or (
            self.byte_cap is not None and sum(item[3] for item in self.data.values()) > self.byte_cap
        ):
            oldest = min(self.data.items(), key=lambda item: item[1][1], default=None)
            if oldest is None:
                break
            self.data.pop(oldest[0], None)

    def get_or(self, key: Any, fn: Callable[[], Any]) -> Any:
        while True:
            now = time.monotonic()
            with self.lock:
                self._evict_locked(now)
                hit = self.data.get(key)
                if hit is not None:
                    self.data[key] = (hit[0], now, hit[2], hit[3])
                    return hit[2]
                waiter = self.inflight.get(key)
                if waiter is None:
                    waiter = threading.Event()
                    self.inflight[key] = waiter
                    break
            waiter.wait()

        try:
            value = fn()
        except BaseException:
            with self.lock:
                self.inflight.pop(key, None)
                waiter.set()
            raise
        weight = max(1, self.weight_fn(value))
        with self.lock:
            self.data[key] = (time.monotonic(), time.monotonic(), value, weight)
            self.inflight.pop(key, None)
            self._evict_locked(time.monotonic())
            waiter.set()
        return value

    def clear(self) -> None:
        with self.lock:
            self.data.clear()

    def stats(self) -> dict[str, int | None]:
        with self.lock:
            return {
                "entries": len(self.data),
                "max_entries": self.max_entries,
                "bytes": sum(item[3] for item in self.data.values()),
                "byte_cap": self.byte_cap,
                "inflight": len(self.inflight),
            }
