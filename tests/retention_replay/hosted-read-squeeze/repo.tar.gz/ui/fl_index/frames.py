"""Frame reconstruction: what the model was sent per request and what it answered.

Joins, per ``request_id``: request_submitted (exact payload), response_received,
selection_decision (included/omitted items + reasons), exposure_composition,
capacity_preflight, request_prepared (overflow), and the nearest preceding
tool_menu_composed.
"""
from __future__ import annotations

import json
from typing import Any

from .journal import Journal
from .schema import object_or_empty, request_payload, response_choice

_JOIN_KINDS = {
    "selection_decision": "selection",
    "exposure_composition": "exposure",
    "capacity_preflight": "capacity",
    "history_decision": "history",
    "latest_exchange_decision": "latest_exchange",
    "thinking_router_classified": "thinking_router",
    "f4_budget_fit": "budget_fit",
    "prompt_compact_applied": "prompt_compact",
}


def _join(d: dict[str, Any], key: str, event_index: int) -> None:
    """Keep first evidence and make duplicate joins visible."""
    if key in d:
        d.setdefault("ambiguous_kinds", []).append(key)
        return
    d[key] = event_index


class AmbiguousRequestError(ValueError):
    """A legacy request id refers to more than one request attempt."""


def _msg_chars(m: dict[str, Any]) -> int:
    c = m.get("content")
    if isinstance(c, str):
        return len(c)
    return len(json.dumps(c)) if c is not None else 0


def _build_request_index(j: Journal) -> tuple[list[dict[str, Any]], dict[str, dict[str, int]]]:
    """Return ordered attempts and per-attempt {kind: event index} joins."""
    reqs: list[dict[str, Any]] = []
    joins: dict[str, dict[str, int]] = {}
    last_menu: int | None = None
    active: dict[str, str] = {}
    pending: dict[str, list[dict[str, Any]]] = {}
    for row in j.rows:
        k, rid = row["kind"], row.get("request_id")
        if k == "tool_menu_composed":
            last_menu = row["i"]
        if not rid:
            continue
        if k == "request_submitted":
            attempt_id = row.get("attempt_id") or f"{rid}@event-{row['i']}"
            active[rid] = attempt_id
            d = joins.setdefault(attempt_id, {})
            _join(d, "request_submitted", row["i"])
            if last_menu is not None:
                d["tool_menu"] = last_menu
            for pending_row in pending.pop(attempt_id, []):
                pending_kind = pending_row["kind"]
                if pending_kind in _JOIN_KINDS:
                    _join(d, _JOIN_KINDS[pending_kind], pending_row["i"])
            reqs.append({"request_id": rid, "attempt_id": attempt_id, "i": row["i"], "step": row.get("step"), "seq": row.get("seq")})
            continue
        attempt_id = row.get("attempt_id") or active.get(rid)
        if not attempt_id or attempt_id not in joins or "request_submitted" not in joins[attempt_id]:
            pending.setdefault(attempt_id or rid, []).append(row)
            continue
        d = joins.setdefault(attempt_id, {})
        if k == "response_received":
            _join(d, "response_received", row["i"])
        elif k == "request_prepared":
            _join(d, "request_prepared", row["i"])
        elif k in _JOIN_KINDS:
            _join(d, _JOIN_KINDS[k], row["i"])
    return reqs, joins


def _request_index(j: Journal) -> tuple[list[dict[str, Any]], dict[str, dict[str, int]]]:
    return j.memo_get_or("request_index", lambda: _build_request_index(j))


def _build_frame_rows(j: Journal) -> list[dict[str, Any]]:
    reqs, joins = _request_index(j)
    out = []
    prev_chars = None
    for n, r in enumerate(reqs):
        ev = j.event(r["i"])
        payload, msgs, tools, schema_status = request_payload(ev.get("payload"))
        chars = sum(_msg_chars(m) for m in msgs if isinstance(m, dict))
        d = joins.get(r["attempt_id"], {})
        row = {
            "n": n,
            "request_id": r["request_id"],
            "attempt_id": r["attempt_id"],
            "event_index": r["i"],
            "step": r.get("step"),
            "messages": len(msgs),
            "tools": len(tools),
            "chars": chars,
            "delta_chars": None if prev_chars is None else chars - prev_chars,
            "roles": [m.get("role") for m in msgs if isinstance(m, dict)],
        }
        if schema_status != "ok":
            row["schema_status"] = schema_status
        if d.get("ambiguous_kinds"):
            row["join_status"] = "ambiguous"
            row["ambiguous_kinds"] = sorted(set(d["ambiguous_kinds"]))
        prev_chars = chars
        if "response_received" in d:
            rrow = j.rows[d["response_received"]]
            row["tokens"] = rrow.get("tokens")
            row["finish"] = rrow.get("finish")
            row["action"] = rrow.get("label")
            row["elapsed_s"] = rrow.get("elapsed_s")
        if "capacity" in d:
            row["prompt_est"] = (j.rows[d["capacity"]].get("tokens") or {}).get("prompt_est")
        out.append(row)
    return out


def list_frames(j: Journal) -> list[dict[str, Any]]:
    """Return the bounded, immutable-in-practice frame summary index."""
    return j.memo_get_or("frame_rows", lambda: _build_frame_rows(j))


def _selection_summary(sel: dict[str, Any]) -> dict[str, Any]:
    view, _ = object_or_empty(sel.get("view"))
    def items(lst):
        res = []
        for it in lst if isinstance(lst, list) else []:
            if not isinstance(it, dict):
                res.append({"item_id": str(it)})
                continue
            txt = it.get("text")
            res.append({
                "item_id": it.get("item_id"),
                "group": it.get("group"),
                "priority": it.get("priority"),
                "action_required": it.get("action_required"),
                "reason": it.get("reason") or it.get("omission_reason") or it.get("why"),
                "chars": len(txt) if isinstance(txt, str) else None,
                "preview": txt[:300] if isinstance(txt, str) else None,
            })
        return res
    return {
        "mode": sel.get("mode"),
        "applied": sel.get("applied"),
        "policy_version": view.get("policy_version"),
        "budget_tokens": view.get("budget_tokens"),
        "margin_reasons": view.get("margin_reasons"),
        "selected": items(view.get("selected")),
        "omitted": items(view.get("omitted")),
    }


def _attempt_for(reqs: list[dict[str, Any]], request_id: str) -> tuple[int, dict[str, Any]]:
    exact = [i for i, row in enumerate(reqs) if row["attempt_id"] == request_id]
    if exact:
        return exact[0], reqs[exact[0]]
    matches = [i for i, row in enumerate(reqs) if row["request_id"] == request_id]
    if not matches:
        raise KeyError(request_id)
    if len(matches) > 1:
        raise AmbiguousRequestError(request_id)
    return matches[0], reqs[matches[0]]


def get_frame(j: Journal, request_id: str) -> dict[str, Any]:
    reqs, joins = _request_index(j)
    pos, request = _attempt_for(reqs, request_id)
    attempt_id = request["attempt_id"]
    d = joins.get(attempt_id)
    if not d or "request_submitted" not in d:
        raise KeyError(request_id)
    sub = j.event(d["request_submitted"])
    payload, messages, tools, schema_status = request_payload(sub.get("payload"))
    order = [r["attempt_id"] for r in reqs]
    frame: dict[str, Any] = {
        "request_id": request["request_id"],
        "attempt_id": attempt_id,
        "n": pos,
        "prev_request_id": order[pos - 1] if pos > 0 else None,
        "next_request_id": order[pos + 1] if pos + 1 < len(order) else None,
        "step": sub.get("step"),
        "event_index": d["request_submitted"],
        "messages": messages,
        "tools": tools,
        "request_payload": payload,
        "params": {k: v for k, v in payload.items() if k not in ("messages", "tools")},
        "backend_identity": sub.get("backend_identity"),
        "context_hash": sub.get("context_hash"),
    }
    if schema_status != "ok":
        frame["schema_status"] = schema_status
    if d.get("ambiguous_kinds"):
        frame["join_status"] = "ambiguous"
        frame["ambiguous_kinds"] = sorted(set(d["ambiguous_kinds"]))
    frame["chars"] = sum(_msg_chars(m) for m in messages if isinstance(m, dict))
    tool_names: list[str] = []
    for tool in frame["tools"]:
        if not isinstance(tool, dict):
            continue
        function, _ = object_or_empty(tool.get("function"))
        name = function.get("name") or tool.get("name")
        if name is not None:
            tool_names.append(str(name))
    frame["tool_names"] = tool_names
    if "response_received" in d:
        rev = j.event(d["response_received"])
        choice, response_status = response_choice(rev.get("response"))
        accounting, _ = object_or_empty(rev.get("accounting"))
        message = choice.get("message") if choice else None
        frame["response"] = {
            "event_index": d["response_received"],
            "message": message if isinstance(message, dict) else None,
            "finish_reason": choice.get("finish_reason") if choice else None,
            "accounting": accounting or None,
            "logical_token_accounting": rev.get("logical_token_accounting"),
            "elapsed_s": round(rev["elapsed_ns"] / 1e9, 2) if isinstance(rev.get("elapsed_ns"), (int, float)) else None,
            "schema_status": response_status,
        }
    if "selection" in d:
        selection_event = j.event(d["selection"])
        frame["selection"] = _selection_summary(selection_event)
        frame["selection"]["event_index"] = d["selection"]
        frame["selection_source"] = {"event_index": d["selection"], "event": selection_event}
    for k in ("exposure", "capacity", "history", "latest_exchange", "thinking_router", "budget_fit", "prompt_compact"):
        if k in d:
            ev = dict(j.event(d[k]))
            for drop in ("previous_hash", "record_hash", "journal_format", "schema", "run_id", "task_id"):
                ev.pop(drop, None)
            frame[k] = ev
    if "request_prepared" in d:
        prep = j.event(d["request_prepared"])
        frame["overflow"] = prep.get("overflow")
        frame["renderer_version"] = prep.get("renderer_version")
    if "tool_menu" in d:
        menu = j.event(d["tool_menu"])
        frame["tool_menu"] = {"event_index": d["tool_menu"], "available_tools": menu.get("available_tools"), "stages": menu.get("stages"), "schema_status": "ok" if isinstance(menu, dict) else "invalid_object"}
    return frame
