"""Small, conservative adapters for model-generated artifact shapes.

The viewer must keep raw evidence inspectable without allowing one unexpected
JSON shape to break an entire journal or page. These helpers deliberately do
not invent missing values; they mark unsupported values instead.
"""
from __future__ import annotations

from typing import Any


def object_or_empty(value: Any) -> tuple[dict[str, Any], str]:
    if isinstance(value, dict):
        return value, "ok"
    return {}, "invalid_object"


def list_or_empty(value: Any) -> tuple[list[Any], str]:
    if isinstance(value, list):
        return value, "ok"
    return [], "invalid_array"


def event_object(value: Any, raw: str | None = None) -> dict[str, Any]:
    """Return an object envelope for every journal line value."""
    if isinstance(value, dict):
        return value
    result: dict[str, Any] = {
        "kind": "non_object",
        "schema_status": "invalid_event",
        "value": value,
    }
    if raw is not None:
        result["raw"] = raw[:20000]
    return result


def normalize_messages(value: Any) -> tuple[list[dict[str, Any]], str]:
    messages, status = list_or_empty(value)
    if status != "ok":
        return [], status
    out: list[dict[str, Any]] = []
    invalid = False
    for index, message in enumerate(messages):
        if isinstance(message, dict):
            item = dict(message)
            if not isinstance(item.get("role"), str):
                item["role"] = "unknown"
                item.setdefault("schema_status", "invalid_message_role")
                invalid = True
            out.append(item)
        else:
            out.append({
                "role": "unknown",
                "content": message,
                "schema_status": "invalid_message",
                "index": index,
            })
            invalid = True
    return out, "invalid_items" if invalid else "ok"


def normalize_tools(value: Any) -> tuple[list[dict[str, Any]], str]:
    tools, status = list_or_empty(value)
    if status != "ok":
        return [], status
    out: list[dict[str, Any]] = []
    invalid = False
    for index, tool in enumerate(tools):
        if isinstance(tool, dict):
            out.append(dict(tool))
        else:
            out.append({"name": "unknown", "value": tool, "schema_status": "invalid_tool", "index": index})
            invalid = True
    return out, "invalid_items" if invalid else "ok"


def request_payload(value: Any) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]], str]:
    payload, status = object_or_empty(value)
    if status != "ok":
        return {"value": value, "schema_status": status}, [], [], status
    messages, message_status = normalize_messages(payload.get("messages", []))
    tools, tool_status = normalize_tools(payload.get("tools", []))
    if message_status != "ok" or tool_status != "ok":
        status = "invalid_fields"
    return payload, messages, tools, status


def response_choice(value: Any) -> tuple[dict[str, Any] | None, str]:
    response, status = object_or_empty(value)
    if status != "ok":
        return None, status
    choices, choice_status = list_or_empty(response.get("choices", []))
    if choice_status != "ok":
        return None, choice_status
    if not choices:
        return None, "missing_choice"
    choice = choices[0]
    if not isinstance(choice, dict):
        return None, "invalid_choice"
    return choice, "ok"

