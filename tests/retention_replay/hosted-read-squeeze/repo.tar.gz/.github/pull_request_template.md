## Summary

What changed and why?

## Tests run

- [ ] `python3 -B -m unittest tests.test_framelab`
- [ ] `(cd ui && python3 -B -m unittest discover -s tests -t .)`
- [ ] `(cd ui/web && npm test)`
- [ ] `bash scripts/check.sh`
- [ ] Not run (explain why):

## Contributor License Agreement

- [ ] I have read and signed the Contributor License Agreement in [CLA.md](../CLA.md).
