---
name: Bug report
about: Report a problem with Frame Lab
title: "[Bug] "
labels: []
assignees: []
---

## What happened?

Describe the problem and what you expected to happen.

## Steps to reproduce

1. First step:
2. Next step:
3. Expected result:

## Command and error

Paste the command and the error message. Remove secrets and private task data first.

## Environment

- Frame Lab version:
- Python version:
- Operating system:
