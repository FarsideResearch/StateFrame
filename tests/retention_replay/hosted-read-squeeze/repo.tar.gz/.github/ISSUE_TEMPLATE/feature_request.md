---
name: Feature request
about: Suggest a change to Frame Lab
title: "[Feature] "
labels: []
assignees: []
---

## What problem should this solve?

Describe the task you are trying to do and where the current workflow falls short.

## What would you like Frame Lab to do?

Describe the change and how you would use it.

## Other approaches considered

Add any alternatives or relevant context.
