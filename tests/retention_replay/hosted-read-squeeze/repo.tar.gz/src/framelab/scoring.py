"""Normalize the first action of a chat completion and score it against a target."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Mapping, Sequence

from . import FrameLabError
from .jsonutil import load_document

SCORER_SCHEMA = "framelab/scorer/1"
SHORT_TEXT = 280
_TARGET_KEYS = frozenset({
    "tool", "tools", "arguments", "argument_path", "selector_in", "argument_contains",
    "argument_any_contains", "text_contains", "kind",
})


def first_action(response: Mapping[str, object] | None) -> dict[str, object] | None:
    """The first tool call (name and parsed arguments) or the plain text reply. Nothing is executed."""
    if not isinstance(response, Mapping):
        return None
    choices = response.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], Mapping):
        return None
    message = choices[0].get("message")
    if not isinstance(message, Mapping):
        return None
    content = message.get("content")
    text = content[:SHORT_TEXT] if isinstance(content, str) else ""
    calls = message.get("tool_calls")
    if isinstance(calls, list) and calls and isinstance(calls[0], Mapping):
        function = calls[0].get("function")
        if isinstance(function, Mapping):
            arguments: object = function.get("arguments", "")
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    pass  # keep the raw string; an unparsable argument string is itself an observation
            return {"kind": "tool_call", "tool": function.get("name"), "arguments": arguments, "text": text,
                    "tool_calls": len(calls)}
    return {"kind": "content", "tool": None, "arguments": None, "text": text, "tool_calls": 0}


def finish_reason(response: Mapping[str, object] | None) -> str | None:
    if not isinstance(response, Mapping):
        return None
    choices = response.get("choices")
    if isinstance(choices, list) and choices and isinstance(choices[0], Mapping):
        reason = choices[0].get("finish_reason")
        return reason if isinstance(reason, str) else None
    return None


def usage(response: Mapping[str, object] | None) -> dict[str, int | None]:
    raw = response.get("usage") if isinstance(response, Mapping) else None
    raw = raw if isinstance(raw, Mapping) else {}
    return {key: raw.get(key) if type(raw.get(key)) is int else None
            for key in ("prompt_tokens", "completion_tokens", "total_tokens")}


def _strings(value: object) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, Mapping):
        return [s for child in value.values() for s in _strings(child)]
    if isinstance(value, list):
        return [s for child in value for s in _strings(child)]
    return []


def _at_path(value: object, path: Sequence[object]) -> object | None:
    for part in path:
        if isinstance(value, Mapping) and part in value:
            value = value[part]
        elif isinstance(value, list) and type(part) is int and 0 <= part < len(value):
            value = value[part]
        else:
            return None
    return value


def validate_target(target: Mapping[str, object]) -> None:
    unknown = set(target) - _TARGET_KEYS
    if unknown:
        raise FrameLabError(f"scorer target has unknown keys: {sorted(unknown)}")
    if target.get("kind") not in (None, "tool_call", "content"):
        raise FrameLabError("scorer target.kind must be tool_call or content")
    if "selector_in" in target and (not isinstance(target.get("argument_path"), list) or not isinstance(target["selector_in"], list)):
        raise FrameLabError("scorer selector_in needs an argument_path list and a list of allowed values")
    for key in ("argument_contains", "argument_any_contains"):
        if key in target and (not isinstance(target[key], list) or not all(isinstance(s, str) for s in target[key])):
            raise FrameLabError(f"scorer {key} must be a list of strings")
    if "tools" in target and (not isinstance(target["tools"], list) or not target["tools"]):
        raise FrameLabError("scorer tools must be a non-empty list of tool names")
    if "text_contains" in target and not isinstance(target["text_contains"], str):
        raise FrameLabError("scorer text_contains must be a string")


def score(action: Mapping[str, object] | None, target: Mapping[str, object]) -> bool:
    """True when the first action meets every condition the target states."""
    if not isinstance(action, Mapping):
        return False
    kind = target.get("kind", "content" if "text_contains" in target and not ("tool" in target or "tools" in target) else "tool_call")
    if action.get("kind") != kind:
        return False
    if "text_contains" in target and target["text_contains"] not in str(action.get("text") or ""):
        return False
    if kind == "content":
        return True
    accepted = target.get("tools") if "tools" in target else ([target["tool"]] if "tool" in target else None)
    if accepted is not None and action.get("tool") not in accepted:
        return False
    arguments = action.get("arguments")
    if "arguments" in target and arguments != target["arguments"]:
        return False
    if "selector_in" in target and _at_path(arguments, target["argument_path"]) not in target["selector_in"]:
        return False
    strings = _strings(arguments)
    if "argument_contains" in target and not all(any(n in s for s in strings) for n in target["argument_contains"]):
        return False
    if "argument_any_contains" in target and not any(any(n in s for s in strings) for n in target["argument_any_contains"]):
        return False
    return True


def load_scorer(path: Path) -> dict[str, object]:
    scorer = dict(load_document(Path(path), "scorer file"))
    if scorer.get("schema") != SCORER_SCHEMA:
        raise FrameLabError(f"scorer schema must be {SCORER_SCHEMA!r}")
    target = scorer.get("target")
    if not isinstance(target, Mapping):
        raise FrameLabError("scorer file needs a 'target' object")
    validate_target(target)
    return scorer
