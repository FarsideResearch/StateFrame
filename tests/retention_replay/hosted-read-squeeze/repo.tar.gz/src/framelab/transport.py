"""Send one chat-completions request to an OpenAI-compatible endpoint (stdlib only).

The endpoint defaults to ``STATEFRAME_ENDPOINT``, the same variable the engine reads. Frame Lab
talks to loopback servers unless ``--allow-remote`` is given, because a variant can carry the
recorded task and repository text. An optional bearer key comes from ``FRAMELAB_API_KEY`` and is
never written to results, logs or error messages.
"""
from __future__ import annotations

import ipaddress
import json
import os
import time
import urllib.error
import urllib.request
from typing import Mapping
from urllib.parse import urlparse

from . import FrameLabError

API_KEY_ENV = "FRAMELAB_API_KEY"
ENDPOINT_ENV = "STATEFRAME_ENDPOINT"
_ERROR_DETAIL = 240


def chat_url(endpoint: str | None) -> str:
    raw = (endpoint or os.environ.get(ENDPOINT_ENV) or "").strip()
    if not raw:
        raise FrameLabError(f"no endpoint: pass --endpoint or set {ENDPOINT_ENV} (for example http://127.0.0.1:8080/v1)")
    parsed = urlparse(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise FrameLabError(f"endpoint must be an http(s) URL, got {raw!r}")
    if parsed.username or parsed.password:
        raise FrameLabError("endpoint URL must not embed credentials; use the FRAMELAB_API_KEY variable")
    path = parsed.path.rstrip("/")
    if not path.endswith("/chat/completions"):
        path += "/chat/completions"
    return parsed._replace(path=path, query="", fragment="").geturl()


def is_loopback(url: str) -> bool:
    host = urlparse(url).hostname or ""
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def require_allowed(url: str, allow_remote: bool) -> None:
    if not allow_remote and not is_loopback(url):
        raise FrameLabError(
            f"refusing non-loopback endpoint {urlparse(url).hostname!r}: variants carry your task and code text; "
            "pass --allow-remote to send them there deliberately")


def apply_seed(body: Mapping[str, object], mode: str, sample_index: int) -> dict[str, object]:
    """``keep`` sends the recorded seed; ``vary`` derives a distinct, reproducible seed per sample."""
    if mode not in {"keep", "vary"}:
        raise FrameLabError("seed mode must be keep or vary")
    out = dict(body)
    if mode == "vary" and "seed" in out:
        base = out["seed"] if type(out["seed"]) is int else 0
        out["seed"] = (base + 1 + sample_index) & 0x7FFFFFFF
    return out


def apply_slot(body: Mapping[str, object], mode: str) -> dict[str, object]:
    """``free`` drops a recorded llama.cpp ``id_slot`` so the server picks any idle slot."""
    if mode not in {"free", "keep"}:
        raise FrameLabError("slot mode must be free or keep")
    out = dict(body)
    if mode == "free":
        out.pop("id_slot", None)
    return out


def wire_bytes(body: Mapping[str, object]) -> bytes:
    """The engine's own wire serialization (``json.dumps(body)``), so hashes compare across tools."""
    return json.dumps(dict(body)).encode("utf-8")


def send_once(body: Mapping[str, object], url: str, *, timeout_s: float) -> dict[str, object]:
    """POST one body. Transport and HTTP failures are returned as an outcome, never raised."""
    if not timeout_s or timeout_s <= 0:
        raise FrameLabError("timeout must be a positive number of seconds")
    headers = {"Content-Type": "application/json"}
    key = os.environ.get(API_KEY_ENV)
    if key:
        headers["Authorization"] = f"Bearer {key}"
    request = urllib.request.Request(url, data=wire_bytes(body), method="POST", headers=headers)
    started = time.monotonic_ns()
    try:
        with urllib.request.urlopen(request, timeout=timeout_s) as reply:
            raw = reply.read()
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", "replace")
        except OSError:
            detail = ""
        if key:
            detail = detail.replace(key, "[redacted]")
        return {"error": f"http {exc.code}: {detail[:_ERROR_DETAIL]}", "elapsed_ns": time.monotonic_ns() - started}
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        reason = getattr(exc, "reason", exc)
        return {"error": f"transport: {type(reason).__name__}", "elapsed_ns": time.monotonic_ns() - started}
    elapsed = time.monotonic_ns() - started
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"error": "response is not JSON", "elapsed_ns": elapsed}
    if not isinstance(parsed, dict):
        return {"error": "response is not a JSON object", "elapsed_ns": elapsed}
    return {"response": parsed, "elapsed_ns": elapsed}
