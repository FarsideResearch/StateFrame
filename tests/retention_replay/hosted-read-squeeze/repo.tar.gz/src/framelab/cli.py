"""``framelab`` command line: list, extract, validate, run, render, tape, ui."""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Sequence

from . import FrameLabError, __version__
from .experiment import DEFAULT_MAX_REQUESTS, execute, extract_base, load_base, render_markdown
from .journal import find_journal, list_requests, load_journal
from .jsonutil import load_document, write_json, write_text
from .scoring import load_scorer
from .tape import check, load_tape, parity, serve
from .transport import chat_url
from .variants import apply_variant, load_variants, variant_name


def _requests(args: argparse.Namespace) -> int:
    rows = list_requests(load_journal(Path(args.run)))
    if args.json:
        print(json.dumps(rows, indent=2))
        return 0
    print(f"{'step':>5} {'seq':>6} {'msgs':>5} {'tools':>5} {'bytes':>8}  request id")
    for row in rows:
        print(f"{row['step'] if row['step'] is not None else '-':>5} {row['sequence']:>6} {row['messages'] or '-':>5} "
              f"{row['tools'] or '-':>5} {row['wire_bytes'] or '-':>8}  {row['request_id']}")
    return 0


def _extract(args: argparse.Namespace) -> int:
    journal = find_journal(Path(args.run))
    base = extract_base(journal, args.at)
    target = write_json(Path(args.out), base)
    print(f"wrote {target}")
    print(f"request {base['source']['request_id']} at step {base['source']['step']}, "
          f"{base['integrity']['wire_bytes']} bytes, hash verified")
    return 0


def _validate(args: argparse.Namespace) -> int:
    base = load_base(Path(args.base))
    variants = load_variants(Path(args.variants))
    if args.scorer:
        load_scorer(Path(args.scorer))
    for index, variant in enumerate(variants):
        body, audit = apply_variant(base, variant)
        print(f"ok {variant_name(variant, index)}: {len(body.get('messages', []))} messages, "
              f"{len(body.get('tools') or [])} tools; " + ("; ".join(audit) or "no edits"))
        if args.show:
            print(json.dumps(body, indent=2, ensure_ascii=False))
    return 0


def _run(args: argparse.Namespace) -> int:
    base = load_base(Path(args.base))
    variants = load_variants(Path(args.variants))
    scorer = load_scorer(Path(args.scorer))
    result = execute(base, variants, scorer, url=chat_url(args.endpoint), n=args.n, seed_mode=args.seed_mode,
                     slot_mode=args.slot, timeout_s=args.timeout, max_requests=args.max_requests,
                     allow_remote=args.allow_remote, model=args.model or os.environ.get("STATEFRAME_MODEL"),
                     progress=None if args.quiet else (lambda line: print(line, file=sys.stderr)))
    out = Path(args.out)
    write_json(out, result)
    md = write_text(out.with_suffix(".md"), render_markdown(result, args.title))
    print(f"wrote {out.resolve()} and {md}")
    for v in result["variants"]:
        print(f"  {v['name']}: {v['hits']}/{v['n']} hits")
    return 1 if result["transport_errors"] == result["requests"] else 0


def _render(args: argparse.Namespace) -> int:
    result = load_document(Path(args.result), "result file")
    text = render_markdown(result, args.title)
    if args.out:
        print(f"wrote {write_text(Path(args.out), text)}")
    else:
        sys.stdout.write(text)
    return 0


def _tape_check(args: argparse.Namespace) -> int:
    bad = 0
    for path in args.runs:
        try:
            info = check(Path(path))
            print(f"ok {path}: {info['responses']} responses, {info['requests']} requests")
        except FrameLabError as exc:
            print(f"FAIL {path}: {exc}")
            bad += 1
    return 1 if bad else 0


def _tape_parity(args: argparse.Namespace) -> int:
    report = parity(Path(args.candidate), Path(args.baseline))
    print(json.dumps(report, indent=2))
    return 0 if report["first_difference"] is None and report["candidate_requests"] == report["baseline_requests"] else 1


def _tape_serve(args: argparse.Namespace) -> int:
    tapes = []
    for spec in args.tape:
        name, _, path = spec.partition("=")
        if not path:
            name, path = Path(spec).name, spec
        markers = [m.partition("=")[2] for m in args.marker if m.partition("=")[0] == name]
        tapes.append(load_tape(name, Path(path), markers))
    server = serve(tapes, port=args.port, upstream=args.upstream, log_path=Path(args.log), live_after=args.live_after)
    print(json.dumps({"listening": f"http://127.0.0.1:{server.server_address[1]}/v1",
                      "tapes": {t.name: len(t.items) for t in tapes}, "live_after": args.live_after}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


def _ui_root() -> Path:
    return Path(__file__).resolve().parents[2] / "ui"


def _ui(args: argparse.Namespace) -> int:
    root = _ui_root()
    script = root / "start.sh"
    if not script.is_file():
        raise FrameLabError("The Frame Lab UI ships in the source repository. Clone it and run `pip install -e .` "
                            "from the cloned repository.")
    command = ["bash", str(script)] + ([str(args.port)] if args.port else [])
    env = dict(os.environ)
    if args.data:
        env["FRAME_LAB_DATA"] = str(Path(args.data).resolve())
    child = subprocess.Popen(command, env=env, start_new_session=True)
    try:
        return child.wait()
    except KeyboardInterrupt:
        if child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait()
        print("Frame Lab UI stopped.")
        return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="framelab", description="Controlled experiments on recorded StateFrame requests.")
    parser.add_argument("--version", action="version", version=f"framelab {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("requests", help="list the model requests a run sent")
    p.add_argument("run", help="run directory or events.jsonl")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=_requests)

    p = sub.add_parser("extract", help="rebuild one recorded request as a base file")
    p.add_argument("run", help="run directory or events.jsonl")
    p.add_argument("--at", required=True, help="step:N, seq:N, a bare number (step, then sequence) or a request id")
    p.add_argument("--out", required=True)
    p.set_defaults(func=_extract)

    p = sub.add_parser("validate", help="apply every variant offline and report what changed")
    p.add_argument("--base", required=True)
    p.add_argument("--variants", required=True)
    p.add_argument("--scorer")
    p.add_argument("--show", action="store_true", help="print each edited request")
    p.set_defaults(func=_validate)

    p = sub.add_parser("run", help="send variants to an endpoint and score the first response")
    p.add_argument("--base", required=True)
    p.add_argument("--variants", required=True)
    p.add_argument("--scorer", required=True)
    p.add_argument("--out", required=True, help="result JSON path; a Markdown report is written beside it")
    p.add_argument("--endpoint", help="OpenAI-compatible base URL (default: $STATEFRAME_ENDPOINT)")
    p.add_argument("--model", help="override the recorded model name (default: $STATEFRAME_MODEL if set)")
    p.add_argument("--n", type=int, default=3, help="samples per variant (default 3)")
    p.add_argument("--seed-mode", choices=("keep", "vary"), default="vary")
    p.add_argument("--slot", choices=("free", "keep"), default="free")
    p.add_argument("--timeout", type=float, default=600.0, help="seconds per request")
    p.add_argument("--max-requests", type=int, default=DEFAULT_MAX_REQUESTS)
    p.add_argument("--allow-remote", action="store_true", help="permit a non-loopback endpoint")
    p.add_argument("--title")
    p.add_argument("--quiet", action="store_true")
    p.set_defaults(func=_run)

    p = sub.add_parser("render", help="render a result JSON as Markdown")
    p.add_argument("result")
    p.add_argument("--out")
    p.add_argument("--title")
    p.set_defaults(func=_render)

    tape = sub.add_parser("tape", help="replay a recorded run's model responses").add_subparsers(dest="tape_command", required=True)
    p = tape.add_parser("check", help="verify runs can serve as tapes")
    p.add_argument("runs", nargs="+")
    p.set_defaults(func=_tape_check)
    p = tape.add_parser("parity", help="compare the requests two runs sent")
    p.add_argument("candidate")
    p.add_argument("baseline")
    p.set_defaults(func=_tape_parity)
    p = tape.add_parser("serve", help="serve recorded responses as an OpenAI-compatible endpoint")
    p.add_argument("--tape", action="append", required=True, help="NAME=RUN (or just RUN); repeat for several tasks")
    p.add_argument("--marker", action="append", default=[], help="NAME=TEXT routing marker, required with several tapes")
    p.add_argument("--port", type=int, default=8090)
    p.add_argument("--upstream", help="real server for non-chat routes such as /tokenize")
    p.add_argument("--live-after", type=int, help="answer chat requests from index N onward live through --upstream")
    p.add_argument("--log", default="tape-relay.jsonl")
    p.set_defaults(func=_tape_serve)

    p = sub.add_parser("ui", help="start the Frame Lab UI on 127.0.0.1")
    p.add_argument("--data", help="folder of runs/experiments to inspect (default: bundled demo)")
    p.add_argument("--port", type=int)
    p.set_defaults(func=_ui)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except FrameLabError as exc:
        print(f"framelab: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
