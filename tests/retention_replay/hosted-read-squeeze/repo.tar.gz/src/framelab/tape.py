"""Tapes: a recorded run's model responses, replayed so a changed engine can be compared offline.

``framelab tape serve`` runs a small OpenAI-compatible relay. Point a new StateFrame run at it
(``STATEFRAME_ENDPOINT=http://127.0.0.1:<port>/v1``) and every chat request is answered with the
next recorded response of the matching tape, so the engine code runs for real while the model is
held fixed. Other routes (``/tokenize``, ``/props``, ...) go to ``--upstream`` unchanged.

``framelab tape parity`` then compares what the two engines sent, request by request.
"""
from __future__ import annotations

import gzip
import hashlib
import http.client
import http.server
import json
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping, Sequence
from urllib.parse import urlparse

from . import FrameLabError
from .journal import find_journal, load_journal

# Values that differ between two identical runs: 32-hex run ids and handles, 64-hex digests of
# records containing them, pytest wall-clock durations and memory addresses.
_VOLATILE = (
    (re.compile(r"(?<![0-9a-f])(?:[0-9a-f]{64}|[0-9a-f]{32})(?![0-9a-f])"), "<ID>"),
    (re.compile(r" in [0-9]+\.[0-9]+s\b"), " in <T>s"),
    (re.compile(r"\bat 0x[0-9a-fA-F]+"), "at 0x<ADDR>"),
)


def mask_volatile(text: str) -> str:
    for pattern, replacement in _VOLATILE:
        text = pattern.sub(replacement, text)
    return text


def load_responses(journal: Path) -> list[dict[str, object]]:
    """Recorded chat completions in order; each must hydrate to a real completion."""
    responses = []
    for record in load_journal(journal):
        if record.get("kind") != "response_received" or not isinstance(record.get("response"), Mapping):
            continue
        response = record["response"]
        if not isinstance(response.get("choices"), list) or not response["choices"]:
            raise FrameLabError(f"recorded response {len(responses)} is not a chat completion")
        responses.append({"request_id": record.get("request_id"), "response": response})
    return responses


def load_requests(journal: Path) -> list[dict[str, object]]:
    return [{"sequence": r.get("sequence"), "step": r.get("step"), "wire": r["payload_utf8"]}
            for r in load_journal(journal)
            if r.get("kind") == "request_submitted" and isinstance(r.get("payload_utf8"), str)]


def check(journal_or_run: Path) -> dict[str, object]:
    """Can this run serve as a tape? Every blob resolves and at least one response exists."""
    journal = find_journal(Path(journal_or_run))
    responses = load_responses(journal)
    if not responses:
        raise FrameLabError(f"{journal} has no recorded model responses")
    return {"journal": str(journal), "responses": len(responses), "requests": len(load_requests(journal))}


def parity(candidate: Path, baseline: Path) -> dict[str, object]:
    """Compare the requests two runs sent, after masking per-run identifiers."""
    cand, base = load_requests(find_journal(candidate)), load_requests(find_journal(baseline))
    identical, first = 0, None
    for index, (c, b) in enumerate(zip(cand, base)):
        cm, bm = mask_volatile(c["wire"]), mask_volatile(b["wire"])
        if cm == bm:
            identical += 1
            continue
        if first is None:
            first = {"request_index": index, "candidate_step": c["step"], "baseline_step": b["step"],
                     "where": _first_difference(cm, bm), "candidate_bytes": len(cm), "baseline_bytes": len(bm)}
    return {"compared": min(len(cand), len(base)), "identical": identical, "candidate_requests": len(cand),
            "baseline_requests": len(base), "first_difference": first}


def _first_difference(a: str, b: str) -> dict[str, object]:
    try:
        ja, jb = json.loads(a), json.loads(b)
    except json.JSONDecodeError:
        ja = jb = None
    if isinstance(ja, dict) and isinstance(jb, dict):
        for key in sorted(set(ja) | set(jb)):
            if ja.get(key) == jb.get(key):
                continue
            if key == "messages" and isinstance(ja.get(key), list) and isinstance(jb.get(key), list):
                for i, (ma, mb) in enumerate(zip(ja[key], jb[key])):
                    if ma != mb:
                        return {"field": "messages", "message_index": i}
                return {"field": "messages", "message_count": [len(ja[key]), len(jb[key])]}
            return {"field": key}
    offset = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
    return {"char_offset": offset}


@dataclass
class Tape:
    name: str
    items: list[dict[str, object]]
    markers: list[str]
    cursor: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def take(self) -> int:
        with self.lock:
            index = self.cursor
            self.cursor += 1
            return index


def load_tape(name: str, journal_or_run: Path, markers: Sequence[str] = ()) -> Tape:
    journal = find_journal(Path(journal_or_run))
    items = load_responses(journal)
    if not items:
        raise FrameLabError(f"tape {name}: no recorded responses in {journal}")
    return Tape(name, items, [m for m in markers if len(m) >= 6])


def _message_text(body: bytes) -> str:
    try:
        doc = json.loads(body)
    except ValueError:
        return ""
    parts = []
    for message in doc.get("messages") or [] if isinstance(doc, dict) else []:
        content = message.get("content") if isinstance(message, dict) else None
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            parts.extend(str(p.get("text", "")) for p in content if isinstance(p, dict))
    return "\n".join(parts)


def make_handler(tapes: Sequence[Tape], upstream: str | None, log_path: Path, live_after: int | None = None):
    """Build the relay's request handler. Ambiguous or unmatched chat requests fail loudly, never guess."""
    if len(tapes) > 1 and any(not t.markers for t in tapes):
        raise FrameLabError("with several tapes every tape needs a --marker that appears only in its own task text")
    up = urlparse(upstream) if upstream else None
    log_lock = threading.Lock()

    def log(record: dict[str, object]) -> None:
        record["ts_ns"] = time.time_ns()
        with log_lock, open(log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, sort_keys=True) + "\n")

    class Handler(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *_args):
            return

        def _reply(self, status: int, payload, content_type="application/json", encoding=None):
            data = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            if encoding:
                self.send_header("Content-Encoding", encoding)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _forward(self, body: bytes) -> None:
            # Every log line is written before its reply, so a client that reads the log next sees it.
            if up is None:
                log({"kind": "no_upstream", "path": self.path})
                self._reply(502, {"error": "tape relay: no --upstream configured for this route"})
                return
            cls = http.client.HTTPSConnection if up.scheme == "https" else http.client.HTTPConnection
            conn = cls(up.hostname, up.port, timeout=600)
            headers = {k: v for k, v in self.headers.items() if k.lower() not in {"host", "content-length", "connection"}}
            try:
                conn.request(self.command, self.path, body=body or None, headers=headers)
                resp = conn.getresponse()
                data = resp.read()
                log({"kind": "forward", "path": self.path, "status": resp.status, "bytes": len(data)})
                self._reply(resp.status, data, resp.getheader("Content-Type") or "application/json",
                            resp.getheader("Content-Encoding"))
            except OSError as exc:
                log({"kind": "forward_error", "path": self.path, "error": type(exc).__name__})
                self._reply(502, {"error": f"upstream: {type(exc).__name__}"})
            finally:
                conn.close()

        def _chat(self, raw: bytes) -> None:
            body = raw
            if "gzip" in (self.headers.get("Content-Encoding") or "").lower() or raw[:2] == b"\x1f\x8b":
                try:
                    body = gzip.decompress(raw)
                except OSError:
                    pass
            digest = hashlib.sha256(body).hexdigest()
            if len(tapes) == 1:
                matches = list(tapes)
            else:
                text = _message_text(body)
                matches = [t for t in tapes if any(m in text for m in t.markers)]
            if len(matches) != 1:
                log({"kind": "route_error", "matches": [t.name for t in matches], "body_sha256": digest})
                self._reply(500, {"error": f"tape relay: request matches {len(matches)} tapes"})
                return
            tape = matches[0]
            index = tape.take()
            if live_after is not None and index >= live_after:
                log({"kind": "live_forward", "tape": tape.name, "request_index": index, "body_sha256": digest})
                self._forward(raw)
                return
            if index >= len(tape.items):
                log({"kind": "tape_end", "tape": tape.name, "request_index": index, "body_sha256": digest})
                self._reply(503, {"error": "tape relay: tape exhausted"})
                return
            log({"kind": "served", "tape": tape.name, "request_index": index, "body_sha256": digest,
                 "recorded_request_id": tape.items[index]["request_id"]})
            self._reply(200, tape.items[index]["response"])

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            route = self.path.split("?", 1)[0].rstrip("/")
            if route in {"/v1/chat/completions", "/chat/completions"}:
                self._chat(raw)
            else:
                self._forward(raw)

        def do_GET(self):
            self._forward(b"")

    return Handler


def serve(tapes: Sequence[Tape], *, port: int, log_path: Path, upstream: str | None = None, live_after: int | None = None,
          host: str = "127.0.0.1") -> http.server.ThreadingHTTPServer:
    """Create (not start) the relay server; callers run ``serve_forever``."""
    if upstream and urlparse(upstream).scheme not in {"http", "https"}:
        raise FrameLabError("--upstream must be an http(s) URL")
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    return http.server.ThreadingHTTPServer((host, port), make_handler(tapes, upstream, log_path, live_after))
