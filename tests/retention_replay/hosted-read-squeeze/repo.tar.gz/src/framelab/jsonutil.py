"""Small JSON helpers shared by every Frame Lab module (stdlib only)."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Mapping

from . import FrameLabError


def canonical_bytes(value: object) -> bytes:
    """The engine journal's canonical form: sorted keys, compact, UTF-8, no NaN."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256_tag(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def deep_copy(value: object) -> object:
    return copy.deepcopy(value)


def as_mapping(value: object, context: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise FrameLabError(f"{context} must be an object")
    return value


def as_string(value: object, context: str) -> str:
    if not isinstance(value, str):
        raise FrameLabError(f"{context} must be a string")
    return value


def load_document(path: Path, context: str) -> Mapping[str, object]:
    """Load one JSON object; YAML is accepted only when PyYAML is installed."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise FrameLabError(f"cannot read {context}: {path}") from exc
    if path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ModuleNotFoundError as exc:
            raise FrameLabError(f"{context} is YAML but PyYAML is not installed; use JSON or install PyYAML") from exc
        try:
            value = yaml.safe_load(raw)
        except Exception as exc:  # PyYAML raises several parser exception types
            raise FrameLabError(f"{context} is not valid YAML: {path}") from exc
    else:
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise FrameLabError(f"{context} is not valid JSON: {path}") from exc
    return as_mapping(value, context)


def write_json(path: Path, value: object) -> Path:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)
    return path


def write_text(path: Path, text: str) -> Path:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)
    return path
