"""The variant edit language: small, typed, model-visible edits to one recorded request.

Every edit names its target exactly (a message selector plus an exact anchor and an expected
occurrence count). An edit that matches zero or more places than expected is refused, so a
variant can never silently apply to the wrong text or to nothing at all.
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Mapping, Sequence

from . import FrameLabError
from .jsonutil import as_mapping, as_string, load_document

VARIANTS_SCHEMA = "framelab/variants/1"

OPS = (
    "add_line", "noop", "remove_harness_card", "remove_lines", "remove_message", "remove_message_block",
    "remove_text", "replace_message", "replace_text", "set_tool_menu",
)

# The engine's own state card opens the system prompt with this sentence and closes with the second.
_CARD_OPENING = "StateFrame is your current working state."
_CARD_CLOSING = "evidence gaps; it does not certify correctness."


def _messages(body: Mapping[str, object]) -> list[dict[str, object]]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not all(isinstance(m, Mapping) for m in messages):
        raise FrameLabError("request has no list of message objects")
    return [dict(m) for m in messages]


def _content(message: Mapping[str, object], index: int) -> str:
    content = message.get("content")
    if not isinstance(content, str):
        raise FrameLabError(f"message {index} content is not text; this edit needs a text message")
    return content


def tool_name(tool: object, context: str) -> str:
    function = as_mapping(as_mapping(tool, context).get("function"), f"{context}.function")
    return as_string(function.get("name"), f"{context}.function.name")


def _find_message(messages: Sequence[Mapping[str, object]], edit: Mapping[str, object]) -> int:
    selector = as_mapping(edit.get("selector", edit), "message selector")
    candidates = list(range(len(messages)))
    if "message_index" in selector:
        index = selector["message_index"]
        if type(index) is not int or not 0 <= index < len(messages):
            raise FrameLabError(f"message_index {index!r} is out of range")
        candidates = [index]
    if "role" in selector:
        role = as_string(selector["role"], "selector.role")
        candidates = [i for i in candidates if messages[i].get("role") == role]
    if "contains" in selector:
        needle = as_string(selector["contains"], "selector.contains")
        candidates = [i for i in candidates if isinstance(messages[i].get("content"), str)
                      and needle in messages[i]["content"]]
    if not candidates:
        raise FrameLabError(f"message selector matched no messages: {dict(selector)!r}")
    occurrence = selector.get("occurrence", 1)
    if type(occurrence) is not int or occurrence < 1:
        raise FrameLabError("selector occurrence must be a positive integer (1 = the latest match)")
    if occurrence > len(candidates):
        raise FrameLabError(f"selector occurrence {occurrence} exceeds its {len(candidates)} matches")
    return candidates[-occurrence]


def _expected(edit: Mapping[str, object]) -> int:
    expected = edit.get("expected_occurrences", 1)
    if type(expected) is not int or expected < 1:
        raise FrameLabError("expected_occurrences must be a positive integer")
    return expected


def _replace_anchor(body: dict[str, object], edit: Mapping[str, object], replacement: str | None) -> str:
    messages = _messages(body)
    index = _find_message(messages, edit)
    content = _content(messages[index], index)
    op = edit.get("op")
    anchor = as_string(edit.get("anchor"), f"{op}.anchor")
    if not anchor:
        raise FrameLabError(f"{op}.anchor must not be empty")
    new_text = replacement if replacement is not None else as_string(edit.get("replacement", edit.get("text", "")), f"{op}.replacement")
    found, expected = content.count(anchor), _expected(edit)
    if found != expected:
        raise FrameLabError(f"{op}.anchor found {found} time(s), expected {expected}")
    messages[index]["content"] = content.replace(anchor, new_text, found)
    body["messages"] = messages
    return f"message[{index}] {op}"


def _add_line(body: dict[str, object], edit: Mapping[str, object]) -> str:
    messages = _messages(body)
    index = _find_message(messages, edit)
    content = _content(messages[index], index)
    text = as_string(edit.get("text"), "add_line.text")
    if not text or "\n" in text or "\r" in text:
        raise FrameLabError("add_line.text must be one non-empty line")
    placement = edit.get("placement", "end")
    if placement == "start":
        updated = text + ("\n" if content else "") + content
    elif placement == "end":
        updated = content + ("\n" if content and not content.endswith("\n") else "") + text
    elif placement in {"before_anchor", "after_anchor"}:
        anchor = as_string(edit.get("anchor"), "add_line.anchor")
        found, expected = content.count(anchor), _expected(edit)
        if not anchor or found != expected:
            raise FrameLabError(f"add_line.anchor found {found} time(s), expected {expected}")
        insertion = text + "\n" + anchor if placement == "before_anchor" else anchor + text + "\n"
        updated = content.replace(anchor, insertion, expected)
    else:
        raise FrameLabError("add_line.placement must be start, end, before_anchor or after_anchor")
    messages[index]["content"] = updated
    body["messages"] = messages
    return f"message[{index}] add_line"


def _remove_lines(body: dict[str, object], edit: Mapping[str, object]) -> str:
    messages = _messages(body)
    index = _find_message(messages, edit)
    lines = _content(messages[index], index).splitlines(keepends=True)
    needle = as_string(edit.get("line_contains"), "remove_lines.line_contains")
    if not needle:
        raise FrameLabError("remove_lines.line_contains must not be empty")
    matched, expected = sum(needle in line for line in lines), _expected(edit)
    if matched != expected:
        raise FrameLabError(f"remove_lines matched {matched} line(s), expected {expected}")
    messages[index]["content"] = "".join(line for line in lines if needle not in line)
    body["messages"] = messages
    return f"message[{index}] remove_lines"


def _remove_harness_card(body: dict[str, object], edit: Mapping[str, object]) -> str:
    """Remove the engine's state card (or a section headed "harness card"), refusing any ambiguity."""
    messages = _messages(body)
    candidates = [i for i, m in enumerate(messages) if isinstance(m.get("content"), str) and (
        "harness card" in m["content"].lower()
        or (m.get("role") == "system" and m["content"].startswith(_CARD_OPENING) and _CARD_CLOSING in m["content"]))]
    if len(candidates) != 1:
        raise FrameLabError(f"remove_harness_card found {len(candidates)} candidate messages, expected 1")
    index = candidates[0]
    lines = _content(messages[index], index).splitlines(keepends=True)
    headers = [i for i, line in enumerate(lines) if "harness card" in line.lower()]
    if len(headers) > 1:
        raise FrameLabError(f"remove_harness_card found {len(headers)} card headers")
    start = headers[0] if headers else 0
    if edit.get("end_marker") is not None:
        marker = as_string(edit["end_marker"], "remove_harness_card.end_marker")
        ends = [i for i in range(start + 1, len(lines)) if marker in lines[i]]
        if len(ends) != 1:
            raise FrameLabError(f"remove_harness_card end_marker found {len(ends)} lines, expected 1")
        end = ends[0] + 1
    elif headers:
        # A labelled section ends where the next labelled section ("[...]") begins.
        boundaries = [i for i in range(start + 1, len(lines)) if lines[i].lstrip().startswith("[")]
        if not boundaries:
            raise FrameLabError("remove_harness_card has no next labelled section; pass end_marker")
        end = boundaries[0]
    else:
        boundaries = [i + 1 for i in range(start, len(lines)) if _CARD_CLOSING in lines[i]]
        if not boundaries:
            raise FrameLabError("remove_harness_card could not find the end of the state card")
        end = boundaries[0]
    messages[index]["content"] = "".join(lines[:start] + lines[end:])
    body["messages"] = messages
    return f"message[{index}] remove_harness_card lines={end - start}"


def _set_tool_menu(body: dict[str, object], base: Mapping[str, object], edit: Mapping[str, object]) -> str:
    menu = edit.get("menu", edit.get("tools"))
    if not isinstance(menu, list) or not menu:
        raise FrameLabError("set_tool_menu requires a non-empty menu list")
    catalog = base.get("tool_catalog") if isinstance(base.get("tool_catalog"), Mapping) else {}
    current = body.get("tools") if isinstance(body.get("tools"), list) else []
    by_name = {tool_name(t, f"request tool {i}"): copy.deepcopy(dict(t)) for i, t in enumerate(current)}
    tools: list[dict[str, object]] = []
    names: list[str] = []
    for index, item in enumerate(menu):
        if isinstance(item, str):
            name = item
            source = by_name.get(name) or catalog.get(name)
            if not isinstance(source, Mapping):
                raise FrameLabError(f"set_tool_menu item {name!r} has no definition in the request or the run's tool catalog")
            tool = copy.deepcopy(dict(source))
        elif isinstance(item, Mapping):
            tool = copy.deepcopy(dict(item))
            name = tool_name(tool, f"set_tool_menu item {index}")
        else:
            raise FrameLabError(f"set_tool_menu item {index} must be a tool name or a tool object")
        if name in names:
            raise FrameLabError(f"set_tool_menu lists {name!r} twice")
        names.append(name)
        tools.append(tool)
    body["tools"] = tools
    return "tools=[" + ", ".join(names) + "]"


def apply_variant(base: Mapping[str, object], variant: Mapping[str, object]) -> tuple[dict[str, object], list[str]]:
    """Apply a variant's edits to a deep copy of the base request; returns (body, audit lines)."""
    request = base.get("request")
    if not isinstance(request, Mapping):
        raise FrameLabError("base extraction has no request object")
    edits = variant.get("edits", [])
    if not isinstance(edits, list):
        raise FrameLabError("variant.edits must be a list")
    body = copy.deepcopy(dict(request))
    audit: list[str] = []
    for position, raw in enumerate(edits):
        edit = as_mapping(raw, f"edit {position}")
        op = as_string(edit.get("op"), f"edit {position}.op")
        if op == "noop":
            audit.append("noop")
        elif op == "replace_message":
            messages = _messages(body)
            index = _find_message(messages, edit)
            messages[index]["content"] = as_string(edit.get("text"), "replace_message.text")
            body["messages"] = messages
            audit.append(f"message[{index}] replace_message")
        elif op == "remove_message":
            messages = _messages(body)
            index = _find_message(messages, edit)
            del messages[index]
            body["messages"] = messages
            audit.append(f"message[{index}] remove_message")
        elif op == "replace_text":
            audit.append(_replace_anchor(body, edit, None))
        elif op in {"remove_text", "remove_message_block"}:
            audit.append(_replace_anchor(body, edit, ""))
        elif op == "add_line":
            audit.append(_add_line(body, edit))
        elif op == "remove_lines":
            audit.append(_remove_lines(body, edit))
        elif op == "remove_harness_card":
            audit.append(_remove_harness_card(body, edit))
        elif op == "set_tool_menu":
            audit.append(_set_tool_menu(body, base, edit))
        else:
            raise FrameLabError(f"unsupported op {op!r}; allowed: {', '.join(OPS)}")
    return body, audit


def variant_name(variant: Mapping[str, object], index: int) -> str:
    name = as_string(variant.get("name", f"variant-{index + 1}"), f"variant {index}.name")
    if not name.strip():
        raise FrameLabError(f"variant {index}.name must not be empty")
    return name


def load_variants(path: Path) -> list[dict[str, object]]:
    document = load_document(Path(path), "variant file")
    if document.get("schema") != VARIANTS_SCHEMA:
        raise FrameLabError(f"variant file schema must be {VARIANTS_SCHEMA!r}")
    raw = document.get("variants")
    if not isinstance(raw, list) or not raw:
        raise FrameLabError("variant file needs a non-empty 'variants' list")
    seen: set[str] = set()
    variants = []
    for index, item in enumerate(raw):
        variant = dict(as_mapping(item, f"variant {index}"))
        name = variant_name(variant, index)
        if name in seen:
            raise FrameLabError(f"duplicate variant name {name!r}")
        seen.add(name)
        variants.append(variant)
    return variants
