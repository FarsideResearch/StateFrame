"""Read a StateFrame run journal and rebuild one recorded model request exactly.

A StateFrame run writes ``<run>/worker/measurement-runs/<run id>/events.jsonl``. Each line is one
canonical JSON record with ``kind``, ``sequence`` and ``event_id``. Values larger than a few KB are
stored once under ``blobs/<sha256>.zlib`` beside the journal and replaced by ``{"$blob": sha, "bytes": n}``.

Every model request appears as a ``request_submitted`` record carrying the exact wire text
(``payload_utf8``) and its ``payload_hash``. Frame Lab trusts only those bytes: the hash is
recomputed and a mismatch is refused, never repaired.
"""
from __future__ import annotations

import json
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from . import FrameLabError
from .jsonutil import canonical_bytes, sha256_tag

_BLOB_MAX_BYTES = 256 * 1024 * 1024
_HEX = frozenset("0123456789abcdef")


def find_journal(path: Path) -> Path:
    """Accept a journal file or a run directory and return the single journal inside it."""
    path = Path(path)
    if path.is_file():
        return path
    if not path.is_dir():
        raise FrameLabError(f"no journal or run directory at {path}")
    candidates = sorted(path.glob("worker/measurement-runs/*/events.jsonl")) or sorted(path.glob("events.jsonl"))
    if len(candidates) != 1:
        raise FrameLabError(f"expected exactly one events.jsonl under {path}, found {len(candidates)}; pass the file")
    return candidates[0]


def _blob_reference(value: object) -> tuple[str, int] | None:
    if not isinstance(value, Mapping) or set(value) != {"$blob", "bytes"}:
        return None
    blob, size = value.get("$blob"), value.get("bytes")
    if not isinstance(blob, str) or len(blob) != 64 or not set(blob) <= _HEX:
        return None
    if type(size) is not int or size <= 0 or size > _BLOB_MAX_BYTES:
        return None
    return blob, size


class _BlobStore:
    """Resolve ``$blob`` references beside one journal; every resolved value is hash checked."""

    def __init__(self, journal: Path):
        self.directory = journal.parent / "blobs"
        self.cache: dict[str, object] = {}

    def _read(self, blob: str) -> bytes:
        for name, compressed in ((f"{blob}.zlib", True), (blob, False)):
            candidate = self.directory / name
            if candidate.is_file():
                data = candidate.read_bytes()
                return zlib.decompress(data) if compressed else data
        raise FrameLabError(f"journal blob {blob[:16]} is missing from {self.directory}")

    def resolve(self, value: object, depth: int = 0) -> object:
        if depth > 64:
            raise FrameLabError("journal blob references nest too deeply")
        reference = _blob_reference(value)
        if reference is not None:
            blob, size = reference
            if blob not in self.cache:
                try:
                    encoded = self._read(blob)
                except zlib.error as exc:
                    raise FrameLabError(f"journal blob {blob[:16]} is not valid zlib data") from exc
                try:
                    decoded = json.loads(encoded)
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise FrameLabError(f"journal blob {blob[:16]} is not valid JSON") from exc
                resolved = self.resolve(decoded, depth + 1)
                logical = canonical_bytes(resolved)
                if len(logical) != size or sha256_tag(logical) != "sha256:" + blob:
                    raise FrameLabError(f"journal blob {blob[:16]} does not match its recorded hash or size")
                self.cache[blob] = resolved
            # Shared, not copied: loaded records are read-only; every edit path deep-copies first.
            return self.cache[blob]
        if isinstance(value, Mapping):
            if "$blob" in value:
                raise FrameLabError("malformed journal blob reference")
            return {key: self.resolve(item, depth + 1) for key, item in value.items()}
        if isinstance(value, list):
            return [self.resolve(item, depth + 1) for item in value]
        return value


def _record_digest(record: Mapping[str, object]) -> str:
    payload = dict(record)
    payload.pop("record_hash", None)
    return sha256_tag(canonical_bytes(payload))


MODEL_KINDS = frozenset({"request_prepared", "request_submitted", "response_received"})


def load_journal(path: Path, hydrate: frozenset[str] | None = MODEL_KINDS) -> list[dict[str, object]]:
    """Load every record; blobs are hydrated for the record kinds in ``hydrate`` (None = all).

    Other records keep their ``$blob`` references, which keeps a long run's journal fast to read.
    Refuses: unreadable or empty files, invalid JSON, non-object lines, sequence gaps, mixed run
    ids, and (when the journal carries a ``record_hash`` chain) any broken link.
    """
    journal = find_journal(Path(path))
    try:
        lines = journal.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError) as exc:
        raise FrameLabError(f"cannot read journal {journal}") from exc
    if not any(line.strip() for line in lines):
        raise FrameLabError(f"empty journal: {journal}")
    store = _BlobStore(journal)
    records: list[dict[str, object]] = []
    previous: Mapping[str, object] | None = None
    run_id: object = None
    for number, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            raw = json.loads(line)
        except json.JSONDecodeError as exc:
            raise FrameLabError(f"invalid JSON at line {number} of {journal}") from exc
        if not isinstance(raw, dict):
            raise FrameLabError(f"journal line {number} is not an object")
        sequence = raw.get("sequence")
        if type(sequence) is not int:
            raise FrameLabError(f"journal line {number} has no integer sequence")
        if previous is not None and sequence != previous["sequence"] + 1:
            raise FrameLabError(f"journal sequence gap before {sequence}")
        if run_id is None:
            run_id = raw.get("run_id")
        elif raw.get("run_id") != run_id:
            raise FrameLabError("journal contains more than one run")
        if "record_hash" in raw:
            if raw["record_hash"] != _record_digest(raw):
                raise FrameLabError(f"record hash mismatch at sequence {sequence}")
            linked = raw.get("previous_hash")
            if previous is not None and linked is not None and linked != previous.get("record_hash"):
                raise FrameLabError(f"journal hash link mismatch at sequence {sequence}")
        if hydrate is None or raw.get("kind") in hydrate:
            hydrated = store.resolve(raw)
            if not isinstance(hydrated, dict):
                raise FrameLabError(f"journal record {sequence} did not hydrate to an object")
            records.append(hydrated)
        else:
            records.append(raw)
        previous = raw
    return records


@dataclass(frozen=True)
class RecordedRequest:
    submitted: Mapping[str, object]
    response: Mapping[str, object] | None
    body: dict[str, object]
    wire_utf8: str
    payload_hash: str
    request_id: str


def _resolve_submitted(records: Sequence[Mapping[str, object]], anchor: Mapping[str, object]) -> RecordedRequest:
    if anchor.get("kind") == "request_prepared":
        request_id = anchor.get("request_id")
        matches = [r for r in records if r.get("kind") == "request_submitted" and r.get("request_id") == request_id]
        if not matches:
            raise FrameLabError(f"request {request_id!r} was prepared but never submitted; its wire bytes were not recorded")
        anchor = matches[0]
    if anchor.get("kind") != "request_submitted":
        raise FrameLabError(f"sequence {anchor.get('sequence')} is {anchor.get('kind')!r}, not a model request")
    wire = anchor.get("payload_utf8")
    recorded_hash = anchor.get("payload_hash")
    if not isinstance(wire, str) or not wire:
        raise FrameLabError(f"request at sequence {anchor.get('sequence')} has no payload_utf8")
    if not isinstance(recorded_hash, str):
        raise FrameLabError(f"request at sequence {anchor.get('sequence')} has no payload_hash")
    computed = sha256_tag(wire.encode("utf-8"))
    if computed != recorded_hash:
        raise FrameLabError(f"payload hash mismatch: recorded={recorded_hash} computed={computed}")
    try:
        body = json.loads(wire)
    except json.JSONDecodeError as exc:
        raise FrameLabError("payload_utf8 is not valid JSON") from exc
    if not isinstance(body, dict):
        raise FrameLabError("payload_utf8 is not a JSON object")
    request_id = anchor.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise FrameLabError("request_submitted has no request_id")
    response = next((r for r in records if r.get("kind") == "response_received"
                     and r.get("transport_attempt_id") == anchor.get("event_id")), None)
    return RecordedRequest(anchor, response, body, wire, recorded_hash, request_id)


def resolve_request(records: Sequence[Mapping[str, object]], at: str) -> RecordedRequest:
    """Resolve ``--at``: ``step:N``, a bare number (step first, then journal sequence) or a request id."""
    value = str(at).strip()
    if not value:
        raise FrameLabError("--at must name a step, a journal sequence or a request id")
    by_sequence = {r["sequence"]: r for r in records if type(r.get("sequence")) is int}
    # A request id can be all digits (it is hex); an exact id match wins over reading it as a step.
    id_matches = [r for r in records if r.get("kind") in {"request_prepared", "request_submitted"} and r.get("request_id") == value]
    if id_matches:
        submitted = [r for r in id_matches if r.get("kind") == "request_submitted"]
        if len(submitted) == 1:
            return _resolve_submitted(records, submitted[0])
        if len(id_matches) == 1:
            return _resolve_submitted(records, id_matches[0])
        raise FrameLabError(f"request id {value!r} matched {len(id_matches)} request records")
    if value.startswith("seq:"):
        target = by_sequence.get(int(value[4:])) if value[4:].isdigit() else None
        if target is None:
            raise FrameLabError(f"no journal record at {value}")
        return _resolve_submitted(records, target)
    explicit_step = value.startswith("step:")
    if explicit_step:
        value = value[5:]
    if value.isdigit():
        step = int(value)
        for kind in ("request_submitted", "request_prepared"):
            matches = [r for r in records if r.get("kind") == kind and r.get("step") == step]
            if len(matches) > 1 and kind == "request_submitted":
                ids = ", ".join(str(r.get("request_id")) for r in matches)
                raise FrameLabError(f"step {step} has several submitted requests ({ids}); pass a request id")
            if len(matches) == 1:
                return _resolve_submitted(records, matches[0])
        if explicit_step or step not in by_sequence:
            raise FrameLabError(f"no model request at step {step}")
        return _resolve_submitted(records, by_sequence[step])
    raise FrameLabError(f"no request id {value!r} in this journal")


def list_requests(records: Sequence[Mapping[str, object]]) -> list[dict[str, object]]:
    """One row per submitted model request, for choosing ``--at``."""
    rows = []
    for record in records:
        if record.get("kind") != "request_submitted":
            continue
        payload = record.get("payload")
        messages = payload.get("messages") if isinstance(payload, Mapping) else None
        tools = payload.get("tools") if isinstance(payload, Mapping) else None
        wire = record.get("payload_utf8")
        rows.append({
            "sequence": record.get("sequence"),
            "step": record.get("step"),
            "request_id": record.get("request_id"),
            "messages": len(messages) if isinstance(messages, list) else None,
            "tools": len(tools) if isinstance(tools, list) else None,
            "wire_bytes": len(wire.encode("utf-8")) if isinstance(wire, str) else None,
        })
    return rows
