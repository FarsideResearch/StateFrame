"""Extract a base request, run variants against an endpoint and render the results."""
from __future__ import annotations

import copy
import json
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Mapping, Sequence
from urllib.parse import urlparse

from . import FrameLabError, __version__
from .journal import RecordedRequest, load_journal, resolve_request
from .jsonutil import as_mapping, load_document, sha256_tag
from .scoring import finish_reason, first_action, score, usage
from .transport import apply_seed, apply_slot, require_allowed, send_once, wire_bytes
from .variants import apply_variant, tool_name, variant_name

BASE_SCHEMA = "framelab/base/1"
RESULT_SCHEMA = "framelab/result/1"
DEFAULT_MAX_REQUESTS = 40
MAX_REQUESTS_CEILING = 1000


def _tool_catalog(records: Sequence[Mapping[str, object]], up_to_sequence: int) -> dict[str, dict[str, object]]:
    """Every tool definition the run offered up to the anchor, so a variant may re-offer one."""
    catalog: dict[str, dict[str, object]] = {}
    for record in records:
        if record.get("kind") != "request_submitted" or not isinstance(record.get("sequence"), int):
            continue
        if record["sequence"] > up_to_sequence:
            continue
        payload = record.get("payload")
        tools = payload.get("tools") if isinstance(payload, Mapping) else None
        for index, tool in enumerate(tools if isinstance(tools, list) else []):
            try:
                catalog[tool_name(tool, f"recorded tool {index}")] = copy.deepcopy(dict(tool))
            except FrameLabError:
                continue
    return catalog


def extract_base(journal: Path, at: str) -> dict[str, object]:
    records = load_journal(Path(journal))
    recorded: RecordedRequest = resolve_request(records, at)
    sequence = recorded.submitted.get("sequence")
    sequence = sequence if isinstance(sequence, int) else 0
    response = recorded.response.get("response") if isinstance(recorded.response, Mapping) else None
    return {
        "schema": BASE_SCHEMA,
        "source": {
            "journal_name": Path(journal).name,
            "run_id": recorded.submitted.get("run_id"),
            "at": str(at),
            "sequence": sequence,
            "step": recorded.submitted.get("step"),
            "request_id": recorded.request_id,
        },
        "integrity": {
            "recorded_payload_hash": recorded.payload_hash,
            "reconstructed_payload_hash": sha256_tag(recorded.wire_utf8.encode("utf-8")),
            "verified": True,
            "wire_bytes": len(recorded.wire_utf8.encode("utf-8")),
        },
        "request_wire_utf8": recorded.wire_utf8,
        "request": recorded.body,
        "tool_catalog": _tool_catalog(records, sequence),
        "recorded_first_action": first_action(response if isinstance(response, Mapping) else None),
    }


def load_base(path: Path) -> dict[str, object]:
    """Load a saved base and re-verify that its request still equals its recorded wire bytes."""
    base = dict(load_document(Path(path), "base file"))
    if base.get("schema") != BASE_SCHEMA:
        raise FrameLabError(f"base schema must be {BASE_SCHEMA!r}")
    wire = base.get("request_wire_utf8")
    integrity = as_mapping(base.get("integrity"), "base.integrity")
    request = as_mapping(base.get("request"), "base.request")
    if not isinstance(wire, str):
        raise FrameLabError("base has no recorded wire bytes")
    actual = sha256_tag(wire.encode("utf-8"))
    if actual != integrity.get("recorded_payload_hash") or integrity.get("verified") is not True:
        raise FrameLabError("base wire bytes no longer match the recorded payload hash")
    if json.loads(wire) != dict(request):
        raise FrameLabError("base request differs from its recorded wire bytes; re-run extract instead of editing it")
    return base


def execute(base: Mapping[str, object], variants: Sequence[Mapping[str, object]], scorer: Mapping[str, object], *,
            url: str, n: int, seed_mode: str = "vary", slot_mode: str = "free", timeout_s: float = 600.0,
            max_requests: int = DEFAULT_MAX_REQUESTS, allow_remote: bool = False, model: str | None = None,
            send: Callable[..., dict[str, object]] = send_once,
            progress: Callable[[str], None] | None = None) -> dict[str, object]:
    """Send every variant ``n`` times and score each first response. Returned tools are never run."""
    if type(n) is not int or n < 1:
        raise FrameLabError("n must be a positive integer")
    if type(max_requests) is not int or not 1 <= max_requests <= MAX_REQUESTS_CEILING:
        raise FrameLabError(f"max_requests must be between 1 and {MAX_REQUESTS_CEILING}")
    planned = len(variants) * n
    if planned > max_requests:
        raise FrameLabError(f"{planned} requests planned, above --max-requests {max_requests}")
    require_allowed(url, allow_remote)
    target = as_mapping(scorer.get("target"), "scorer.target")
    started = time.monotonic_ns()
    results: list[dict[str, object]] = []
    for index, variant in enumerate(variants):
        name = variant_name(variant, index)
        body, audit = apply_variant(base, variant)
        if model:
            body["model"] = model
        if body.get("stream") is True:
            body["stream"] = False
            audit.append("stream=false (Frame Lab reads one complete response)")
        body = apply_slot(body, slot_mode)
        samples = []
        for sample_index in range(n):
            sample_body = apply_seed(body, seed_mode, sample_index)
            outcome = send(sample_body, url, timeout_s=timeout_s)
            response = outcome.get("response") if isinstance(outcome.get("response"), Mapping) else None
            reason = finish_reason(response)
            truncated = reason == "length"
            action = None if truncated else first_action(response)
            elapsed = outcome.get("elapsed_ns")
            samples.append({
                "sample_index": sample_index,
                "action": action,
                "hit": bool(action) and score(action, target),
                "finish_reason": reason,
                "truncated": truncated,
                "usage": usage(response),
                "latency_ms": elapsed / 1e6 if isinstance(elapsed, int) else None,
                "error": outcome.get("error"),
            })
            if progress:
                progress(f"{name} sample {sample_index + 1}/{n}: {'hit' if samples[-1]['hit'] else 'miss'}")
        hits = sum(1 for s in samples if s["hit"])
        distribution = Counter(
            str(s["action"]["tool"]) if s["action"] and s["action"]["kind"] == "tool_call"
            else "content" if s["action"] else "error/none" for s in samples)
        results.append({
            "name": name,
            "edits": copy.deepcopy(variant.get("edits", [])),
            "audit": audit,
            "request_hash": sha256_tag(wire_bytes(body)),
            "n": n,
            "hits": hits,
            "hit_rate": hits / n,
            "tool_distribution": dict(sorted(distribution.items())),
            "mean_output_tokens": _mean(s["usage"]["completion_tokens"] for s in samples),
            "mean_prompt_tokens": _mean(s["usage"]["prompt_tokens"] for s in samples),
            "mean_latency_ms": _mean(s["latency_ms"] for s in samples),
            "samples": samples,
        })
    errors = sum(1 for v in results for s in v["samples"] if s["error"])
    return {
        "schema": RESULT_SCHEMA,
        "framelab_version": __version__,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "base": copy.deepcopy(base.get("source", {})),
        "recorded_first_action": copy.deepcopy(base.get("recorded_first_action")),
        "endpoint": {"host": _host(url), "model_override": model},
        "sampler": {"seed_mode": seed_mode, "slot_mode": slot_mode,
                    "temperature": as_mapping(base.get("request"), "base.request").get("temperature")},
        "n": n,
        "requests": planned,
        "transport_errors": errors,
        "elapsed_ms": (time.monotonic_ns() - started) / 1e6,
        "scorer": copy.deepcopy(dict(scorer)),
        "variants": results,
        "notice": f"n={n} per variant: hit rates describe these samples and are not stable estimates.",
    }


def _host(url: str) -> str:
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.hostname}:{parsed.port}" if parsed.port else f"{parsed.scheme}://{parsed.hostname}"


def _mean(values) -> float | None:
    numbers = [float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]
    return round(sum(numbers) / len(numbers), 3) if numbers else None


def _cell(value: object) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def render_markdown(result: Mapping[str, object], title: str | None = None) -> str:
    lines = [
        f"# {title or 'Frame Lab experiment'}", "",
        f"- Base request: `{_cell(result.get('base', {}).get('request_id'))}` (step {result.get('base', {}).get('step')})",
        f"- Endpoint: `{_cell(result.get('endpoint', {}).get('host'))}`",
        f"- Requests: {result.get('requests')} ({result.get('transport_errors')} transport errors)",
        f"- Recorded first action: `{_cell(json.dumps(result.get('recorded_first_action'), sort_keys=True))}`",
        f"- {result.get('notice')}", "",
        "| Variant | Hits | Hit rate | First actions | Mean output tokens | Mean prompt tokens | Mean latency ms |",
        "|---|---:|---:|---|---:|---:|---:|",
    ]
    for v in result.get("variants") or []:
        lines.append(f"| `{_cell(v['name'])}` | {v['hits']}/{v['n']} | {v['hit_rate']:.0%} | "
                     f"`{_cell(json.dumps(v['tool_distribution'], sort_keys=True))}` | {v['mean_output_tokens']} | "
                     f"{v['mean_prompt_tokens']} | {v['mean_latency_ms']} |")
    for v in result.get("variants") or []:
        lines += ["", f"## {_cell(v['name'])}", "", "Edits applied: " + ("; ".join(v.get("audit") or []) or "none"), "",
                  "| # | Hit | First action | Finish | Output tokens | Latency ms | Error |", "|---:|:---:|---|---|---:|---:|---|"]
        for s in v["samples"]:
            lines.append(f"| {s['sample_index']} | {'yes' if s['hit'] else 'no'} | "
                         f"`{_cell(json.dumps(s['action'], ensure_ascii=False, sort_keys=True))}` | {s['finish_reason']} | "
                         f"{s['usage']['completion_tokens']} | {s['latency_ms']} | {_cell(s['error'] or '')} |")
    return "\n".join(lines) + "\n"
