"""Frame Lab: controlled experiments on the requests a StateFrame run actually sent.

Frame Lab reads a run journal, rebuilds one recorded model request byte for byte,
applies small typed edits to what the model sees, sends each variant to an
OpenAI-compatible endpoint and scores only the first response. Returned tool calls
are never executed.
"""

__version__ = "0.1.0"


class FrameLabError(ValueError):
    """A user-actionable validation or experiment error."""
