# Troubleshooting

| Message (or symptom) | Meaning | Fix |
|---|---|---|
| `expected exactly one events.jsonl under ...` | The folder is not a run directory, or holds several runs. | Pass the run directory itself, or the `events.jsonl` file. |
| `journal blob ... is missing` / `does not match its recorded hash` | The run's `blobs/` folder was not copied with it, or a blob changed. | Copy the whole run directory, including `blobs/`. |
| `journal sequence gap` / `more than one run` | The journal was edited or two journals were joined. | Use the journal exactly as the engine wrote it. |
| `payload hash mismatch` | A request's recorded bytes do not match their hash. | The journal is damaged; use another run. |
| `step N has several submitted requests` | The engine retried that request. | Pass the request id from `framelab requests`. |
| `base request differs from its recorded wire bytes` | The base file was edited by hand. | Re-run `framelab extract`; put changes in variants. |
| `... anchor found 0 time(s), expected 1` | The anchor text is not in the selected message (or occurs a different number of times). | Check with `framelab validate --show`; fix the selector, the anchor, or `expected_occurrences`. |
| `message selector matched no messages` | No message has that role, index or text. | Print the base and look at `request.messages`. |
| `set_tool_menu item ... has no definition` | The tool was never offered in this run up to that request. | Use a tool from the request or `tool_catalog`, or give a full tool object. |
| `no endpoint: pass --endpoint or set STATEFRAME_ENDPOINT` | No server configured. | Export `STATEFRAME_ENDPOINT`, or pass `--endpoint`. |
| `refusing non-loopback endpoint` | The server is not on this machine. | Pass `--allow-remote` if you accept that the request text leaves the machine. |
| `N requests planned, above --max-requests` | Variants times `n` exceeds the limit (40). | Raise `--max-requests` deliberately, or lower `n`. |
| Every sample has `transport: ...` errors | The server is down, the URL is wrong, or it timed out. | Check the server; raise `--timeout` for slow servers. |
| `http 404` from the server | Wrong base URL. | `--endpoint` is the base (`http://host:port/v1`); Frame Lab adds `/chat/completions`. |
| Control samples rarely match `recorded_first_action` | A different model, server or settings than the original run. | Compare like with like, or treat the control as your new baseline. See [Reading results](results.md). |
| Tape relay returns 503 | The tape has no more recorded responses. | The new engine sent more requests than the original; compare with `tape parity`, or use `--live-after`. |
| Tape relay returns 500 | With several tapes, the request matched zero or several markers. | Give each tape a marker that appears only in its own task text. |
| Tape relay returns 502 on `/tokenize` | No `--upstream` for non-chat routes. | Pass `--upstream` with your real server. |
| `framelab: The Frame Lab UI ships in the source repository` | The installed command cannot find the UI folder. | Clone the repository and run `pip install -e .` from the clone. The command exits with code 2. |
| UI shows the demo instead of your runs | Nothing was configured. | Pass `--data DIR` (or set `FRAME_LAB_DATA`). |
| UI lists no runs from `DIR` | `DIR` has neither `runs/` nor run directories directly inside it. | Point `--data` at the folder that holds the run directories. |
