# Reading results

`framelab run` writes a result JSON (schema `framelab/result/1`) and a Markdown report beside it.

## Top level

| Field | Meaning |
|---|---|
| `base` | Which recorded request was used: request id, step, journal sequence, run id. |
| `recorded_first_action` | What the model did first in the original run. Compare your control with it. |
| `endpoint` | The server host (never a key) and any model override. |
| `sampler` | Seed mode, slot mode, the recorded temperature. |
| `n`, `requests`, `transport_errors` | Samples per variant, total requests, how many failed to get a response. |
| `scorer` | The scorer exactly as used. |
| `variants` | One entry per variant (below). |

## Per variant

| Field | Meaning |
|---|---|
| `edits`, `audit` | The edits as written, and what each one changed (`message[2] add_line`). |
| `request_hash` | `sha256:` of the edited request as serialized (before per-sample seeds). Equal hashes mean equal requests. |
| `hits`, `hit_rate` | Samples the scorer accepted. |
| `tool_distribution` | First tool per sample; `content` for a text reply, `error/none` for failures. |
| `mean_output_tokens`, `mean_prompt_tokens`, `mean_latency_ms` | Averages over samples that reported them. |
| `samples` | Each sample's first action (tool, parsed arguments, first 280 characters of text), finish reason, usage, latency, error. |

## How much to trust it

- Start from the control. If the control does not match `recorded_first_action` most of the time, the server,
  model or sampling settings differ from the original run, and the comparison is about that setup, not the original.
- Prompt token counts show whether an edit changed the request size; a large change can matter by itself.
- `n` of 3 to 5 tells you whether something is worth a closer look, nothing more. The report says so on every run.
  Before you rely on a difference, rerun with a larger `n` and on a request from a different task.
- A sample with `truncated: true` hit the token limit and never counts as a hit.
- `transport_errors` close to `requests` means a server problem, not a model result.
