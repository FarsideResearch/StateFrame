# The UI

```bash
framelab ui --data PATH/TO/RUNS
```

The UI binds to 127.0.0.1 (port 8786, or `--port`) and is read only: it answers GET and HEAD requests and refuses
anything else. With no `--data` it shows a synthetic demo. The Overview page offers a dismissible guide to that
demo run, its model frames, an experiment, and grades. The dismissal is saved in this browser.

## Data folder

| `DIR` holds | The UI uses it as |
|---|---|
| `runs/` | Run directories (each with `worker/`, `spec.json` or `summary.json`). |
| `experiments/<name>/` | Result folders. `RESULTS.md` gives the title; JSON files with arrays of records are tabulated. Write `framelab run --out DIR/experiments/<name>/RESULTS.json` to land here. |
| `grades/` | Grade and proof files (see [Concepts](concepts.md#grades)). |

`DIR` may also be a single run directory, or a folder whose subfolders are run directories. A versioned source
manifest (`--config FILE`, schema in `ui/schemas/source-manifest.schema.json`) can point each of `runs`,
`experiments` and `grades` at any path. Older manifests using the pre-release experiment source key remain accepted;
API responses use `experiments`. Older file links and API requests using that key are accepted and normalized to
`experiments`; newly generated links use the canonical key. Imported folders are read only.

## Pages

| Page | Shows |
|---|---|
| Overview | Source status, a demo walkthrough when using demo data, counts, recent runs, and the command line workflow. |
| Runs | Run names and tasks, status, recorded result, grade, requests, tests, and time. A run without a matching grade reads "Not graded"; its own result remains visible. Missing counts read "not recorded". |
| Run | What the model saw, what it did, how it was checked, why it stopped, its timeline, model frames, files, and run details. Engine settings and raw run data are available in disclosures. |
| Experiments | Result folders and experiment details. A declared comparison leads with variants, matched pairs, and the leading variant for its primary measure, with a sample-size caution. Tables and raw result files remain available. |
| Grades | Grade and proof files, plus reports in the grades folder. |

Navigation has visible labels and supports the keyboard. On narrow screens, all four destinations appear in a
second header row. The theme control cycles through system, light, and dark.
Page titles follow the current page, and the Overview title is simply "Frame Lab".

Everything the UI shows passes a redaction step: keys, tokens, credentials in URLs, email addresses and local home
paths are masked. Files named like secrets (`.env`, `*.pem`, `*.key`, names containing `secret` or `password`) are
never served. Links inside a run cannot leave its folder.
