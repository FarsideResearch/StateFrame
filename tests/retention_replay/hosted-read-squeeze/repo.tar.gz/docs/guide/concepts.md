# Concepts

## Run directory and journal

Every `stateframe run` writes a run directory. Frame Lab reads three things from it:

| File | What it holds |
|---|---|
| `worker/measurement-runs/<run id>/events.jsonl` | The journal: one JSON record per event, in order. |
| `worker/measurement-runs/<run id>/blobs/<sha256>.zlib` | Large values, stored once. A record holds `{"$blob": "<sha256>", "bytes": n}` in their place. |
| `summary.json` | The engine's summary: success, exit code, outcome, request and token counts, wall time. |

Every journal record has `kind`, `sequence` (1, 2, 3, ... with no gaps), `event_id` and `run_id`. The kinds Frame Lab
uses:

| Kind | Fields Frame Lab reads |
|---|---|
| `request_submitted` | `request_id`, `step`, `payload_utf8` (the exact bytes sent), `payload_hash` (`sha256:` of those bytes), `payload` |
| `request_prepared` | `request_id`, `step` (a request that was built; its bytes are on the matching `request_submitted`) |
| `response_received` | `transport_attempt_id` (the submitted record's `event_id`), `request_id`, `response` (the chat completion) |

When Frame Lab loads a journal it replaces every blob reference with its content and checks that the content's
SHA-256 and size match the reference. A missing or altered blob, a gap in `sequence`, or records from two runs
in one file stop the load with an error. If records carry a `record_hash` chain, that chain is checked too.

Frame Lab does not import StateFrame or require a particular StateFrame package version. It supports run journals
whose submitted request records include exact `payload_utf8` bytes and a matching `payload_hash`. It verifies those
hashes and does not write to the StateFrame run directory. Journal formats without those fields are not supported.

## Base

A base is one recorded request, extracted into a JSON file (`framelab extract`). It holds:

- `request_wire_utf8`: the exact text the engine sent, and `request`: the same text parsed.
- `integrity`: the recorded hash and the recomputed one. Every load recomputes it, so an edited base is refused.
- `tool_catalog`: every tool definition the run offered up to that request, so a variant can offer a tool again
  after the engine removed it from the menu.
- `recorded_first_action`: what the model actually did first in the original run.

A step is the engine's turn number. Pick the step where the model made the choice you want to study.

## Variant

A variant is a named list of edits applied to a copy of the base request (schema `framelab/variants/1`). Edits
change only what the model sees: message text, whole messages, the engine's state card in the system message, or
the tool menu. Every text edit names an exact anchor and how many times it must occur (default once); a mismatch is
an error, so an edit can never apply to the wrong place or silently do nothing. Always include a `noop` control: it
is the recorded request unchanged, so its results show the model's own variation.

## Scorer

A scorer (schema `framelab/scorer/1`) has one `target` that decides whether a first response is a hit: which tool
was called, what its arguments contain, or what a text reply says. Only the first tool call of the first response
is scored. A response cut off by the token limit (`finish_reason: "length"`) is never a hit, and neither is a
sample that got no response (a transport or HTTP error).

## Sample

Frame Lab sends each variant `n` times. With seed mode `vary` (the default) each sample uses a distinct seed
derived from the recorded one (recorded seed + 1 + sample index), so samples differ but a rerun reproduces them.
If the recorded request had no seed, none is added, and samples then differ only by the server's own randomness, so a
rerun need not reproduce them. With `keep`, every sample sends the recorded seed.

## Tape

A tape is a run's recorded model responses, in order. `framelab tape serve` answers chat requests from it, so a
new engine version can run against fixed model answers. Two runs of the same engine on the same tape send the same
requests except for per-run identifiers; `framelab tape parity` compares them with those identifiers masked.
The relay serves answers by position and never compares a request with the recorded one, so it is not a way to
measure variants.

## Grades

A grade file is JSON in a `grades/` folder: `<name>.graded.json` carries a verdict (`FIXED` or `NOT_FIXED`);
`<name>.json` without `.graded` is a proof that lists per-case results without a verdict. `task_id` names the task;
`run_ids` (or `candidate_sha256`) ties the grade to specific runs. The UI shows them; nothing in Frame Lab writes them.
