# Design rationale

**The command line is the native interface.** Frame Lab was built for coding agents running StateFrame experiments.
Commands let an agent inspect requests, validate edits, run experiments and keep JSON result files. People can use
the same commands or inspect runs in the local read-only UI.

**Experiment on one recorded request, not a whole run.** A full run is long, slow and noisy: one early difference
changes everything after it. The engine records each request exactly, so the cleanest question is local: given
exactly this state, does this change alter what the model does next? Frame Lab answers that with a handful of
cheap requests instead of whole runs.

**The recorded bytes are the source of truth.** A base is the wire text the engine sent, checked against its
recorded hash on every load. Edits apply to a copy; a hand-edited base is refused. This keeps every result tied to
a real request, and a `noop` control reproduces it byte for byte.

**Edits must match exactly or fail.** A text edit that matches nothing would silently send the control twice and
report a meaningless "no effect". So every edit names its anchor and how often it must occur, and anything else is
an error before a single request is sent.

**Only the first action is scored, and tools are never run.** Executing a returned tool call would need the whole
workspace and its history, and the next request would no longer be controlled. The first action is the decision the
edit can affect directly.

**Small samples say so.** Every report states `n`. Seeds vary per sample but reproducibly, so a rerun gives the same
draws. A control arm in every experiment shows the model's own variation.

**Local by default.** Requests carry the user's task and code, so Frame Lab sends them only to loopback servers
unless told otherwise, never logs an API key, and caps the number of requests per run. The UI binds to 127.0.0.1,
never contacts a model server, masks secrets and local paths, and is read only: it accepts no request that could
change anything.

**Tapes hold the model fixed.** To see what an engine change does, the model's answers have to stay the same. The
relay serves a run's recorded answers in order and stops at the end of the tape rather than guess, and `parity`
compares requests with per-run identifiers masked, so a real difference stands out.

**Standard library only.** The command line and the UI server need nothing beyond Python 3.11, so they install
offline next to StateFrame. The web app is prebuilt and its third-party licenses ship with it.
