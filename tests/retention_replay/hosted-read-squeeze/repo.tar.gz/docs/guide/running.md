# Running experiments

All commands take a run directory or its `events.jsonl`. Exit codes: 0 success, 1 a check failed (see each
command), 2 an input error (the message says what to fix).

## The loop

```bash
framelab requests RUN                                   # 1. find the step
framelab extract RUN --at step:7 --out work/base.json   # 2. freeze that request
framelab validate --base work/base.json --variants v.json --scorer s.json   # 3. check edits offline
framelab run --base work/base.json --variants v.json --scorer s.json \
  --n 8 --out work/experiments/menu-test/RESULTS.json   # 4. send and score
framelab ui --data work                                 # 5. look at it
```

## `framelab requests RUN [--json]`

One row per `request_submitted`: step, journal sequence, message count, tool count, wire bytes, request id.

## `framelab extract RUN --at WHERE --out FILE`

`WHERE` is `step:N`, `seq:N`, a request id, or a bare number. A bare number is read as a request id if one matches
exactly, then as a step, then as a journal sequence. A step with two submitted requests (a retry) is refused; pass
the request id. A `request_prepared` record resolves to its `request_submitted`.

## `framelab validate --base FILE --variants FILE [--scorer FILE] [--show]`

Applies every variant to a copy of the base and prints the edits it made. `--show` prints each edited request.
Use it before every `run`: a bad anchor fails here, before any request is sent.

### Edit ops

| Op | Fields | Effect |
|---|---|---|
| `noop` | | Nothing; the recorded request. |
| `replace_text` | selector, `anchor`, `replacement`, `expected_occurrences` | Replace the anchor. It must occur exactly `expected_occurrences` times (default 1), and all of those occurrences are replaced; any other count is an error. |
| `remove_text` | selector, `anchor`, `expected_occurrences` | Delete the anchor text (same counting rule). `remove_message_block` is another name for the same op. |
| `add_line` | selector, `text` (one line), `placement`: `start`, `end`, `before_anchor`, `after_anchor`, plus `anchor` | Insert a line. |
| `remove_lines` | selector, `line_contains`, `expected_occurrences` | Delete every line containing the string. |
| `replace_message` | selector, `text` | Replace a message's whole text. |
| `remove_message` | selector | Delete a message. |
| `remove_harness_card` | optional `end_marker` | Delete the engine's state card at the start of the system message (or a section whose header says "harness card"). |
| `set_tool_menu` | `menu`: tool names or full tool objects | Offer exactly these tools, in this order. A name must exist in the request or the base's tool catalog: the keys of `tool_catalog` in the base file list every name you can use. |

A selector picks one message with `message_index`, `role` and `contains` (all optional, combined), then
`occurrence` (default 1) counts back from the latest match. Text edits need a message whose content is a string.

## `framelab run`

A run needs a local OpenAI-compatible model server. There is no offline or dry-run mode. A tape relay can check
command wiring, but its recorded answers ignore the request and do not measure variants.

| Flag | Default | Meaning |
|---|---|---|
| `--base`, `--variants`, `--scorer`, `--out` | required | `--out` is the result JSON; a Markdown report is written beside it with `.md`. |
| `--endpoint URL` | `$STATEFRAME_ENDPOINT` | OpenAI-compatible base URL; `/chat/completions` is appended if missing. |
| `--model NAME` | `$STATEFRAME_MODEL`, else the recorded name | Replaces the request's `model` field. |
| `--n` | 3 | Samples per variant. |
| `--seed-mode` | `vary` | `vary` or `keep` (see [Concepts](concepts.md#sample)). |
| `--slot` | `free` | `free` drops the server slot identifier recorded in the request; `keep` sends it. |
| `--timeout` | 600 | Seconds per request. |
| `--max-requests` | 40 | Variants times `n` may not exceed it (hard ceiling 1000). |
| `--allow-remote` | off | Needed for any host that is not loopback. |
| `--title`, `--quiet` | | Report title; no per-sample progress lines. |

`FRAMELAB_API_KEY`, when set, is sent as `Authorization: Bearer ...` and never written anywhere. A request that
asked for streaming is sent with `stream: false`. Exit code 1 means every request failed in transport.

Store results as `<folder>/experiments/<name>/RESULTS.json` so `framelab ui --data <folder>` lists them.
In a UI source manifest, `experiments` is the current key for experiment results; the older `frame_lab` key
continues to work.

## `framelab render RESULT [--out FILE] [--title T]`

Rewrites the Markdown report from a result JSON.

## `framelab tape ...`

| Command | Does |
|---|---|
| `tape check RUN...` | Loads each run's recorded responses (with blobs) and counts them. Exit 1 if any run cannot serve as a tape. |
| `tape serve --tape [NAME=]RUN [--tape ...] [--marker NAME=TEXT ...] [--port 8090] [--upstream URL] [--live-after N] [--log FILE]` | Serves `/v1/chat/completions` (and `/chat/completions`) from the tape, in order. Other routes go to `--upstream`, or get 502 without it. After the last response: 503. With `--live-after N`, chat request N and later go to `--upstream`. With several tapes, each request is routed to the one tape whose marker appears in its message text; zero or several matches get 500. |
| `tape parity CANDIDATE BASELINE` | Compares the two runs' requests in order after masking 32- and 64-hex ids, pytest durations and memory addresses. Prints the first difference (field, or message index). Exit 1 if any differ or the counts differ. |

Every request to the chat route consumes the next recorded response, including a probe you send by hand, so do
not test the relay with a chat request before a run. The relay does not compare a request with the one that was
recorded: it is for replaying an engine against fixed answers, not for measuring variants.

The relay logs one JSON line per request (`served`, `tape_end`, `forward`, `live_forward`, `route_error`) to `--log`.

## `framelab ui [--data DIR] [--port N]`

Starts the UI on 127.0.0.1 (default port 8786). The UI folder must be present in a source clone or editable
install. If it is missing, Frame Lab exits with code 2 and tells you to clone the repository and run
`pip install -e .`. See [The UI](ui.md).
