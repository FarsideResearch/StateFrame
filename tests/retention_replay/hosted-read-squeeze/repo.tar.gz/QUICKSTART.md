# Quickstart

This walks through one experiment on the bundled sample run, then the same steps on a run of your own. Frame Lab's command line is its native interface for agents: request lists can be JSON, and extracted bases and experiment results are files. People can use those commands or inspect the same data in the local UI.
Commands assume you are in the Frame Lab folder and installed it with `pip install --no-index --no-build-isolation -e .`
(or use `PYTHONPATH=src python3 -m framelab` in place of `framelab`). The editable install (`-e`) keeps
`framelab ui` working, because the UI lives in this folder rather than inside the Python package.

## 1. Look at a run

A StateFrame run directory holds its journal at `worker/measurement-runs/<run id>/events.jsonl`. Frame Lab accepts
the run directory or the journal file.

```bash
framelab requests examples/sample-run
```

```text
 step    seq  msgs tools    bytes  request id
    0      3     3     4     5539  00000000000000000000000000000001
    1      6     3     4     5580  00000000000000000000000000000002
    2      9     3     4     5573  00000000000000000000000000000003
```

## 2. Extract one request as a base

```bash
framelab extract examples/sample-run --at step:1 --out work/base.json
```

`--at` takes `step:N`, `seq:N` (journal sequence), a bare number (step first, then sequence) or a request id.
The base holds the exact wire text the engine sent, its recorded hash (checked on every load), the tool catalog the
run offered up to that point, and the first action the model actually took.

## 3. Write variants

A variant is a list of typed edits to what the model sees. Excerpt from `examples/variants.json`:

```json
{
  "schema": "framelab/variants/1",
  "variants": [
    {"name": "control", "edits": [{"op": "noop"}]},
    {"name": "without-state-card", "edits": [{"op": "remove_harness_card"}]},
    {"name": "edit-tools-only", "edits": [{"op": "set_tool_menu", "menu": ["read_file", "replace_in_file"]}]}
  ]
}
```

Always keep a `noop` control: it is the recorded request, unchanged.

| Op | What it does | Fields |
|---|---|---|
| `noop` | Send the request unchanged | |
| `replace_text` | Replace an exact anchor | selector, `anchor`, `replacement`, `expected_occurrences` (default 1) |
| `remove_text` | Delete an exact anchor (`remove_message_block` is another name for it) | selector, `anchor`, `expected_occurrences` |
| `add_line` | Add one line | selector, `text`, `placement`: `start`, `end`, `before_anchor`, `after_anchor` (+ `anchor`) |
| `remove_lines` | Delete lines containing a string | selector, `line_contains`, `expected_occurrences` |
| `replace_message` | Replace a whole message | selector, `text` |
| `remove_message` | Delete a message | selector |
| `remove_harness_card` | Delete the engine's state card from the system message | optional `end_marker` |
| `set_tool_menu` | Offer exactly these tools, in this order | `menu`: tool names (the keys of `tool_catalog` in the base file) or full tool objects |

A selector picks one message: `{"role": "user", "contains": "[Requirements]", "occurrence": 1}`.
`message_index`, `role` and `contains` narrow the candidates; `occurrence` counts back from the latest match.
An anchor that matches a different number of times than expected is an error, never a silent no-op.

Check the variants offline:

```bash
framelab validate --base work/base.json --variants examples/variants.json --scorer examples/scorer.json
```

Add `--show` to print each edited request.

## 4. Write a scorer

The scorer says what counts as a hit for the first action. `examples/scorer.json`:

```json
{
  "schema": "framelab/scorer/1",
  "target": {
    "tool": "replace_in_file",
    "argument_path": ["path"],
    "selector_in": ["pricing.py"],
    "argument_contains": ["discount"]
  }
}
```

| Target key | Meaning |
|---|---|
| `tool` or `tools` | The first tool call must be this tool (or one of these) |
| `arguments` | Arguments must equal this object exactly |
| `argument_path` + `selector_in` | The value at this path must be one of these |
| `argument_contains` | Every string must appear somewhere in the arguments |
| `argument_any_contains` | At least one string must appear |
| `text_contains` | The reply text must contain this (with `kind: "content"` for a text-only reply) |

A response cut off by the token limit (`finish_reason: "length"`) never counts as a hit.

## 5. Run it

`framelab run` needs a local OpenAI-compatible model server. There is no offline or dry-run mode. Point Frame Lab at the same server StateFrame uses:

```bash
export STATEFRAME_ENDPOINT=http://127.0.0.1:8080/v1
framelab run --base work/base.json --variants examples/variants.json --scorer examples/scorer.json \
  --n 5 --out work/experiments/first/RESULTS.json
```

You get `RESULTS.json` and a readable `RESULTS.md`: hits per variant, the distribution of first tools, mean tokens and
latency, and every sample's first action.

- `--n` samples per variant. With `--seed-mode vary` (default) each sample gets a distinct, reproducible seed.
- `--slot free` (default) drops the server slot identifier recorded in the request so the server picks an idle slot.
- `--model NAME` overrides the recorded model name; `STATEFRAME_MODEL` is used when set.
- `--max-requests` caps the total (40 by default). `--allow-remote` is required for a non-loopback server.
- `FRAMELAB_API_KEY` adds a bearer token, never stored in results.

Small `n` gives a description, not an estimate. Before you believe a difference, rerun it with more samples and on
a second task.

## 6. Do it on your own run

```bash
stateframe run --repo path/to/repo --task "..."     # prints its run directory
framelab requests <run-dir>
framelab extract <run-dir> --at step:7 --out work/base.json
```

Pick the step where the model made the choice you want to change, then write variants against that request.

## 7. Inspect runs in the UI

```bash
framelab ui --data work
```

Then open http://127.0.0.1:8786/. The data folder may hold `runs/` (run directories), `experiments/` (result
folders such as `work/experiments/first`) and `grades/`; it can also be one run directory, or a folder of run
directories. With no `--data` the UI shows a small synthetic demo. If you use a source manifest, `experiments` is
the current key for experiment results; the older `frame_lab` key remains accepted. Runs show their timeline, the frame the model
saw at each step, files and the engine's summary. Grade files are described in
[the concepts page](docs/guide/concepts.md#grades). The pages are described in [The UI](docs/guide/ui.md).

## 8. Replay a run against a changed engine

A tape holds a run's recorded model responses. Serve it as an endpoint, point a new StateFrame run at it and the
engine code runs for real while the model's answers stay fixed:

```bash
framelab tape check <run-dir>
framelab tape serve --tape <run-dir> --port 8090 --upstream http://127.0.0.1:8080
STATEFRAME_ENDPOINT=http://127.0.0.1:8090/v1 stateframe run --repo ... --task "..."
framelab tape parity <new-run-dir> <run-dir>
```

`--upstream` serves routes other than chat (such as `/tokenize`). `parity` compares the two runs' requests after
masking per-run ids and reports the first one that differs. The relay answers 503 when the tape runs out; add
`--live-after N` to continue live from request N. To replay several tasks at once, give each tape a
`--marker NAME=TEXT` that appears only in that task's text.
