"""The license check fails on copyleft, source-available, non-commercial and unknown licenses, and passes this repo."""
from __future__ import annotations

import io
import sys
import unittest
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import license_inventory as inventory  # noqa: E402


class VerdictTest(unittest.TestCase):
    def test_permissive_licenses_pass(self) -> None:
        for expression in ("MIT", "Apache-2.0", "BSD-3-Clause", "ISC", "(MIT OR Apache-2.0)", "Python-2.0"):
            self.assertTrue(inventory.verdict(expression)[0], expression)

    def test_denied_licenses_fail_with_the_reason(self) -> None:
        for expression in ("GPL-3.0-only", "LGPL-2.1-or-later", "AGPL-3.0", "MIT AND AGPL-3.0", "SSPL-1.0",
                           "BUSL-1.1", "CC-BY-NC-4.0", "MPL-2.0"):
            ok, why = inventory.verdict(expression)
            self.assertFalse(ok, expression)
            self.assertIn("denied license", why)

    def test_unknown_and_unlisted_licenses_fail(self) -> None:
        self.assertEqual(inventory.verdict("UNKNOWN"), (False, "no license declared"))
        self.assertEqual(inventory.verdict(""), (False, "no license declared"))
        self.assertFalse(inventory.verdict("WTFPL")[0])

    def test_optional_python_dependencies_are_permissive(self) -> None:
        for dist, expression in inventory.OPTIONAL_PYTHON.values():
            self.assertTrue(inventory.verdict(expression)[0], dist)


class RepositoryTest(unittest.TestCase):
    def test_python_code_imports_only_stdlib_own_modules_or_declared_optionals(self) -> None:
        rows = inventory.python_rows()
        unexpected = [r for r in rows if r["module"].split(".")[0] not in inventory.OPTIONAL_PYTHON]
        self.assertEqual(unexpected, [])

    def test_full_check_passes_on_this_repository(self) -> None:
        out = io.StringIO()
        with redirect_stdout(out):
            code = inventory.main([])
        self.assertEqual(code, 0, out.getvalue())
        self.assertIn("LICENSE CHECK PASSED", out.getvalue())


if __name__ == "__main__":
    unittest.main()
