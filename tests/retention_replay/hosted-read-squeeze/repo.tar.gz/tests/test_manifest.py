"""Release manifest and backend checks on isolated source trees."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


manifest = load("manifest", ROOT / "scripts" / "manifest.py")
backend = load("fl_backend", ROOT / "_build" / "fl_backend.py")


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="framelab-manifest-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.manifest = self.root / "MANIFEST.txt"
        self.manifest.write_text(manifest.HEADER + "MANIFEST.txt\n", encoding="utf-8")
        self.root_patch = mock.patch.object(manifest, "ROOT", self.root)
        self.manifest_patch = mock.patch.object(manifest, "MANIFEST", self.manifest)
        self.root_patch.start()
        self.manifest_patch.start()
        self.addCleanup(self.root_patch.stop)
        self.addCleanup(self.manifest_patch.stop)

    def git(self, *args):
        subprocess.run(["git", "-C", str(self.root), *args], check=True, capture_output=True)

    def check(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            status = manifest.main(["check"])
        return status, output.getvalue()

    def test_checkout_uses_all_tracked_files_and_reports_both_directions(self):
        self.git("init", "-q")
        (self.root / "tracked.txt").write_text("payload", encoding="utf-8")
        (self.root / "vanished.txt").write_text("payload", encoding="utf-8")
        (self.root / "orphaned.txt").write_text("payload", encoding="utf-8")
        (self.root / "untracked.txt").write_text("local only", encoding="utf-8")
        self.git("add", "MANIFEST.txt", "tracked.txt", "vanished.txt", "orphaned.txt")
        (self.root / "vanished.txt").unlink()
        (self.root / "orphaned.txt").unlink()
        self.manifest.write_text(manifest.HEADER + "MANIFEST.txt\nmissing.txt\nvanished.txt\n", encoding="utf-8")
        status, output = self.check()
        self.assertEqual(status, 1)
        self.assertIn("listed but missing: missing.txt", output)
        self.assertIn("listed but missing: vanished.txt", output)
        self.assertIn("present but not listed: tracked.txt", output)
        self.assertIn("tracked but missing and not listed: orphaned.txt", output)
        self.assertNotIn("untracked.txt", output)
        self.assertNotIn(".git/", output)

    def test_refresh_sorts_tracked_payload_and_refresh_web_updates_only_web(self):
        self.git("init", "-q")
        dist = self.root / "ui" / "web" / "dist"
        dist.mkdir(parents=True)
        (dist / "new.js").write_text("new", encoding="utf-8")
        (self.root / "a.txt").write_text("a", encoding="utf-8")
        self.git("add", "MANIFEST.txt", "a.txt", "ui/web/dist/new.js")
        self.manifest.write_text(manifest.HEADER + "MANIFEST.txt\nui/web/dist/old.js\n", encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(manifest.main(["refresh-web"]), 1)
        self.assertEqual(manifest.listed(), ["MANIFEST.txt", "ui/web/dist/new.js"])
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(manifest.main(["refresh"]), 0)
        self.assertEqual(self.manifest.read_text(encoding="utf-8"),
                         manifest.HEADER + "MANIFEST.txt\na.txt\nui/web/dist/new.js\n")

    def test_non_git_walk_excludes_install_and_output_trees(self):
        (self.root / "source.txt").write_text("source", encoding="utf-8")
        for directory in (".git", ".venv", "venv", "__pycache__", "node_modules", "build", "dist", "_dist",
                          "work", "generated.egg-info", "custom-env"):
            path = self.root / directory
            path.mkdir()
            (path / "noise.txt").write_text("noise", encoding="utf-8")
        (self.root / "custom-env" / "pyvenv.cfg").write_text("home = /tmp", encoding="utf-8")
        web_dist = self.root / "ui" / "web" / "dist"
        web_dist.mkdir(parents=True)
        (web_dist / "index.html").write_text("bundled UI", encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(manifest.main(["refresh"]), 0)
        self.assertEqual(manifest.listed(), ["MANIFEST.txt", "source.txt", "ui/web/dist/index.html"])
        self.assertEqual(self.check()[0], 0)


class BackendManifestTests(unittest.TestCase):
    def test_wheel_and_sdist_name_missing_manifest_input(self):
        with tempfile.TemporaryDirectory(prefix="framelab-backend-") as directory:
            root = Path(directory)
            (root / "MANIFEST.txt").write_text("MANIFEST.txt\nmissing.js\n", encoding="utf-8")
            (root / "pyproject.toml").write_text('[project]\nname = "framelab"\nversion = "0.1.0"\n',
                                                 encoding="utf-8")
            with mock.patch.object(backend, "ROOT", root), mock.patch.object(backend, "MANIFEST", root / "MANIFEST.txt"):
                for build in (backend.build_wheel, backend.build_sdist):
                    with self.subTest(build=build.__name__), self.assertRaisesRegex(backend.BuildError, "missing.js"):
                        build(directory)

    def test_release_listing_check_builds_valid_temp_payload(self):
        with tempfile.TemporaryDirectory(prefix="framelab-release-test-") as directory:
            root = Path(directory)
            paths = ["MANIFEST.txt", "README.md", "pyproject.toml", "src/framelab/__init__.py",
                     "_build/fl_backend.py", "scripts/build_release.py", "scripts/check_release.py"]
            for name in paths[4:]:
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT / name, target)
            package = root / "src" / "framelab"
            package.mkdir(parents=True)
            (package / "__init__.py").write_text('__version__ = "0.1.0"\n', encoding="utf-8")
            (root / "README.md").write_text("Frame Lab test package\n", encoding="utf-8")
            (root / "pyproject.toml").write_text(
                '[project]\nname = "framelab"\nversion = "0.1.0"\ndescription = "test"\n'
                'license = "AGPL-3.0-only"\nrequires-python = ">=3.11"\nreadme = "README.md"\n', encoding="utf-8")
            (root / "MANIFEST.txt").write_text(manifest.HEADER + "\n".join(sorted(paths)) + "\n",
                                                 encoding="utf-8")
            result = subprocess.run([sys.executable, "-B", str(root / "scripts" / "check_release.py")],
                                    cwd=root, capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("release listings verified:", result.stdout)
