"""Frame Lab CLI tests. Stdlib unittest only; no model server, network or StateFrame install needed."""
from __future__ import annotations

import contextlib
import hashlib
import http.client
import http.server
import importlib.util
import io
import json
import os
import signal
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from framelab import FrameLabError  # noqa: E402
from framelab import cli, journal, scoring, tape, transport, variants  # noqa: E402
from framelab.experiment import execute, extract_base, load_base, render_markdown  # noqa: E402

_spec = importlib.util.spec_from_file_location("make_sample_run", ROOT / "examples" / "make_sample_run.py")
sample = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sample)


class SampleRunCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="framelab-test-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.journal = sample.build(self.tmp / "run")
        self.run_dir = self.tmp / "run"

    def rewrite(self, mutate):
        lines = [json.loads(line) for line in self.journal.read_text().splitlines()]
        lines = mutate(lines)
        self.journal.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in lines))


class UICommandTests(unittest.TestCase):
    def test_ui_starts_when_source_script_exists(self):
        with tempfile.TemporaryDirectory(prefix="framelab-ui-test-") as temp:
            root = Path(temp)
            marker = root / "started"
            (root / "start.sh").write_text('#!/bin/sh\n: > "$FRAMELAB_TEST_MARKER"\n', encoding="utf-8")
            with mock.patch.object(cli, "_ui_root", return_value=root), \
                    mock.patch.dict(os.environ, {"FRAMELAB_TEST_MARKER": str(marker)}):
                self.assertEqual(cli.main(["ui", "--port", "12345"]), 0)
            self.assertTrue(marker.is_file())

    def test_ui_missing_source_prints_clone_instructions_and_returns_two(self):
        with tempfile.TemporaryDirectory(prefix="framelab-ui-test-") as temp:
            stderr = io.StringIO()
            with mock.patch.object(cli, "_ui_root", return_value=Path(temp) / "missing-ui"), \
                    contextlib.redirect_stderr(stderr):
                status = cli.main(["ui"])
        self.assertEqual(status, 2)
        self.assertEqual(
            stderr.getvalue().splitlines(),
            ["framelab: The Frame Lab UI ships in the source repository. Clone it and run `pip install -e .` from the cloned repository."],
        )

    def test_sigint_stops_real_demo_server_without_traceback(self):
        with tempfile.TemporaryDirectory(prefix="framelab-ui-cli-") as directory:
            bin_dir = Path(directory) / "bin"
            bin_dir.mkdir()
            (bin_dir / "python3").symlink_to(sys.executable)
            env = dict(os.environ, PATH=f"{bin_dir}:/usr/bin:/bin", PYTHONPATH=str(ROOT / "src"))
            with socket.socket() as sock:
                sock.bind(("127.0.0.1", 0))
                port = sock.getsockname()[1]
            process = subprocess.Popen([sys.executable, "-B", "-m", "framelab", "ui", "--port", str(port)],
                                       cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            def stop_if_running():
                if process.poll() is None:
                    process.send_signal(signal.SIGINT)
                try:
                    process.communicate(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.communicate()
            self.addCleanup(stop_if_running)
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    self.fail(f"UI CLI exited before readiness: {process.communicate()}")
                try:
                    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=0.5)
                    connection.request("GET", "/api/health")
                    response = connection.getresponse()
                    response.read()
                    connection.close()
                    if response.status == 200:
                        break
                except OSError:
                    time.sleep(0.05)
            else:
                self.fail("demo server did not become ready")
            process.send_signal(signal.SIGINT)
            stdout, stderr = process.communicate(timeout=10)
            self.assertEqual(process.returncode, 0, stderr)
            self.assertIn("Frame Lab UI stopped.", stdout)
            self.assertNotIn("Traceback", stdout + stderr)
            # The child owns the listener. A successful bind proves it has released the port.
            with socket.socket() as probe:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                probe.bind(("127.0.0.1", port))


class JournalTests(SampleRunCase):
    def test_lists_every_submitted_request(self):
        rows = journal.list_requests(journal.load_journal(self.run_dir))
        self.assertEqual([r["step"] for r in rows], [0, 1, 2])
        self.assertTrue(all(r["tools"] == 4 and r["messages"] == 3 for r in rows))

    def test_sample_externalizes_large_values_as_blobs(self):
        raw = [json.loads(line) for line in self.journal.read_text().splitlines()]
        submitted = [r for r in raw if r["kind"] == "request_submitted"]
        self.assertTrue(all("$blob" in r["payload_utf8"] for r in submitted), "fixture must exercise blob hydration")

    def test_resolves_step_sequence_and_request_id_to_the_same_request(self):
        records = journal.load_journal(self.run_dir)
        by_step = journal.resolve_request(records, "step:1")
        self.assertEqual(journal.resolve_request(records, "1").request_id, by_step.request_id)
        self.assertEqual(journal.resolve_request(records, f"seq:{by_step.submitted['sequence']}").request_id, by_step.request_id)
        self.assertEqual(journal.resolve_request(records, by_step.request_id).request_id, by_step.request_id)
        self.assertEqual(by_step.response["response"]["choices"][0]["message"]["tool_calls"][0]["function"]["name"], "replace_in_file")

    def test_unknown_step_is_refused(self):
        with self.assertRaisesRegex(FrameLabError, "no model request at step 9"):
            journal.resolve_request(journal.load_journal(self.run_dir), "step:9")

    def test_payload_hash_mismatch_is_refused(self):
        def tamper(rows):
            for r in rows:
                if r["kind"] == "request_submitted" and r["step"] == 1:
                    r["payload_hash"] = "sha256:" + "0" * 64
            return rows
        self.rewrite(tamper)
        with self.assertRaisesRegex(FrameLabError, "payload hash mismatch"):
            journal.resolve_request(journal.load_journal(self.run_dir), "step:1")

    def test_missing_and_corrupt_blobs_are_refused(self):
        blobs = sorted((self.journal.parent / "blobs").iterdir())
        blobs[0].write_bytes(__import__("zlib").compress(b'"tampered"'))
        with self.assertRaisesRegex(FrameLabError, "does not match its recorded hash"):
            journal.load_journal(self.run_dir)
        blobs[0].unlink()
        with self.assertRaisesRegex(FrameLabError, "missing"):
            journal.load_journal(self.run_dir)

    def test_sequence_gap_and_mixed_runs_are_refused(self):
        self.rewrite(lambda rows: rows[:2] + rows[3:])
        with self.assertRaisesRegex(FrameLabError, "sequence gap"):
            journal.load_journal(self.run_dir)
        sample.build(self.run_dir)

        def mixed(rows):
            rows[-1]["run_id"] = "f" * 32
            return rows
        self.rewrite(mixed)
        with self.assertRaisesRegex(FrameLabError, "more than one run"):
            journal.load_journal(self.run_dir)

    def test_record_hash_chain_is_checked_when_present(self):
        def chain(rows):
            previous = None
            for r in rows:
                if previous:
                    r["previous_hash"] = previous
                body = dict(r)
                r["record_hash"] = "sha256:" + hashlib.sha256(
                    json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
                previous = r["record_hash"]
            return rows
        self.rewrite(chain)
        self.assertEqual(len(journal.load_journal(self.run_dir)), 11)

        def broken(rows):
            rows[4]["step"] = 7
            return rows
        self.rewrite(broken)
        with self.assertRaisesRegex(FrameLabError, "record hash mismatch"):
            journal.load_journal(self.run_dir)

    def test_run_directory_needs_exactly_one_journal(self):
        with self.assertRaisesRegex(FrameLabError, "exactly one"):
            journal.find_journal(self.tmp)


class VariantTests(SampleRunCase):
    def setUp(self):
        super().setUp()
        self.base = extract_base(self.journal, "step:1")

    def apply(self, *edits):
        return variants.apply_variant(self.base, {"name": "v", "edits": list(edits)})

    def test_noop_reproduces_the_recorded_bytes(self):
        body, _ = self.apply({"op": "noop"})
        self.assertEqual(transport.wire_bytes(body).decode(), self.base["request_wire_utf8"])

    def test_base_is_never_mutated(self):
        before = json.dumps(self.base, sort_keys=True)
        self.apply({"op": "remove_message", "selector": {"role": "system"}}, {"op": "set_tool_menu", "menu": ["done"]})
        self.assertEqual(json.dumps(self.base, sort_keys=True), before)

    def test_text_edits(self):
        body, audit = self.apply({"op": "replace_text", "selector": {"role": "user", "contains": "[Requirements]"},
                                  "anchor": "(open)", "replacement": "(closed)"})
        self.assertIn("(closed)", body["messages"][2]["content"])
        body, _ = self.apply({"op": "remove_text", "selector": {"message_index": 1}, "anchor": " at checkout"})
        self.assertNotIn("at checkout", body["messages"][1]["content"])
        body, _ = self.apply({"op": "remove_lines", "selector": {"message_index": 2}, "line_contains": "[Turn]"})
        self.assertNotIn("[Turn]", body["messages"][2]["content"])
        body, _ = self.apply({"op": "replace_message", "selector": {"message_index": 1}, "text": "new task"})
        self.assertEqual(body["messages"][1]["content"], "new task")
        body, _ = self.apply({"op": "add_line", "selector": {"message_index": 1}, "placement": "start", "text": "first"})
        self.assertTrue(body["messages"][1]["content"].startswith("first\n"))

    def test_anchor_count_must_match_exactly(self):
        with self.assertRaisesRegex(FrameLabError, "found 0 time"):
            self.apply({"op": "replace_text", "selector": {"message_index": 1}, "anchor": "absent", "replacement": "x"})
        with self.assertRaisesRegex(FrameLabError, "found 119 time"):
            self.apply({"op": "remove_text", "selector": {"message_index": 2}, "anchor": "# pricing helper"})
        body, _ = self.apply({"op": "remove_text", "selector": {"message_index": 2}, "anchor": "# pricing helper",
                              "expected_occurrences": 119})
        self.assertNotIn("# pricing helper", body["messages"][2]["content"])

    def test_selectors(self):
        with self.assertRaisesRegex(FrameLabError, "matched no messages"):
            self.apply({"op": "remove_message", "selector": {"role": "tool"}})
        with self.assertRaisesRegex(FrameLabError, "out of range"):
            self.apply({"op": "remove_message", "selector": {"message_index": 9}})
        with self.assertRaisesRegex(FrameLabError, "exceeds"):
            self.apply({"op": "remove_message", "selector": {"role": "system", "occurrence": 2}})
        body, _ = self.apply({"op": "remove_message", "selector": {"role": "user", "occurrence": 2}})
        self.assertEqual([m["role"] for m in body["messages"]], ["system", "user"])
        self.assertIn("[Requirements]", body["messages"][1]["content"])

    def test_state_card_removal(self):
        body, audit = self.apply({"op": "remove_harness_card"})
        self.assertEqual(body["messages"][0]["content"], "")
        self.assertIn("remove_harness_card", audit[0])

    def test_tool_menu(self):
        body, _ = self.apply({"op": "set_tool_menu", "menu": ["done", "read_file"]})
        self.assertEqual([t["function"]["name"] for t in body["tools"]], ["done", "read_file"])
        with self.assertRaisesRegex(FrameLabError, "no definition"):
            self.apply({"op": "set_tool_menu", "menu": ["delete_everything"]})
        with self.assertRaisesRegex(FrameLabError, "twice"):
            self.apply({"op": "set_tool_menu", "menu": ["done", "done"]})
        custom = {"type": "function", "function": {"name": "ask_user", "parameters": {"type": "object"}}}
        body, _ = self.apply({"op": "set_tool_menu", "menu": [custom]})
        self.assertEqual(body["tools"], [custom])

    def test_catalog_lets_a_variant_reoffer_an_earlier_tool(self):
        base = dict(self.base)
        base["request"] = dict(base["request"], tools=[t for t in base["request"]["tools"] if t["function"]["name"] != "done"])
        body, _ = variants.apply_variant(base, {"edits": [{"op": "set_tool_menu", "menu": ["done"]}]})
        self.assertEqual(body["tools"][0]["function"]["name"], "done")

    def test_unknown_op_and_bad_files(self):
        with self.assertRaisesRegex(FrameLabError, "unsupported op"):
            self.apply({"op": "rewrite_everything"})
        bad = self.tmp / "v.json"
        bad.write_text(json.dumps({"schema": "framelab/variants/1", "variants": [{"name": "a"}, {"name": "a"}]}))
        with self.assertRaisesRegex(FrameLabError, "duplicate"):
            variants.load_variants(bad)
        bad.write_text(json.dumps({"schema": "other", "variants": [{}]}))
        with self.assertRaisesRegex(FrameLabError, "schema"):
            variants.load_variants(bad)

    def test_saved_base_is_reverified(self):
        path = self.tmp / "base.json"
        path.write_text(json.dumps(self.base))
        self.assertEqual(load_base(path)["source"]["step"], 1)
        edited = json.loads(path.read_text())
        edited["request"]["temperature"] = 1.5
        path.write_text(json.dumps(edited))
        with self.assertRaisesRegex(FrameLabError, "differs from its recorded wire"):
            load_base(path)

    def test_shipped_examples_validate(self):
        base = extract_base(sample.build(self.tmp / "again"), "step:1")
        for variant in variants.load_variants(ROOT / "examples" / "variants.json"):
            variants.apply_variant(base, variant)
        scoring.load_scorer(ROOT / "examples" / "scorer.json")


def completion(name=None, arguments=None, content=None, finish="tool_calls"):
    message = {"role": "assistant", "content": content}
    if name:
        message["tool_calls"] = [{"id": "c", "type": "function", "function": {"name": name, "arguments": json.dumps(arguments)}}]
    return {"choices": [{"message": message, "finish_reason": finish}], "usage": {"prompt_tokens": 10, "completion_tokens": 3}}


class ScoringTests(unittest.TestCase):
    def test_first_action(self):
        action = scoring.first_action(completion("replace_in_file", {"path": "pricing.py"}))
        self.assertEqual((action["kind"], action["tool"], action["arguments"]), ("tool_call", "replace_in_file", {"path": "pricing.py"}))
        self.assertEqual(scoring.first_action(completion(content="hello", finish="stop"))["kind"], "content")
        self.assertIsNone(scoring.first_action({"choices": []}))

    def test_targets(self):
        action = scoring.first_action(completion("replace_in_file", {"path": "pricing.py", "new": "discount / 100"}))
        self.assertTrue(scoring.score(action, {"tool": "replace_in_file"}))
        self.assertTrue(scoring.score(action, {"tools": ["read_file", "replace_in_file"]}))
        self.assertFalse(scoring.score(action, {"tool": "read_file"}))
        self.assertTrue(scoring.score(action, {"argument_path": ["path"], "selector_in": ["pricing.py"]}))
        self.assertFalse(scoring.score(action, {"argument_path": ["path"], "selector_in": ["other.py"]}))
        self.assertTrue(scoring.score(action, {"argument_contains": ["discount", "pricing"]}))
        self.assertFalse(scoring.score(action, {"argument_contains": ["discount", "absent"]}))
        self.assertTrue(scoring.score(action, {"argument_any_contains": ["absent", "discount"]}))
        text = scoring.first_action(completion(content="All tests pass.", finish="stop"))
        self.assertTrue(scoring.score(text, {"text_contains": "tests pass"}))
        self.assertFalse(scoring.score(text, {"tool": "done"}))
        self.assertFalse(scoring.score(None, {"tool": "done"}))

    def test_bad_targets_are_refused(self):
        for target in ({"tool": "x", "typo": 1}, {"selector_in": ["a"]}, {"argument_contains": "a"}, {"kind": "other"}):
            with self.assertRaises(FrameLabError):
                scoring.validate_target(target)


class TransportTests(unittest.TestCase):
    def test_chat_url(self):
        self.assertEqual(transport.chat_url("http://127.0.0.1:8080/v1"), "http://127.0.0.1:8080/v1/chat/completions")
        self.assertEqual(transport.chat_url("http://localhost:8080/v1/chat/completions/"), "http://localhost:8080/v1/chat/completions")
        with mock.patch.dict(os.environ, {"STATEFRAME_ENDPOINT": "http://[::1]:9000/v1"}):
            self.assertEqual(transport.chat_url(None), "http://[::1]:9000/v1/chat/completions")
        with mock.patch.dict(os.environ, {}, clear=True), self.assertRaisesRegex(FrameLabError, "no endpoint"):
            transport.chat_url(None)
        for bad in ("ftp://x/v1", "http://user:pw@127.0.0.1/v1", "127.0.0.1:8080"):
            with self.assertRaises(FrameLabError):
                transport.chat_url(bad)

    def test_remote_endpoints_need_explicit_permission(self):
        transport.require_allowed("http://127.0.0.1:1/v1/chat/completions", False)
        transport.require_allowed("http://[::1]:1/v1/chat/completions", False)
        with self.assertRaisesRegex(FrameLabError, "allow-remote"):
            transport.require_allowed("http://10.0.0.5:8080/v1/chat/completions", False)
        transport.require_allowed("http://10.0.0.5:8080/v1/chat/completions", True)

    def test_seed_and_slot(self):
        body = {"seed": 7, "id_slot": 3}
        self.assertEqual([transport.apply_seed(body, "vary", i)["seed"] for i in range(3)], [8, 9, 10])
        self.assertEqual(transport.apply_seed(body, "keep", 2)["seed"], 7)
        self.assertNotIn("seed", transport.apply_seed({}, "vary", 0))
        self.assertNotIn("id_slot", transport.apply_slot(body, "free"))
        self.assertEqual(transport.apply_slot(body, "keep")["id_slot"], 3)


class StubModel(http.server.BaseHTTPRequestHandler):
    """A fake OpenAI-compatible server: answers by what the request offers and records headers."""
    seen: list = []

    def log_message(self, *_):
        return

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        StubModel.seen.append({"auth": self.headers.get("Authorization"), "body": body, "path": self.path})
        names = [t["function"]["name"] for t in body.get("tools", [])]
        if "fail" in json.dumps(body["messages"]):
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"secret-key-123 exploded")
            return
        if "run_tests" in names:
            reply = completion("run_tests", {"target": "tests"})
        else:
            reply = completion("replace_in_file", {"path": "pricing.py", "old": "x", "new": "discount / 100"})
        data = json.dumps(reply).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def start(handler) -> tuple[http.server.ThreadingHTTPServer, str]:
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"http://127.0.0.1:{server.server_address[1]}"


class ExperimentTests(SampleRunCase):
    def setUp(self):
        super().setUp()
        StubModel.seen = []
        self.server, self.url = start(StubModel)
        self.addCleanup(self.server.server_close)
        self.addCleanup(self.server.shutdown)
        self.base = extract_base(self.journal, "step:1")
        self.scorer = scoring.load_scorer(ROOT / "examples" / "scorer.json")

    def test_end_to_end_against_a_live_server(self):
        menu = [{"name": "full", "edits": []}, {"name": "edit-only", "edits": [{"op": "set_tool_menu", "menu": ["replace_in_file"]}]}]
        with mock.patch.dict(os.environ, {"FRAMELAB_API_KEY": "secret-key-123"}):
            result = execute(self.base, menu, self.scorer, url=transport.chat_url(self.url + "/v1"), n=2, model="other-model")
        by_name = {v["name"]: v for v in result["variants"]}
        self.assertEqual(by_name["full"]["hits"], 0)
        self.assertEqual(by_name["full"]["tool_distribution"], {"run_tests": 2})
        self.assertEqual(by_name["edit-only"]["hits"], 2)
        self.assertEqual(len(StubModel.seen), 4)
        self.assertTrue(all(s["auth"] == "Bearer secret-key-123" and s["path"] == "/v1/chat/completions" for s in StubModel.seen))
        self.assertEqual({s["body"]["seed"] for s in StubModel.seen}, {1235, 1236})
        self.assertTrue(all("id_slot" not in s["body"] and s["body"]["model"] == "other-model" for s in StubModel.seen))
        self.assertNotIn("secret-key-123", json.dumps(result) + render_markdown(result))

    def test_http_errors_are_recorded_and_redacted(self):
        failing = [{"name": "boom", "edits": [{"op": "replace_message", "selector": {"message_index": 1}, "text": "fail"}]}]
        with mock.patch.dict(os.environ, {"FRAMELAB_API_KEY": "secret-key-123"}):
            result = execute(self.base, failing, self.scorer, url=transport.chat_url(self.url + "/v1"), n=1)
        sample_ = result["variants"][0]["samples"][0]
        self.assertTrue(sample_["error"].startswith("http 500"))
        self.assertNotIn("secret-key-123", json.dumps(result))
        self.assertFalse(sample_["hit"])

    def test_unreachable_endpoint_is_a_recorded_outcome(self):
        result = execute(self.base, [{"name": "a"}], self.scorer, url="http://127.0.0.1:9/v1/chat/completions", n=1, timeout_s=2)
        self.assertEqual(result["transport_errors"], 1)
        self.assertIn("transport", result["variants"][0]["samples"][0]["error"])

    def test_truncated_responses_never_score(self):
        def send(body, url, timeout_s):
            return {"response": completion("replace_in_file", {"path": "pricing.py", "x": "discount"}, finish="length"), "elapsed_ns": 1}
        result = execute(self.base, [{"name": "a"}], self.scorer, url="http://127.0.0.1:1/v1/chat/completions", n=1, send=send)
        self.assertEqual(result["variants"][0]["hits"], 0)
        self.assertTrue(result["variants"][0]["samples"][0]["truncated"])

    def test_budget_and_remote_guards(self):
        with self.assertRaisesRegex(FrameLabError, "above --max-requests"):
            execute(self.base, [{"name": "a"}, {"name": "b"}], self.scorer, url=self.url + "/v1/chat/completions", n=30)
        with self.assertRaisesRegex(FrameLabError, "allow-remote"):
            execute(self.base, [{"name": "a"}], self.scorer, url="http://203.0.113.9/v1/chat/completions", n=1)
        self.assertEqual(StubModel.seen, [])

    def test_cli_round_trip(self):
        base = self.tmp / "base.json"
        out = self.tmp / "out" / "result.json"
        quiet = io.StringIO()
        with contextlib.redirect_stdout(quiet), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(cli.main(["extract", str(self.run_dir), "--at", "1", "--out", str(base)]), 0)
            self.assertEqual(cli.main(["validate", "--base", str(base), "--variants", str(ROOT / "examples" / "variants.json"),
                                       "--scorer", str(ROOT / "examples" / "scorer.json")]), 0)
            self.assertEqual(cli.main(["run", "--base", str(base), "--variants", str(ROOT / "examples" / "variants.json"),
                                       "--scorer", str(ROOT / "examples" / "scorer.json"), "--endpoint", self.url + "/v1",
                                       "--n", "1", "--out", str(out)]), 0)
        result = json.loads(out.read_text())
        self.assertEqual([v["name"] for v in result["variants"]], ["control", "without-state-card", "test-first-hint", "edit-tools-only"])
        self.assertEqual(result["variants"][-1]["hits"], 1)
        self.assertIn("| `edit-tools-only` | 1/1 |", out.with_suffix(".md").read_text())
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            self.assertEqual(cli.main(["extract", str(self.run_dir), "--at", "step:42", "--out", str(base)]), 2)
        self.assertIn("no model request at step 42", err.getvalue())


class TapeTests(SampleRunCase):
    def post(self, url, body, path="/v1/chat/completions"):
        host, port = url.split("//")[1].split(":")
        conn = http.client.HTTPConnection(host, int(port), timeout=10)
        try:
            conn.request("POST", path, body=json.dumps(body), headers={"Content-Type": "application/json"})
            reply = conn.getresponse()
            return reply.status, json.loads(reply.read() or b"{}")
        finally:
            conn.close()

    def serve(self, tapes, **kwargs):
        server = tape.serve(tapes, port=0, log_path=self.tmp / "relay.jsonl", **kwargs)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return f"http://127.0.0.1:{server.server_address[1]}"

    def test_check_and_self_parity(self):
        info = tape.check(self.run_dir)
        self.assertEqual((info["responses"], info["requests"]), (3, 3))
        report = tape.parity(self.run_dir, self.run_dir)
        self.assertEqual((report["identical"], report["first_difference"]), (3, None))

    def test_parity_masks_run_ids_but_finds_real_changes(self):
        other = self.tmp / "other"
        shutil.copytree(self.run_dir, other)
        path = journal.find_journal(other)
        path.write_text(path.read_text().replace(sample.RUN_ID, "f" * 32))
        self.assertIsNone(tape.parity(other, self.run_dir)["first_difference"])
        changed = sample.TASK.replace("80.00", "90.00")
        with mock.patch.object(sample, "TASK", changed):
            sample.build(other)
        report = tape.parity(other, self.run_dir)
        self.assertEqual(report["first_difference"]["where"], {"field": "messages", "message_index": 1})

    def test_relay_serves_recorded_responses_in_order_then_stops(self):
        url = self.serve([tape.load_tape("sample", self.run_dir)])
        names = []
        for _ in range(3):
            status, reply = self.post(url, {"messages": [{"role": "user", "content": "anything"}]})
            self.assertEqual(status, 200)
            names.append(reply["choices"][0]["message"]["tool_calls"][0]["function"]["name"])
        self.assertEqual(names, ["read_file", "replace_in_file", "run_tests"])
        self.assertEqual(self.post(url, {"messages": []})[0], 503)
        self.assertEqual(self.post(url, {}, path="/tokenize")[0], 502)
        kinds = [json.loads(line)["kind"] for line in (self.tmp / "relay.jsonl").read_text().splitlines()]
        self.assertEqual(kinds, ["served", "served", "served", "tape_end", "no_upstream"])

    def test_relay_forwards_other_routes_and_live_after(self):
        upstream, upstream_url = start(StubModel)
        self.addCleanup(upstream.server_close)
        self.addCleanup(upstream.shutdown)
        url = self.serve([tape.load_tape("sample", self.run_dir)], upstream=upstream_url, live_after=1)
        first = self.post(url, {"messages": [{"role": "user", "content": "x"}]})[1]
        self.assertEqual(first["choices"][0]["message"]["tool_calls"][0]["function"]["name"], "read_file")
        live = self.post(url, {"messages": [{"role": "user", "content": "x"}], "tools": []})[1]
        self.assertEqual(live["choices"][0]["message"]["tool_calls"][0]["function"]["name"], "replace_in_file")

    def test_several_tapes_route_by_marker_and_refuse_ambiguity(self):
        second = self.tmp / "second"
        sample.build(second)
        with self.assertRaisesRegex(FrameLabError, "--marker"):
            tape.make_handler([tape.load_tape("a", self.run_dir), tape.load_tape("b", second)], None, self.tmp / "l.jsonl")
        url = self.serve([tape.load_tape("a", self.run_dir, ["alpha-task"]), tape.load_tape("b", second, ["beta-task"])])
        self.assertEqual(self.post(url, {"messages": [{"role": "user", "content": "beta-task"}]})[0], 200)
        self.assertEqual(self.post(url, {"messages": [{"role": "user", "content": "alpha-task beta-task"}]})[0], 500)
        self.assertEqual(self.post(url, {"messages": [{"role": "user", "content": "neither"}]})[0], 500)


if __name__ == "__main__":
    unittest.main()
