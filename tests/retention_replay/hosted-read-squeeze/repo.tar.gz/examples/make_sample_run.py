#!/usr/bin/env python3
"""Write a small synthetic StateFrame run in the engine's journal format.

The run is invented: a two-turn bug fix in a toy repository. It lets you try every Frame Lab
command without a model server. Re-running the script reproduces the same bytes.

    python3 examples/make_sample_run.py examples/sample-run
"""
from __future__ import annotations

import hashlib
import json
import sys
import zlib
from pathlib import Path

RUN_ID = "0123456789abcdef0123456789abcdef"
BLOB_THRESHOLD = 4096


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def tool(name: str, description: str, properties: dict) -> dict:
    return {"type": "function", "function": {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties, "required": sorted(properties)}}}


TOOLS = [
    tool("read_file", "Read a file in the workspace.", {"path": {"type": "string"}}),
    tool("replace_in_file", "Replace exact text in a file.",
         {"path": {"type": "string"}, "old": {"type": "string"}, "new": {"type": "string"}}),
    tool("run_tests", "Run the project's tests.", {"target": {"type": "string"}}),
    tool("done", "Finish when the requirements are met.", {"summary": {"type": "string"}}),
]

STATE_CARD = (
    "StateFrame is your current working state. Requirements define success; receipts record what was observed.\n"
    "Edits can make a receipt stale. Use the frame to choose the next action that closes evidence gaps; it does not certify correctness.\n"
)

TASK = ("Discounts are charged wrong at checkout: a 25% discount on an 80.00 order should cost 60.00. "
        "Fix the pricing code so tests/test_pricing.py passes.")


def frame(step: int, receipts: list[str]) -> str:
    lines = ["[Requirements]", "R1 discount applies as a percentage of the subtotal (open)", "",
             "[Workspace]", "pricing.py  tests/test_pricing.py", "", "[Receipts]"]
    lines += receipts or ["none yet"]
    lines += ["", f"[Turn] {step}"]
    # Pad the frame with a file view so the request crosses the journal's blob threshold.
    lines += ["", "[Current source] pricing.py"] + [f"{n:>4}  # pricing helper line {n}" for n in range(1, 120)]
    return "\n".join(lines)


def request(step: int, receipts: list[str]) -> dict:
    return {
        "model": "local-model", "temperature": 0.2, "max_tokens": 2048, "seed": 1234, "id_slot": 0,
        "messages": [{"role": "system", "content": STATE_CARD},
                     {"role": "user", "content": TASK},
                     {"role": "user", "content": frame(step, receipts)}],
        "tools": TOOLS, "tool_choice": "auto",
    }


def response(call_id: str, name: str, arguments: dict, prompt_tokens: int) -> dict:
    return {"id": f"chatcmpl-{call_id}", "object": "chat.completion", "model": "local-model",
            "choices": [{"index": 0, "finish_reason": "tool_calls", "message": {
                "role": "assistant", "content": None,
                "tool_calls": [{"id": call_id, "type": "function",
                                "function": {"name": name, "arguments": json.dumps(arguments)}}]}}],
            "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": 31, "total_tokens": prompt_tokens + 31}}


class Journal:
    def __init__(self, directory: Path):
        self.dir = directory
        self.blobs = directory / "blobs"
        self.blobs.mkdir(parents=True, exist_ok=True)
        self.lines: list[bytes] = []
        self.sequence = 0

    def _externalize(self, value: object) -> object:
        data = canonical(value)
        if len(data) <= BLOB_THRESHOLD:
            return value
        digest = hashlib.sha256(data).hexdigest()
        (self.blobs / f"{digest}.zlib").write_bytes(zlib.compress(data, 9))
        return {"$blob": digest, "bytes": len(data)}

    def emit(self, kind: str, **fields: object) -> str:
        self.sequence += 1
        event_id = f"{RUN_ID}:{self.sequence}"
        record = {key: self._externalize(value) for key, value in fields.items()}
        record.update({"schema": "stateframe-audit/1", "kind": kind, "run_id": RUN_ID, "task_id": "sample-discount-fix",
                       "event_id": event_id, "sequence": self.sequence, "timestamp_ns": 1767225600000000000 + self.sequence})
        self.lines.append(canonical(record) + b"\n")
        return event_id

    def save(self) -> Path:
        path = self.dir / "events.jsonl"
        path.write_bytes(b"".join(self.lines))
        return path


def build(out: Path) -> Path:
    journal = Journal(out / "worker" / "measurement-runs" / RUN_ID)
    journal.emit("run_started", manifest={"engine": "stateframe", "sample": True})
    turns = [
        ([], "read_file", {"path": "pricing.py"}),
        (["read pricing.py: discount subtracts a flat amount"], "replace_in_file",
         {"path": "pricing.py", "old": "subtotal - discount", "new": "subtotal * (1 - discount / 100)"}),
        (["read pricing.py", "edited pricing.py line 12"], "run_tests", {"target": "tests/test_pricing.py"}),
    ]
    for step, (receipts, name, arguments) in enumerate(turns):
        body = request(step, receipts)
        wire = json.dumps(body)
        request_id = f"{step + 1:032x}"
        journal.emit("request_prepared", request_id=request_id, step=step)
        attempt = journal.emit("request_submitted", request_id=request_id, step=step, payload=body,
                               payload_utf8=wire, payload_hash="sha256:" + hashlib.sha256(wire.encode()).hexdigest())
        journal.emit("response_received", request_id=request_id, step=step, transport_attempt_id=attempt,
                     response=response(f"call_{step}", name, arguments, 900 + 40 * step))
    journal.emit("run_finished", outcome="tests_pass")
    (out / "spec.json").write_text(json.dumps({"task": TASK, "sample": True}, indent=1, sort_keys=True) + "\n")
    # The run summary `stateframe run` writes (a subset of its fields).
    summary = {"requests": len(turns), "prompt_tokens_sent": sum(900 + 40 * s for s in range(len(turns))),
               "completion_tokens": 31 * len(turns), "wall_seconds": 42.0, "runtime_outcome": "done",
               "check_outcome": "passed", "exit_code": 0, "succeeded": True}
    (out / "summary.json").write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return journal.save()


if __name__ == "__main__":
    target = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).with_name("sample-run"))
    print(f"wrote {build(target)}")
