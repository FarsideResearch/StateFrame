# Frame Lab: repository guide for coding agents and contributors

Frame Lab is the experiment bench for people building or tuning agents on StateFrame. It takes one recorded model request, applies typed edits to a copy, sends each version to an OpenAI-compatible server, and scores the first response. It also inspects StateFrame run records and replays recorded model answers against a changed engine.

Frame Lab was built by and for coding agents running StateFrame experiments. Its command line is the native interface: agents can inspect requests, validate edits, run experiments, and keep the JSON results as files. People can use the same commands and the local read-only UI.

## Repository map

| Path | What it is |
|---|---|
| `src/framelab/` | The `framelab` command line. Python standard library only. |
| `ui/server.py`, `ui/fl_index/` | The local HTTP server and read-only indexers for runs, journals, frames, experiments and grades. Python standard library only. |
| `ui/web/` | The Vue app. `ui/web/dist` is the prebuilt bundle the server serves; `ui/web/src` is its source. |
| `ui/demo/` | Synthetic data shown when no source is configured. |
| `examples/` | A synthetic StateFrame run, the script that writes it, example variants and a scorer. |
| `tests/`, `ui/tests/`, `ui/web/tests/` | The three test suites. They do not need a model server. |
| `scripts/` | Release helpers and `check.sh`, which runs the test suites available in a fresh clone. |
| `docs/guide/` | Concepts, experiments, results, the UI, extending, troubleshooting and design rationale. |

## Install and inspect

Python 3.11 or newer is required. From the repository root:

```bash
pip install --no-index --no-build-isolation -e .
framelab requests examples/sample-run --json
framelab extract examples/sample-run --at step:1 --out work/base.json
framelab validate --base work/base.json --variants examples/variants.json --scorer examples/scorer.json
```

`requests --json` prints a machine-readable request list. `extract` writes the exact recorded request and its verified hash to `work/base.json`. `validate` applies the edits offline and refuses a mismatch before sending anything.

## Run an experiment

`framelab run` needs a local OpenAI-compatible model server. Set `STATEFRAME_ENDPOINT` to its `/v1` endpoint:

```bash
export STATEFRAME_ENDPOINT=http://127.0.0.1:8080/v1
framelab run --base work/base.json --variants examples/variants.json --scorer examples/scorer.json \
  --n 5 --out work/experiments/first/RESULTS.json
framelab render work/experiments/first/RESULTS.json
framelab ui --data work
```

`run` writes `RESULTS.json` and a Markdown report beside it. `render` rewrites that report. The UI reads the same run and experiment files without changing them. To inspect the bundled demo, run `framelab ui` with no `--data`.

The tape relay can exercise command wiring without a model server. Its recorded replies ignore the request content, so tape results do not measure variants:

```bash
framelab tape serve --tape examples/sample-run --port 8090
```

## StateFrame run compatibility

Frame Lab does not import StateFrame or gate on a StateFrame package version, and it declares no numeric version range. It reads run journals containing `request_submitted` events with exact `payload_utf8` bytes and a matching `payload_hash`. It checks those hashes and does not modify the run directory. Older journal formats without those fields are not supported.

## JSON and exit codes

- Use `framelab requests RUN --json` for a JSON request list.
- `framelab extract` writes a base JSON file. `framelab run` writes a result JSON file and Markdown report. `framelab render` writes the report again.
- Exit code 0 means success. Exit code 1 means a check failed or every run request failed in transport. Exit code 2 means invalid input or an unavailable UI source; the message describes the correction.

## Tests

```bash
python3 -B -m unittest tests.test_framelab
(cd ui && python3 -B -m unittest discover -s tests -t .)
(cd ui/web && npm test)
bash scripts/check.sh
```

The web suite needs Node.js 20 or newer and `npm ci` in `ui/web`. `scripts/check.sh` prints a clear skip message when `ui/web/node_modules` is absent.

## Where to go next

- [Quickstart](QUICKSTART.md): one experiment, variant edits, scoring and tape replay.
- [Concepts](docs/guide/concepts.md): run directories, journals, bases, variants, scorers and tapes.
- [Running experiments](docs/guide/running.md): every command and flag.
- [Reading results](docs/guide/results.md): result files and how far to trust them.
- [The UI](docs/guide/ui.md): pages and data sources.
- [Extending](docs/guide/extending.md): edit ops, scorer keys, UI pages and tests.
- [Troubleshooting](docs/guide/troubleshooting.md): common errors and fixes.
- [Design rationale](docs/guide/design.md): why Frame Lab is built this way.
- [Contributing](CONTRIBUTING.md): setup, tests and review.

Frame Lab is licensed under AGPL-3.0-only or a separate commercial license. See [COMMERCIAL-LICENSE.md](COMMERCIAL-LICENSE.md). Contributions require the signed [CLA](CLA.md).
