# Commercial license

StateFrame, including Frame Lab (part of the StateFrame project), is available under the GNU AGPLv3 or under a separate commercial license from Farside Research LLC. One commercial license covers both. For commercial terms, contact Farside Research.

Commercial use outside the AGPL requires a separate signed agreement; this file is not itself a license grant.

Contact: support@farsideresearch.com
