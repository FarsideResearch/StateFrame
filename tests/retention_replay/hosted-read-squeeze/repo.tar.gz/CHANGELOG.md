# Changelog

## Unreleased

- Open-source preparation with refreshed UI and documentation, contributor templates, and a consolidated local check script.
- `framelab ui` now gives a clear clone and editable-install instruction when the source UI is missing.

## 0.1.0 (preview)

First public release, alongside the StateFrame engine.

- `framelab` command line: `requests`, `extract`, `validate`, `run`, `render`, `ui`, and `tape serve | check | parity`.
- Typed variant edits with exact-match anchors; first-action scoring; loopback-only sending unless `--allow-remote`.
- Frame Lab UI: run timeline, frames, files, grades and result folders, read only, in the Farside Research design.
- Reads the run directories StateFrame writes, including its `summary.json`.
