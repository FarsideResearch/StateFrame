"""Stdlib-only PEP 517 build backend for Frame Lab (no setuptools, no downloads).

Install offline with:  pip install --no-index --no-build-isolation [-e] <this dir>
The wheel holds the ``framelab`` package. The sdist adds the UI (server, sources and the prebuilt
web bundle), the examples and the tests. Metadata comes from pyproject.toml.
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import io
import tarfile
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
PACKAGE = SRC / "framelab"
SKIP_PARTS = {"__pycache__"}
# The source package ships exactly the files listed in MANIFEST.txt (see scripts/manifest.py).
MANIFEST = ROOT / "MANIFEST.txt"
# 2026-01-01T00:00:00Z: fixed member time, so archives carry no build time or builder account.
SDIST_MTIME = 1767225600


class BuildError(RuntimeError):
    """A named release input is absent or invalid."""


def _required_file(path: Path) -> Path:
    if not path.is_file() or path.is_symlink():
        raise BuildError(f"Frame Lab release build requires regular file {path.relative_to(ROOT).as_posix()!r}")
    return path


def _manifest() -> list[str]:
    names = [line for line in _required_file(MANIFEST).read_text(encoding="utf-8").splitlines()
             if line and not line.startswith("#")]
    for name in names:
        path = ROOT / name
        if name.startswith("/") or ".." in Path(name).parts:
            raise BuildError(f"MANIFEST.txt contains invalid path {name!r}")
        _required_file(path)
    return sorted(set(names) | {"MANIFEST.txt"})


def _project() -> dict:
    return tomllib.loads(_required_file(ROOT / "pyproject.toml").read_text())["project"]


def _dist_name() -> str:
    project = _project()
    return f"{project['name'].replace('-', '_')}-{project['version']}"


def _metadata() -> str:
    project = _project()
    lines = ["Metadata-Version: 2.4", f"Name: {project['name']}", f"Version: {project['version']}",
             f"Summary: {project['description']}", f"License-Expression: {project['license']}",
             f"Requires-Python: {project['requires-python']}"]
    lines += [f"License-File: {name}" for name in project.get("license-files", [])]
    lines += [f"Classifier: {c}" for c in project.get("classifiers", [])]
    lines += [f"Requires-Dist: {d}" for d in project.get("dependencies", [])]
    readme = _required_file(ROOT / project.get("readme", "README.md"))
    lines.append("Description-Content-Type: text/markdown")
    return "\n".join(lines) + "\n\n" + readme.read_text()


def _entry_points() -> str:
    scripts = _project().get("scripts", {})
    return "[console_scripts]\n" + "".join(f"{k} = {v}\n" for k, v in scripts.items())


def _record_line(name: str, data: bytes) -> str:
    digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()
    return f"{name},sha256={digest},{len(data)}"


def _package_files() -> list[tuple[str, bytes]]:
    _required_file(PACKAGE / "__init__.py")
    return [(path.relative_to(SRC).as_posix(), path.read_bytes()) for path in sorted(PACKAGE.rglob("*.py"))
            if path.is_file() and not SKIP_PARTS & set(path.parts)]


def _write_wheel(directory: str, payload: list[tuple[str, bytes]]) -> str:
    name = _dist_name()
    info = f"{name}.dist-info"
    files = list(payload)
    files.append((f"{info}/METADATA", _metadata().encode()))
    files.append((f"{info}/WHEEL", b"Wheel-Version: 1.0\nGenerator: fl_backend\nRoot-Is-Purelib: true\nTag: py3-none-any\n"))
    files.append((f"{info}/entry_points.txt", _entry_points().encode()))
    for license_name in _project().get("license-files", []):
        files.append((f"{info}/licenses/{license_name}", _required_file(ROOT / license_name).read_bytes()))
    record = [_record_line(n, d) for n, d in files] + [f"{info}/RECORD,,"]
    files.append((f"{info}/RECORD", ("\n".join(record) + "\n").encode()))
    wheel_name = f"{name}-py3-none-any.whl"
    with zipfile.ZipFile(Path(directory) / wheel_name, "w", zipfile.ZIP_DEFLATED) as archive:
        for file_name, data in files:
            entry = zipfile.ZipInfo(file_name, date_time=(2026, 1, 1, 0, 0, 0))
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, data, zipfile.ZIP_DEFLATED)
    return wheel_name


def get_requires_for_build_wheel(config_settings=None):
    return []


def get_requires_for_build_editable(config_settings=None):
    return []


def get_requires_for_build_sdist(config_settings=None):
    return []


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    _manifest()
    return _write_wheel(wheel_directory, _package_files())


def build_editable(wheel_directory, config_settings=None, metadata_directory=None):
    return _write_wheel(wheel_directory, [("_framelab_editable.pth", (str(SRC) + "\n").encode())])


def _normalize(info: tarfile.TarInfo) -> tarfile.TarInfo:
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    info.mtime = SDIST_MTIME
    info.mode = 0o755 if info.mode & 0o111 else 0o644
    info.pax_headers = {}
    return info


def build_sdist(sdist_directory, config_settings=None):
    name = _dist_name()
    target = Path(sdist_directory) / f"{name}.tar.gz"
    shipped = _manifest()
    # GNU format: run journals keep their engine paths (run id + blob hash), which exceed the 100-byte ustar limit;
    # GNU long-name records carry only the path, where PAX headers would add an extended-header record per member.
    with open(target, "wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as gz, \
            tarfile.open(fileobj=gz, mode="w", format=tarfile.GNU_FORMAT) as archive:
        for relative in shipped:
            archive.add(ROOT / relative, arcname=f"{name}/{relative}", recursive=False, filter=_normalize)
        pkg_info = _metadata().encode()
        entry = _normalize(tarfile.TarInfo(f"{name}/PKG-INFO"))
        entry.size = len(pkg_info)
        archive.addfile(entry, io.BytesIO(pkg_info))
    return target.name


__all__ = ["build_editable", "build_sdist", "build_wheel", "get_requires_for_build_editable",
           "get_requires_for_build_sdist", "get_requires_for_build_wheel"]
