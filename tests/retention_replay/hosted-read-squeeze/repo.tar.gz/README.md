# Frame Lab

Frame Lab is an experiment bench for people building or tuning agents on StateFrame. It helps answer whether a change to what the model sees changes what it does, measured against the exact request StateFrame recorded. Choose one request, apply typed edits to a copy, send each version to an OpenAI-compatible server, and score the first response.

Frame Lab was built by and for coding agents running StateFrame experiments. The people who built StateFrame directed the work, but did not use Frame Lab day to day. That is why the native interface is a set of commands, with machine-readable JSON where it applies and each experiment saved as files. People can use it too. The local UI is read only, and the quickstart below walks through both ways to work.

Frame Lab also reads run records and can replay recorded model answers against a changed StateFrame engine. StateFrame is built and measured on software engineering work; support for general, non-coding tasks is in active development.

## Screenshots

![Frame Lab overview with the start-here guide](docs/assets/overview.png)

Overview with the start-here guide.

![A run's frame inspector](docs/assets/run-frames.png)

A run's frame inspector.

![An experiment result](docs/assets/experiment.png)

An experiment result.

## Human quickstart

Frame Lab requires Python 3.11 or newer. The command line and UI server use the Python standard library. Clone and install it:

```bash
git clone https://github.com/FarsideResearch/FrameLab.git
cd FrameLab
pip install --no-index --no-build-isolation -e .
```

Start the bundled demo:

```bash
framelab ui
```

Press Ctrl-C to stop it. To inspect the example run instead:

```bash
framelab ui --data examples/sample-run
```

The CLI can inspect the bundled synthetic StateFrame run without a model server. List its requests, extract one exact request, and validate the example edits and scorer:

```bash
framelab requests examples/sample-run
mkdir -p work
framelab extract examples/sample-run --at step:1 --out work/base.json
framelab validate --base work/base.json --variants examples/variants.json --scorer examples/scorer.json
```

A real experiment needs a local OpenAI-compatible model server. Set its endpoint, send each variant, then render the result again if you want a fresh Markdown report:

```bash
export STATEFRAME_ENDPOINT=http://127.0.0.1:8080/v1
framelab run --base work/base.json --variants examples/variants.json --scorer examples/scorer.json \
  --n 5 --out work/experiments/first/RESULTS.json
framelab render work/experiments/first/RESULTS.json
```

There is no offline or dry-run mode for `framelab run`. The tape relay can replay recorded answers while you test a changed engine, but it ignores each request and is not a substitute for a model server or a meaningful variant experiment.

For your own StateFrame records, give `framelab requests` and `framelab extract` a run directory or its `events.jsonl` file. Store results under `<data-folder>/experiments/` to have them appear in `framelab ui --data <data-folder>`.

See [QUICKSTART.md](QUICKSTART.md) for variant and scorer formats, tape replay, and a complete walkthrough.

## For agents

[AGENTS.md](AGENTS.md) describes the repository and the command interface. Use `framelab requests RUN --json` when a request list should be machine-readable. `framelab extract` writes a base JSON file; `framelab run` writes a result JSON file and a Markdown report. `framelab render` rewrites the report from result JSON. Exit code 0 means success, 1 means a check failed or all requests failed in transport, and 2 means the input needs correction. [llms.txt](llms.txt) is a compact guide to the repository.

## How Frame Lab relates to StateFrame

Frame Lab reads StateFrame run directories and journals. It does not import or pin a StateFrame package version, and it declares no numeric version range. Compatibility depends on the recorded journal format: submitted requests need exact `payload_utf8` bytes and a matching `payload_hash`. Frame Lab verifies those hashes before using a request. It reads run files and does not modify them.

## Safety defaults

- Frame Lab sends variants only to loopback servers unless you pass `--allow-remote`, because a variant carries your task text and code.
- An optional API key is read from `FRAMELAB_API_KEY` and is never written to results, logs or error messages.
- Every run is capped by `--max-requests` (40 by default). Results with small `n` say so.
- The UI is read only: it serves GET requests from 127.0.0.1, never contacts a model provider and writes nothing.

## Tests

The individual suites run with Python 3.11 or newer. The web suite also needs Node.js 20 or newer and `npm ci` in `ui/web`.

```bash
python3 -B -m unittest discover -s tests -t .
(cd ui && python3 -B -m unittest discover -s tests -t .)
(cd ui/web && npm test)
bash scripts/check.sh  # suites, license inventory, manifest and release archives
```

If another machine-wide test run is active, `FRAMELAB_SKIP_WEB_TESTS=1 bash scripts/check.sh` runs the other checks and reports the web suite as skipped. Run the full check when the machine is free.

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md) before sending a change. Contributions require the signed [CLA](CLA.md).

## License

Frame Lab is licensed under the GNU Affero General Public License v3.0 only (AGPL-3.0-only), or under a separate
commercial license from Farside Research LLC (see [COMMERCIAL-LICENSE.md](COMMERCIAL-LICENSE.md)). Third-party
packages keep their own licenses; see [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md).
Neither license grants permission to use the Farside Research, Frame Lab or StateFrame names or the Farside logo,
except as needed to describe the origin of the software; see [NOTICE](NOTICE).
