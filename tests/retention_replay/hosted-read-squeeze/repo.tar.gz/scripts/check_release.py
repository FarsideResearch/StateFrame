#!/usr/bin/env python3
"""Build release archives in a temporary directory and verify their file lists."""
from __future__ import annotations

import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="framelab-release-") as directory:
        result = subprocess.run([sys.executable, str(ROOT / "scripts" / "build_release.py"), directory],
                                cwd=ROOT, check=False)
        if result.returncode:
            return result.returncode
        wheels = list(Path(directory).glob("*.whl"))
        sdists = list(Path(directory).glob("*.tar.gz"))
        if len(wheels) != 1 or len(sdists) != 1:
            raise ValueError(f"expected one wheel and one sdist; found {len(wheels)} wheel(s), "
                             f"{len(sdists)} sdist(s)")
        wheel, sdist = wheels[0], sdists[0]
        with zipfile.ZipFile(wheel) as archive:
            wheel_names = set(archive.namelist())
            if "framelab/__init__.py" not in wheel_names or not any(
                    name.endswith(".dist-info/METADATA") for name in wheel_names):
                raise ValueError("wheel listing is missing the package or metadata")
        with tarfile.open(sdist, "r:gz") as archive:
            names = {name.partition("/")[2] for name in archive.getnames()}
        expected = {line for line in (ROOT / "MANIFEST.txt").read_text(encoding="utf-8").splitlines()
                    if line and not line.startswith("#")}
        expected.add("PKG-INFO")
        if names != expected:
            raise ValueError(f"sdist listing differs from MANIFEST.txt: "
                             f"missing={sorted(expected - names)}, extra={sorted(names - expected)}")
        print(f"release listings verified: {len(wheel_names)} wheel entries, {len(names)} sdist entries")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, tarfile.TarError, zipfile.BadZipFile) as exc:
        print(f"release listing check failed: {exc}", file=sys.stderr)
        sys.exit(1)
