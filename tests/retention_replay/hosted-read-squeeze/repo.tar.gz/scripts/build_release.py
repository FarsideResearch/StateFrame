#!/usr/bin/env python3
"""Build the offline release artifacts (wheel + sdist) into OUT with the in-tree stdlib backend.

    python3 scripts/build_release.py OUT_DIR
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print(__doc__.strip())
        return 2
    out = Path(argv[0]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    spec = importlib.util.spec_from_file_location("fl_backend", ROOT / "_build" / "fl_backend.py")
    backend = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(backend)
    try:
        for name in (backend.build_wheel(str(out)), backend.build_sdist(str(out))):
            print(out / name)
    except backend.BuildError as exc:
        print(f"release build failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
