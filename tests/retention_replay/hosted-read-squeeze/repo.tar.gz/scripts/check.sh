#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
status=0

run_step() {
  local label="$1"
  shift
  printf '==> %s\n' "$label"
  if (cd "$ROOT" && "$@"); then
    printf 'PASS: %s\n' "$label"
  else
    result=$?
    printf 'FAIL: %s (exit %s)\n' "$label" "$result"
    status=1
  fi
}

run_step 'Core Python suite' python3 -B -m unittest tests.test_framelab tests.test_manifest
run_step 'License inventory tests' python3 -B -m unittest tests.test_license_inventory
run_step 'License inventory' python3 scripts/license_inventory.py
run_step 'Manifest check' python3 scripts/manifest.py check
run_step 'Release archives' python3 scripts/check_release.py

printf '==> UI server suite\n'
if (cd "$ROOT/ui" && python3 -B -m unittest discover -s tests -t .); then
  printf 'PASS: UI server suite\n'
else
  result=$?
  printf 'FAIL: UI server suite (exit %s)\n' "$result"
  status=1
fi

if [ "${FRAMELAB_SKIP_WEB_TESTS:-}" = 1 ]; then
  printf 'SKIP: Web app suite; FRAMELAB_SKIP_WEB_TESTS=1 (another machine-wide test run is active).\n'
elif [ -d "$ROOT/ui/web/node_modules" ]; then
  printf '==> Web app suite\n'
  if (cd "$ROOT/ui/web" && npm test); then
    printf 'PASS: Web app suite\n'
  else
    result=$?
    printf 'FAIL: Web app suite (exit %s)\n' "$result"
    status=1
  fi
else
  printf 'SKIP: Web app suite; install Node.js 20+ and run `npm ci` in ui/web, then rerun `bash scripts/check.sh`.\n'
fi

exit "$status"
