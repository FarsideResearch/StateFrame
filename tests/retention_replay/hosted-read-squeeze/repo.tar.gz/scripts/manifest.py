#!/usr/bin/env python3
"""Check or refresh the tracked release payload in MANIFEST.txt.

    python3 scripts/manifest.py check
    python3 scripts/manifest.py refresh
    python3 scripts/manifest.py refresh-web

In a checkout, every tracked file is part of the payload. Outside Git, local
installations, caches, and build outputs are excluded from the tree walk.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.txt"
HEADER = "# Every file the Frame Lab source package ships, one per line. Maintained with scripts/manifest.py.\n"
EXCLUDED_DIRS = {".git", ".venv", "venv", "__pycache__", "node_modules"}
# ui/web/dist is a shipped bundle, so only root-level release output directories are excluded.
EXCLUDED_ROOT_DIRS = {"build", "dist", "_dist", "work"}
WEB_DIST = "ui/web/dist/"


def _tracked() -> list[str] | None:
    try:
        root = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--show-toplevel"],
                              capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return None
    if root.returncode != 0 or Path(root.stdout.strip()).resolve() != ROOT.resolve():
        return None
    result = subprocess.run(["git", "-C", str(ROOT), "ls-files", "--cached", "-z"],
                            capture_output=True, check=True)
    return sorted(name.decode("utf-8", "surrogateescape") for name in result.stdout.split(b"\0") if name)


def _walk() -> list[str]:
    files: list[str] = []
    for directory, subdirs, names in os.walk(ROOT, followlinks=False):
        current = Path(directory)
        subdirs[:] = sorted(name for name in subdirs if name not in EXCLUDED_DIRS
                            and not (current == ROOT and name in EXCLUDED_ROOT_DIRS)
                            and not name.endswith(".egg-info")
                            and not (current / name / "pyvenv.cfg").is_file())
        files.extend((current / name).relative_to(ROOT).as_posix() for name in names
                     if name not in {".DS_Store", ".git"} and (current / name).is_file())
    return sorted(files)


def payload() -> list[str]:
    tracked = _tracked()
    return tracked if tracked is not None else _walk()


def listed() -> list[str]:
    lines = MANIFEST.read_text(encoding="utf-8").splitlines() if MANIFEST.is_file() else []
    return [line for line in lines if line and not line.startswith("#")]


def _write(names: list[str]) -> None:
    MANIFEST.write_text(HEADER + "\n".join(sorted(set(names) | {"MANIFEST.txt"})) + "\n", encoding="utf-8")


def main(argv: list[str]) -> int:
    command = argv[0] if argv else "check"
    if command in {"refresh", "write"}:
        _write(payload())
    elif command == "refresh-web":
        _write([n for n in listed() if not n.startswith(WEB_DIST)]
               + [n for n in payload() if n.startswith(WEB_DIST)])
    elif command != "check":
        print(__doc__.strip())
        return 2
    want, have = set(listed()), set(payload())
    missing = sorted(name for name in want if name not in have or not (ROOT / name).is_file()
                     or (ROOT / name).is_symlink())
    unlisted = sorted(have - want)
    for name in missing:
        print(f"listed but missing: {name}")
    for name in unlisted:
        if (ROOT / name).is_file() and not (ROOT / name).is_symlink():
            print(f"present but not listed: {name}")
        else:
            print(f"tracked but missing and not listed: {name}")
    print(f"manifest: {len(want)} files, {len(missing)} missing, {len(unlisted)} unlisted")
    return 1 if missing or unlisted or not want else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
