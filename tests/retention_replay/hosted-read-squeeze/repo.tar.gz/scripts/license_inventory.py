#!/usr/bin/env python3
"""Check the license of every third-party package Frame Lab uses and fail on anything not permissive.

Three checks, all offline:

1. Web, locked: every package in ui/web/package-lock.json.
2. Web, installed: every package.json actually present under ui/web/node_modules, nested folders included,
   so a package installed outside the lockfile is caught too. Skipped (and said so) when node_modules is absent.
3. Python: every import in the repository's Python files must be the standard library or this repository's
   own modules. The command line and the UI server have no Python dependencies, so any other import fails.

A license passes only when every term of its SPDX expression is in ALLOWED. Copyleft, source-available and
non-commercial licenses are named in DENIED so the failure says why; UNKNOWN or a missing license also fails.

    python3 scripts/license_inventory.py [--markdown OUT.md]
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "ui" / "web"
# Permissive licenses accepted for dependencies. ISC is the MIT-equivalent license used by many npm
# packages; Python-2.0 and PSF-2.0 are the PSF licenses; BlueOak-1.0.0 is a permissive MIT-style license.
ALLOWED = {"MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0", "ISC", "Python-2.0", "PSF-2.0", "Zlib", "0BSD", "BlueOak-1.0.0"}
# Never acceptable for a dependency, matched as a prefix of each SPDX term (GPL-3.0-only, LGPL-2.1-or-later, ...).
DENIED = ("GPL", "LGPL", "AGPL", "SSPL", "BUSL", "CC-BY-NC", "CC-BY-SA", "MPL", "EUPL", "OSL", "CDDL", "EPL", "Commons-Clause", "Elastic")
# Folders that hold this repository's own Python modules (imported by bare name from their folder).
OWN_ROOTS = (ROOT / "src", ROOT / "ui", ROOT / "_build", ROOT / "scripts", ROOT / "examples", ROOT)
SKIP_DIRS = {"node_modules", ".git", "__pycache__", "dist", "_dist", "build"}
# Optional Python imports: loaded only if the user installed the package, never bundled or required.
# module -> (distribution, SPDX license). Each license must still pass verdict().
OPTIONAL_PYTHON = {"yaml": ("PyYAML", "MIT")}


def _terms(expression: str) -> set[str]:
    return {t for t in re.split(r"\s+(?:AND|OR|WITH)\s+|[()]", expression) if t.strip()} if expression else set()


def verdict(expression: str) -> tuple[bool, str]:
    terms = {t.strip() for t in _terms(expression)}
    if not terms or "UNKNOWN" in terms:
        return False, "no license declared"
    denied = sorted(t for t in terms if t.startswith(DENIED))
    if denied:
        return False, "denied license: " + ", ".join(denied)
    outside = sorted(terms - ALLOWED)
    if outside:
        return False, "not on the permissive list: " + ", ".join(outside)
    return True, ""


def _manifest_license(manifest: Path) -> str:
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "UNKNOWN"
    value = data.get("license") or (data.get("licenses") or [{}])[0].get("type")
    if isinstance(value, dict):
        value = value.get("type")
    return str(value or "UNKNOWN")


def locked_rows() -> list[dict[str, object]]:
    lock = json.loads((WEB / "package-lock.json").read_text(encoding="utf-8"))
    rows = []
    for key, locked in sorted(lock.get("packages", {}).items()):
        if not key.startswith("node_modules/"):
            continue
        expression = str(locked.get("license") or _manifest_license(WEB / key / "package.json"))
        ok, why = verdict(expression)
        rows.append({"name": key.split("node_modules/")[-1], "path": key, "version": locked.get("version"),
                     "license": expression, "scope": "dev" if locked.get("dev") else "locked",
                     "optional": bool(locked.get("optional")), "allowed": ok, "why": why})
    return rows


def installed_rows() -> list[dict[str, object]] | None:
    modules = WEB / "node_modules"
    if not modules.is_dir():
        return None
    rows = []
    for manifest in sorted(modules.rglob("package.json")):
        rel = manifest.parent.relative_to(WEB).as_posix()
        # A package root is node_modules/<name> or node_modules/@scope/<name>; skip package.json files nested
        # inside a package's own source tree (test fixtures, sub-entry points).
        if not re.fullmatch(r"(?:node_modules/(?:@[^/]+/)?[^/@][^/]*/)*node_modules/(?:@[^/]+/)?[^/@][^/]*", rel):
            continue
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = {}
        if not data.get("name"):
            continue
        expression = _manifest_license(manifest)
        ok, why = verdict(expression)
        rows.append({"name": data["name"], "path": rel, "version": data.get("version"), "license": expression,
                     "allowed": ok, "why": why})
    return rows


def python_rows() -> list[dict[str, object]]:
    own = set()
    for base in OWN_ROOTS:
        if base.is_dir():
            own |= {p.stem for p in base.glob("*.py")} | {p.name for p in base.iterdir() if (p / "__init__.py").is_file()}
    stdlib = set(sys.stdlib_module_names) | {"__future__"}
    rows = []
    for path in sorted(ROOT.rglob("*.py")):
        if SKIP_DIRS & set(path.relative_to(ROOT).parts):
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                top = name.split(".")[0]
                if top not in stdlib and top not in own:
                    rows.append({"file": path.relative_to(ROOT).as_posix(), "line": node.lineno, "module": name})
    return rows


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--markdown", type=Path, help="write the locked-package table here")
    args = parser.parse_args(argv)
    failures = 0

    locked = locked_rows()
    for scope in ("locked", "dev"):
        counts = Counter(r["license"] for r in locked if r["scope"] == scope)
        print(f"web {scope}: {sum(counts.values())} packages: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
    for row in locked:
        if not row["allowed"]:
            failures += 1
            print(f"NOT ALLOWED (lockfile): {row['name']} {row['version']} {row['license']}: {row['why']}")

    installed = installed_rows()
    if installed is None:
        print("web installed: SKIP (ui/web/node_modules not present; run npm ci in ui/web to check the installed tree)")
    else:
        counts = Counter(r["license"] for r in installed)
        print(f"web installed: {len(installed)} packages: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
        locked_paths = {r["path"] for r in locked}
        for row in installed:
            if not row["allowed"]:
                failures += 1
                print(f"NOT ALLOWED (installed): {row['name']} {row['version']} {row['license']} at {row['path']}: {row['why']}")
            if row["path"] not in locked_paths:
                failures += 1
                print(f"NOT IN LOCKFILE: {row['name']} {row['version']} at {row['path']}")

    python = python_rows()
    optional = [r for r in python if r["module"].split(".")[0] in OPTIONAL_PYTHON]
    unexpected = [r for r in python if r not in optional]
    print(f"python: 0 required packages; {len(optional)} optional import(s); {len(unexpected)} unexpected")
    for row in optional:
        dist, expression = OPTIONAL_PYTHON[row["module"].split(".")[0]]
        ok, why = verdict(expression)
        print(f"  optional: {dist} ({expression}) imported in {row['file']}:{row['line']}, only if installed")
        if not ok:
            failures += 1
            print(f"NOT ALLOWED (optional python): {dist} {expression}: {why}")
    for row in unexpected:
        failures += 1
        print(f"THIRD-PARTY PYTHON IMPORT: {row['module']} in {row['file']}:{row['line']}")

    if args.markdown:
        lines = ["| Package | Version | License | Install scope |", "|---|---|---|---|"]
        lines += [f"| `{r['name']}` | {r['version']} | {r['license']} | {r['scope']}{' (optional)' if r['optional'] else ''} |" for r in locked]
        args.markdown.write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not locked:
        print("no locked packages found; the lockfile is missing or empty")
        failures += 1
    print("LICENSE CHECK " + ("FAILED: %d problem(s)" % failures if failures else "PASSED"))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
