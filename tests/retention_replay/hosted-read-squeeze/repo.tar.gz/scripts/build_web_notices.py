#!/usr/bin/env python3
"""Write ui/web/public/THIRD_PARTY_NOTICES.md with the full license text of every package the web bundle ships.

The shipped set is the runtime closure of ui/web/package.json "dependencies" (not devDependencies), resolved
through package-lock.json the way Node resolves nested node_modules. Each package's own LICENSE file is copied
verbatim, so every copyright line the license requires travels with the bundle. Vite copies the file into
web/dist on build. Fails if a shipped package has no license file or a license outside the allowed set.

    python3 scripts/build_web_notices.py [--check]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "ui" / "web"
OUT = WEB / "public" / "THIRD_PARTY_NOTICES.md"
ALLOWED = {"MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0", "ISC", "Python-2.0", "PSF-2.0", "Zlib", "0BSD"}
MIT_TEXT = """Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE."""
LICENSE_NAMES = ("LICENSE", "LICENSE.md", "LICENSE.txt", "LICENCE", "LICENCE.md", "license", "license.md", "LICENSE-MIT")


def _resolve(lock: dict, parent_key: str, name: str) -> str:
    """Node resolution: look in parent/node_modules, then each ancestor's, then the top level."""
    base = parent_key
    while True:
        candidate = f"{base}/node_modules/{name}" if base else f"node_modules/{name}"
        if candidate in lock:
            return candidate
        if not base:
            raise SystemExit(f"cannot resolve {name} from {parent_key or 'the root'}")
        base = base.rsplit("/node_modules/", 1)[0] if "/node_modules/" in base else ""


def runtime_closure() -> list[str]:
    packages = json.loads((WEB / "package-lock.json").read_text(encoding="utf-8"))["packages"]
    root_deps = json.loads((WEB / "package.json").read_text(encoding="utf-8")).get("dependencies", {})
    seen: set[str] = set()
    stack = [_resolve(packages, "", name) for name in root_deps]
    while stack:
        key = stack.pop()
        if key in seen:
            continue
        seen.add(key)
        for dep in (packages[key].get("dependencies") or {}):
            stack.append(_resolve(packages, key, dep))
    return sorted(seen)


def render() -> str:
    packages = json.loads((WEB / "package-lock.json").read_text(encoding="utf-8"))["packages"]
    sections = []
    rows = []
    for key in runtime_closure():
        meta = packages[key]
        name = key.split("node_modules/")[-1]
        license_id = str(meta.get("license") or "")
        if license_id not in ALLOWED:
            raise SystemExit(f"{name}: license {license_id or 'missing'} is not in the allowed set")
        text_path = next((WEB / key / n for n in LICENSE_NAMES if (WEB / key / n).is_file()), None)
        if text_path is not None:
            body = text_path.read_text(encoding="utf-8").strip()
        elif license_id == "MIT":
            # A few packages declare MIT but ship no license file; reproduce the standard text with their author.
            manifest = json.loads((WEB / key / "package.json").read_text(encoding="utf-8"))
            author = manifest.get("author")
            author = author.get("name") if isinstance(author, dict) else author
            if not author:
                raise SystemExit(f"{name}: MIT without a license file or an author to credit")
            body = (f"(No license file ships with this package; standard MIT text with the author named in its package.json.)\n\n"
                    f"Copyright (c) {author}\n\n{MIT_TEXT}")
        else:
            raise SystemExit(f"{name}: no license file in {WEB / key}")
        rows.append(f"| `{name}` | {meta.get('version')} | {license_id} |")
        sections.append(f"## {name} {meta.get('version')} ({license_id})\n\n```text\n{body}\n```\n")
    header = (
        "# Frame Lab UI third-party notices\n\n"
        "The Frame Lab web bundle (web/dist) includes the packages below. Each section reproduces the package's own\n"
        "license file. Build tools such as Vite are not part of the bundle and are not listed. Generated by\n"
        "scripts/build_web_notices.py from web/package-lock.json; do not edit by hand.\n\n"
        "| Package | Version | License |\n|---|---|---|\n" + "\n".join(rows) + "\n\n"
    )
    return header + "\n".join(sections)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="fail if the committed file is out of date")
    args = parser.parse_args(argv)
    text = render()
    if args.check:
        if OUT.read_text(encoding="utf-8") != text:
            print(f"{OUT} is out of date; run scripts/build_web_notices.py")
            return 1
        print("web notices up to date")
        return 0
    OUT.write_text(text, encoding="utf-8")
    print(f"wrote {OUT} ({text.count(chr(10) + '## ')} packages)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
